package org.apache.naming.factory;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePartDataSource;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class SendMailFactory
  implements ObjectFactory
{
  protected final String DataSourceClassName = "javax.mail.internet.MimePartDataSource";
  
  public SendMailFactory() {}
  
  public Object getObjectInstance(Object refObj, Name name, Context ctx, Hashtable<?, ?> env)
    throws Exception
  {
    final Reference ref = (Reference)refObj;
    if (ref.getClassName().equals("javax.mail.internet.MimePartDataSource")) {
      AccessController.doPrivileged(new PrivilegedAction()
      {
        public MimePartDataSource run()
        {
          Properties props = new Properties();
          
          Enumeration<RefAddr> list = ref.getAll();
          
          props.put("mail.transport.protocol", "smtp");
          while (list.hasMoreElements())
          {
            RefAddr refaddr = (RefAddr)list.nextElement();
            
            props.put(refaddr.getType(), refaddr.getContent());
          }
          MimeMessage message = new MimeMessage(Session.getInstance(props));
          try
          {
            RefAddr fromAddr = ref.get("mail.from");
            String from = null;
            if (fromAddr != null) {
              from = (String)ref.get("mail.from").getContent();
            }
            if (from != null) {
              message.setFrom(new InternetAddress(from));
            }
            message.setSubject("");
          }
          catch (Exception e) {}
          MimePartDataSource mds = new MimePartDataSource(message);
          return mds;
        }
      });
    }
    return null;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\naming\factory\SendMailFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */