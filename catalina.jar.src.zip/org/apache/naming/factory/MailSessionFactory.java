package org.apache.naming.factory;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class MailSessionFactory
  implements ObjectFactory
{
  protected static final String factoryType = "javax.mail.Session";
  
  public MailSessionFactory() {}
  
  public Object getObjectInstance(Object refObj, Name name, Context context, Hashtable<?, ?> env)
    throws Exception
  {
    final Reference ref = (Reference)refObj;
    if (!ref.getClassName().equals("javax.mail.Session")) {
      return null;
    }
    AccessController.doPrivileged(new PrivilegedAction()
    {
      public Session run()
      {
        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", "localhost");
        
        String password = null;
        
        Enumeration<RefAddr> attrs = ref.getAll();
        while (attrs.hasMoreElements())
        {
          RefAddr attr = (RefAddr)attrs.nextElement();
          if (!"factory".equals(attr.getType())) {
            if ("password".equals(attr.getType())) {
              password = (String)attr.getContent();
            } else {
              props.put(attr.getType(), attr.getContent());
            }
          }
        }
        Authenticator auth = null;
        if (password != null)
        {
          String user = props.getProperty("mail.smtp.user");
          if (user == null) {
            user = props.getProperty("mail.user");
          }
          if (user != null)
          {
            final PasswordAuthentication pa = new PasswordAuthentication(user, password);
            auth = new Authenticator()
            {
              protected PasswordAuthentication getPasswordAuthentication()
              {
                return pa;
              }
            };
          }
        }
        Session session = Session.getInstance(props, auth);
        return session;
      }
    });
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\naming\factory\MailSessionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */