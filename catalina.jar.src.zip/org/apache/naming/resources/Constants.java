package org.apache.naming.resources;

public final class Constants
{
  public static final String PROTOCOL_HANDLER_VARIABLE = "java.protocol.handler.pkgs";
  public static final String Package = "org.apache.naming.resources";
  
  public Constants() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\naming\resources\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */