package org.apache.naming.java;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;
import javax.naming.spi.ObjectFactory;
import org.apache.naming.ContextBindings;
import org.apache.naming.NamingContext;
import org.apache.naming.SelectorContext;

public class javaURLContextFactory
  implements ObjectFactory, InitialContextFactory
{
  public static final String MAIN = "initialContext";
  protected static volatile Context initialContext = null;
  
  public javaURLContextFactory() {}
  
  public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment)
    throws NamingException
  {
    if ((ContextBindings.isThreadBound()) || (ContextBindings.isClassLoaderBound())) {
      return new SelectorContext(environment);
    }
    return null;
  }
  
  public Context getInitialContext(Hashtable<?, ?> environment)
    throws NamingException
  {
    if ((ContextBindings.isThreadBound()) || (ContextBindings.isClassLoaderBound())) {
      return new SelectorContext(environment, true);
    }
    if (initialContext == null) {
      synchronized (javaURLContextFactory.class)
      {
        if (initialContext == null) {
          initialContext = new NamingContext(environment, "initialContext");
        }
      }
    }
    return initialContext;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\naming\java\javaURLContextFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */