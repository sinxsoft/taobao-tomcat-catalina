package org.apache.catalina.ssi;

public class SSIStopProcessingException
  extends Exception
{
  private static final long serialVersionUID = 1L;
  
  public SSIStopProcessingException() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\ssi\SSIStopProcessingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */