package org.apache.catalina.ssi;

import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class ExpressionParseTree
{
  private LinkedList<Node> nodeStack = new LinkedList();
  private LinkedList<OppNode> oppStack = new LinkedList();
  private Node root;
  private SSIMediator ssiMediator;
  private static final int PRECEDENCE_NOT = 5;
  private static final int PRECEDENCE_COMPARE = 4;
  private static final int PRECEDENCE_LOGICAL = 1;
  
  public ExpressionParseTree(String expr, SSIMediator ssiMediator)
    throws ParseException
  {
    this.ssiMediator = ssiMediator;
    parseExpression(expr);
  }
  
  public boolean evaluateTree()
  {
    return this.root.evaluate();
  }
  
  private void pushOpp(OppNode node)
  {
    if (node == null)
    {
      this.oppStack.add(0, node);
      return;
    }
    while (this.oppStack.size() != 0)
    {
      OppNode top = (OppNode)this.oppStack.get(0);
      if (top == null) {
        break;
      }
      if (top.getPrecedence() < node.getPrecedence()) {
        break;
      }
      this.oppStack.remove(0);
      
      top.popValues(this.nodeStack);
      
      this.nodeStack.add(0, top);
    }
    this.oppStack.add(0, node);
  }
  
  private void resolveGroup()
  {
    OppNode top = null;
    while ((top = (OppNode)this.oppStack.remove(0)) != null)
    {
      top.popValues(this.nodeStack);
      
      this.nodeStack.add(0, top);
    }
  }
  
  private void parseExpression(String expr)
    throws ParseException
  {
    StringNode currStringNode = null;
    
    pushOpp(null);
    ExpressionTokenizer et = new ExpressionTokenizer(expr);
    while (et.hasMoreTokens())
    {
      int token = et.nextToken();
      if (token != 0) {
        currStringNode = null;
      }
      switch (token)
      {
      case 0: 
        if (currStringNode == null)
        {
          currStringNode = new StringNode(et.getTokenValue());
          this.nodeStack.add(0, currStringNode);
        }
        else
        {
          currStringNode.value.append(" ");
          currStringNode.value.append(et.getTokenValue());
        }
        break;
      case 1: 
        pushOpp(new AndNode(null));
        break;
      case 2: 
        pushOpp(new OrNode(null));
        break;
      case 3: 
        pushOpp(new NotNode(null));
        break;
      case 4: 
        pushOpp(new EqualNode(null));
        break;
      case 5: 
        pushOpp(new NotNode(null));
        
        this.oppStack.add(0, new EqualNode(null));
        break;
      case 6: 
        resolveGroup();
        break;
      case 7: 
        pushOpp(null);
        break;
      case 8: 
        pushOpp(new NotNode(null));
        
        this.oppStack.add(0, new LessThanNode(null));
        break;
      case 9: 
        pushOpp(new NotNode(null));
        
        this.oppStack.add(0, new GreaterThanNode(null));
        break;
      case 10: 
        pushOpp(new GreaterThanNode(null));
        break;
      case 11: 
        pushOpp(new LessThanNode(null));
      }
    }
    resolveGroup();
    if (this.nodeStack.size() == 0) {
      throw new ParseException("No nodes created.", et.getIndex());
    }
    if (this.nodeStack.size() > 1) {
      throw new ParseException("Extra nodes created.", et.getIndex());
    }
    if (this.oppStack.size() != 0) {
      throw new ParseException("Unused opp nodes exist.", et.getIndex());
    }
    this.root = ((Node)this.nodeStack.get(0));
  }
  
  private abstract class Node
  {
    private Node() {}
    
    public abstract boolean evaluate();
  }
  
  private class StringNode
    extends ExpressionParseTree.Node
  {
    StringBuilder value;
    String resolved = null;
    
    public StringNode(String value)
    {
      super(null);
      this.value = new StringBuilder(value);
    }
    
    public String getValue()
    {
      if (this.resolved == null) {
        this.resolved = ExpressionParseTree.this.ssiMediator.substituteVariables(this.value.toString());
      }
      return this.resolved;
    }
    
    public boolean evaluate()
    {
      return getValue().length() != 0;
    }
    
    public String toString()
    {
      return this.value.toString();
    }
  }
  
  private abstract class OppNode
    extends ExpressionParseTree.Node
  {
    ExpressionParseTree.Node left;
    ExpressionParseTree.Node right;
    
    private OppNode()
    {
      super(null);
    }
    
    public abstract int getPrecedence();
    
    public void popValues(List<ExpressionParseTree.Node> values)
    {
      this.right = ((ExpressionParseTree.Node)values.remove(0));
      this.left = ((ExpressionParseTree.Node)values.remove(0));
    }
  }
  
  private final class NotNode
    extends ExpressionParseTree.OppNode
  {
    private NotNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      return !this.left.evaluate();
    }
    
    public int getPrecedence()
    {
      return 5;
    }
    
    public void popValues(List<ExpressionParseTree.Node> values)
    {
      this.left = ((ExpressionParseTree.Node)values.remove(0));
    }
    
    public String toString()
    {
      return this.left + " NOT";
    }
  }
  
  private final class AndNode
    extends ExpressionParseTree.OppNode
  {
    private AndNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      if (!this.left.evaluate()) {
        return false;
      }
      return this.right.evaluate();
    }
    
    public int getPrecedence()
    {
      return 1;
    }
    
    public String toString()
    {
      return this.left + " " + this.right + " AND";
    }
  }
  
  private final class OrNode
    extends ExpressionParseTree.OppNode
  {
    private OrNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      if (this.left.evaluate()) {
        return true;
      }
      return this.right.evaluate();
    }
    
    public int getPrecedence()
    {
      return 1;
    }
    
    public String toString()
    {
      return this.left + " " + this.right + " OR";
    }
  }
  
  private abstract class CompareNode
    extends ExpressionParseTree.OppNode
  {
    private CompareNode()
    {
      super(null);
    }
    
    protected int compareBranches()
    {
      String val1 = ((ExpressionParseTree.StringNode)this.left).getValue();
      String val2 = ((ExpressionParseTree.StringNode)this.right).getValue();
      
      int val2Len = val2.length();
      if ((val2Len > 1) && (val2.charAt(0) == '/') && (val2.charAt(val2Len - 1) == '/'))
      {
        String expr = val2.substring(1, val2Len - 1);
        try
        {
          Pattern pattern = Pattern.compile(expr);
          if (pattern.matcher(val1).find()) {
            return 0;
          }
          return -1;
        }
        catch (PatternSyntaxException pse)
        {
          ExpressionParseTree.this.ssiMediator.log("Invalid expression: " + expr, pse);
          return 0;
        }
      }
      return val1.compareTo(val2);
    }
  }
  
  private final class EqualNode
    extends ExpressionParseTree.CompareNode
  {
    private EqualNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      return compareBranches() == 0;
    }
    
    public int getPrecedence()
    {
      return 4;
    }
    
    public String toString()
    {
      return this.left + " " + this.right + " EQ";
    }
  }
  
  private final class GreaterThanNode
    extends ExpressionParseTree.CompareNode
  {
    private GreaterThanNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      return compareBranches() > 0;
    }
    
    public int getPrecedence()
    {
      return 4;
    }
    
    public String toString()
    {
      return this.left + " " + this.right + " GT";
    }
  }
  
  private final class LessThanNode
    extends ExpressionParseTree.CompareNode
  {
    private LessThanNode()
    {
      super(null);
    }
    
    public boolean evaluate()
    {
      return compareBranches() < 0;
    }
    
    public int getPrecedence()
    {
      return 4;
    }
    
    public String toString()
    {
      return this.left + " " + this.right + " LT";
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\ssi\ExpressionParseTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */