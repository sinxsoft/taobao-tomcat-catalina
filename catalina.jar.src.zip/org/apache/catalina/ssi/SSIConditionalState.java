package org.apache.catalina.ssi;

class SSIConditionalState
{
  boolean branchTaken = false;
  int nestingCount = 0;
  boolean processConditionalCommandsOnly = false;
  
  SSIConditionalState() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\ssi\SSIConditionalState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */