package org.apache.catalina.session;

import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

@Deprecated
final class StandardSessionContext
  implements HttpSessionContext
{
  private static final List<String> emptyString = ;
  
  StandardSessionContext() {}
  
  @Deprecated
  public Enumeration<String> getIds()
  {
    return Collections.enumeration(emptyString);
  }
  
  @Deprecated
  public HttpSession getSession(String id)
  {
    return null;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\session\StandardSessionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */