package org.apache.catalina.session;

public final class PersistentManager
  extends PersistentManagerBase
{
  private static final String info = "PersistentManager/1.0";
  protected static String name = "PersistentManager";
  
  public PersistentManager() {}
  
  public String getInfo()
  {
    return "PersistentManager/1.0";
  }
  
  public String getName()
  {
    return name;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\session\PersistentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */