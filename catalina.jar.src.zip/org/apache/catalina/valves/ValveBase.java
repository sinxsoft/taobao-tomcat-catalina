package org.apache.catalina.valves;

import java.io.IOException;
import javax.servlet.ServletException;
import org.apache.catalina.Contained;
import org.apache.catalina.Container;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Pipeline;
import org.apache.catalina.Valve;
import org.apache.catalina.comet.CometEvent;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.mbeans.MBeanUtils;
import org.apache.catalina.util.LifecycleMBeanBase;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.res.StringManager;

public abstract class ValveBase
  extends LifecycleMBeanBase
  implements Contained, Valve
{
  protected boolean asyncSupported;
  
  public ValveBase()
  {
    this(false);
  }
  
  public ValveBase(boolean asyncSupported)
  {
    this.asyncSupported = asyncSupported;
  }
  
  protected Container container = null;
  protected Log containerLog = null;
  protected static final String info = "org.apache.catalina.core.ValveBase/1.0";
  protected Valve next = null;
  protected static final StringManager sm = StringManager.getManager("org.apache.catalina.valves");
  
  public Container getContainer()
  {
    return this.container;
  }
  
  public boolean isAsyncSupported()
  {
    return this.asyncSupported;
  }
  
  public void setAsyncSupported(boolean asyncSupported)
  {
    this.asyncSupported = asyncSupported;
  }
  
  public void setContainer(Container container)
  {
    this.container = container;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.core.ValveBase/1.0";
  }
  
  public Valve getNext()
  {
    return this.next;
  }
  
  public void setNext(Valve valve)
  {
    this.next = valve;
  }
  
  public void backgroundProcess() {}
  
  public abstract void invoke(Request paramRequest, Response paramResponse)
    throws IOException, ServletException;
  
  public void event(Request request, Response response, CometEvent event)
    throws IOException, ServletException
  {
    getNext().event(request, response, event);
  }
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    
    this.containerLog = getContainer().getLogger();
  }
  
  protected synchronized void startInternal()
    throws LifecycleException
  {
    setState(LifecycleState.STARTING);
  }
  
  protected synchronized void stopInternal()
    throws LifecycleException
  {
    setState(LifecycleState.STOPPING);
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder(getClass().getName());
    sb.append('[');
    if (this.container == null) {
      sb.append("Container is null");
    } else {
      sb.append(this.container.getName());
    }
    sb.append(']');
    return sb.toString();
  }
  
  public String getObjectNameKeyProperties()
  {
    StringBuilder name = new StringBuilder("type=Valve");
    
    Container container = getContainer();
    
    name.append(MBeanUtils.getContainerKeyProperties(container));
    
    int seq = 0;
    
    Pipeline p = container.getPipeline();
    if (p != null) {
      for (Valve valve : p.getValves()) {
        if (valve != null)
        {
          if (valve == this) {
            break;
          }
          if (valve.getClass() == getClass()) {
            seq++;
          }
        }
      }
    }
    if (seq > 0)
    {
      name.append(",seq=");
      name.append(seq);
    }
    String className = getClass().getName();
    int period = className.lastIndexOf('.');
    if (period >= 0) {
      className = className.substring(period + 1);
    }
    name.append(",name=");
    name.append(className);
    
    return name.toString();
  }
  
  public String getDomainInternal()
  {
    return MBeanUtils.getDomain(getContainer());
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\ValveBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */