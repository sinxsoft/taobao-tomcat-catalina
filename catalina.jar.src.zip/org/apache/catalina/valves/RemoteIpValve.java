package org.apache.catalina.valves;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Response;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.buf.MessageBytes;
import org.apache.tomcat.util.http.MimeHeaders;
import org.apache.tomcat.util.res.StringManager;

public class RemoteIpValve
  extends ValveBase
{
  private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
  private static final String info = "org.apache.catalina.valves.RemoteIpValve/1.0";
  private static final Log log = LogFactory.getLog(RemoteIpValve.class);
  
  protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
  {
    return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern.split(commaDelimitedStrings);
  }
  
  protected static String listToCommaDelimitedString(List<String> stringList)
  {
    if (stringList == null) {
      return "";
    }
    StringBuilder result = new StringBuilder();
    for (Iterator<String> it = stringList.iterator(); it.hasNext();)
    {
      Object element = it.next();
      if (element != null)
      {
        result.append(element);
        if (it.hasNext()) {
          result.append(", ");
        }
      }
    }
    return result.toString();
  }
  
  private int httpServerPort = 80;
  private int httpsServerPort = 443;
  private boolean changeLocalPort = false;
  private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
  private String protocolHeader = null;
  private String protocolHeaderHttpsValue = "https";
  private String portHeader = null;
  private String proxiesHeader = "X-Forwarded-By";
  private String remoteIpHeader = "X-Forwarded-For";
  private boolean requestAttributesEnabled = true;
  private Pattern trustedProxies = null;
  
  public RemoteIpValve()
  {
    super(true);
  }
  
  public int getHttpsServerPort()
  {
    return this.httpsServerPort;
  }
  
  public int getHttpServerPort()
  {
    return this.httpServerPort;
  }
  
  public boolean isChangeLocalPort()
  {
    return this.changeLocalPort;
  }
  
  public void setChangeLocalPort(boolean changeLocalPort)
  {
    this.changeLocalPort = changeLocalPort;
  }
  
  public String getPortHeader()
  {
    return this.portHeader;
  }
  
  public void setPortHeader(String portHeader)
  {
    this.portHeader = portHeader;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.RemoteIpValve/1.0";
  }
  
  public String getInternalProxies()
  {
    if (this.internalProxies == null) {
      return null;
    }
    return this.internalProxies.toString();
  }
  
  public String getProtocolHeader()
  {
    return this.protocolHeader;
  }
  
  public String getProtocolHeaderHttpsValue()
  {
    return this.protocolHeaderHttpsValue;
  }
  
  public String getProxiesHeader()
  {
    return this.proxiesHeader;
  }
  
  public String getRemoteIpHeader()
  {
    return this.remoteIpHeader;
  }
  
  public boolean getRequestAttributesEnabled()
  {
    return this.requestAttributesEnabled;
  }
  
  public String getTrustedProxies()
  {
    if (this.trustedProxies == null) {
      return null;
    }
    return this.trustedProxies.toString();
  }
  
  public void invoke(org.apache.catalina.connector.Request request, Response response)
    throws IOException, ServletException
  {
    String originalRemoteAddr = request.getRemoteAddr();
    String originalRemoteHost = request.getRemoteHost();
    String originalScheme = request.getScheme();
    boolean originalSecure = request.isSecure();
    int originalServerPort = request.getServerPort();
    if ((this.internalProxies != null) && (this.internalProxies.matcher(originalRemoteAddr).matches()))
    {
      String remoteIp = null;
      
      LinkedList<String> proxiesHeaderValue = new LinkedList();
      StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
      for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements();)
      {
        if (concatRemoteIpHeaderValue.length() > 0) {
          concatRemoteIpHeaderValue.append(", ");
        }
        concatRemoteIpHeaderValue.append((String)e.nextElement());
      }
      String[] remoteIpHeaderValue = commaDelimitedListToStringArray(concatRemoteIpHeaderValue.toString());
      for (int idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--)
      {
        String currentRemoteIp = remoteIpHeaderValue[idx];
        remoteIp = currentRemoteIp;
        if (!this.internalProxies.matcher(currentRemoteIp).matches()) {
          if ((this.trustedProxies != null) && (this.trustedProxies.matcher(currentRemoteIp).matches()))
          {
            proxiesHeaderValue.addFirst(currentRemoteIp);
          }
          else
          {
            idx--;
            break;
          }
        }
      }
      LinkedList<String> newRemoteIpHeaderValue = new LinkedList();
      for (; idx >= 0; idx--)
      {
        String currentRemoteIp = remoteIpHeaderValue[idx];
        newRemoteIpHeaderValue.addFirst(currentRemoteIp);
      }
      if (remoteIp != null)
      {
        request.setRemoteAddr(remoteIp);
        request.setRemoteHost(remoteIp);
        if (proxiesHeaderValue.size() == 0)
        {
          request.getCoyoteRequest().getMimeHeaders().removeHeader(this.proxiesHeader);
        }
        else
        {
          String commaDelimitedListOfProxies = listToCommaDelimitedString(proxiesHeaderValue);
          request.getCoyoteRequest().getMimeHeaders().setValue(this.proxiesHeader).setString(commaDelimitedListOfProxies);
        }
        if (newRemoteIpHeaderValue.size() == 0)
        {
          request.getCoyoteRequest().getMimeHeaders().removeHeader(this.remoteIpHeader);
        }
        else
        {
          String commaDelimitedRemoteIpHeaderValue = listToCommaDelimitedString(newRemoteIpHeaderValue);
          request.getCoyoteRequest().getMimeHeaders().setValue(this.remoteIpHeader).setString(commaDelimitedRemoteIpHeaderValue);
        }
      }
      if (this.protocolHeader != null)
      {
        String protocolHeaderValue = request.getHeader(this.protocolHeader);
        if (protocolHeaderValue != null) {
          if (this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue))
          {
            request.setSecure(true);
            
            request.getCoyoteRequest().scheme().setString("https");
            
            setPorts(request, this.httpsServerPort);
          }
          else
          {
            request.setSecure(false);
            
            request.getCoyoteRequest().scheme().setString("http");
            
            setPorts(request, this.httpServerPort);
          }
        }
      }
      if (log.isDebugEnabled()) {
        log.debug("Incoming request " + request.getRequestURI() + " with originalRemoteAddr '" + originalRemoteAddr + "', originalRemoteHost='" + originalRemoteHost + "', originalSecure='" + originalSecure + "', originalScheme='" + originalScheme + "' will be seen as newRemoteAddr='" + request.getRemoteAddr() + "', newRemoteHost='" + request.getRemoteHost() + "', newScheme='" + request.getScheme() + "', newSecure='" + request.isSecure() + "'");
      }
    }
    else if (log.isDebugEnabled())
    {
      log.debug("Skip RemoteIpValve for request " + request.getRequestURI() + " with originalRemoteAddr '" + request.getRemoteAddr() + "'");
    }
    if (this.requestAttributesEnabled)
    {
      request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", request.getRemoteAddr());
      
      request.setAttribute("org.apache.tomcat.remoteAddr", request.getRemoteAddr());
      
      request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", request.getRemoteHost());
      
      request.setAttribute("org.apache.catalina.AccessLog.Protocol", request.getProtocol());
      
      request.setAttribute("org.apache.catalina.AccessLog.ServerPort", Integer.valueOf(request.getServerPort()));
    }
    try
    {
      getNext().invoke(request, response);
    }
    finally
    {
      request.setRemoteAddr(originalRemoteAddr);
      request.setRemoteHost(originalRemoteHost);
      
      request.setSecure(originalSecure);
      
      request.getCoyoteRequest().scheme().setString(originalScheme);
      
      request.setServerPort(originalServerPort);
    }
  }
  
  private void setPorts(org.apache.catalina.connector.Request request, int defaultPort)
  {
    int port = defaultPort;
    if (this.portHeader != null)
    {
      String portHeaderValue = request.getHeader(this.portHeader);
      if (portHeaderValue != null) {
        try
        {
          port = Integer.parseInt(portHeaderValue);
        }
        catch (NumberFormatException nfe)
        {
          if (log.isDebugEnabled()) {
            log.debug(sm.getString("remoteIpValve.invalidPortHeader", new Object[] { portHeaderValue, this.portHeader }), nfe);
          }
        }
      }
    }
    request.setServerPort(port);
    if (this.changeLocalPort) {
      request.setLocalPort(port);
    }
  }
  
  public void setHttpServerPort(int httpServerPort)
  {
    this.httpServerPort = httpServerPort;
  }
  
  public void setHttpsServerPort(int httpsServerPort)
  {
    this.httpsServerPort = httpsServerPort;
  }
  
  public void setInternalProxies(String internalProxies)
  {
    if ((internalProxies == null) || (internalProxies.length() == 0)) {
      this.internalProxies = null;
    } else {
      this.internalProxies = Pattern.compile(internalProxies);
    }
  }
  
  public void setProtocolHeader(String protocolHeader)
  {
    this.protocolHeader = protocolHeader;
  }
  
  public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue)
  {
    this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
  }
  
  public void setProxiesHeader(String proxiesHeader)
  {
    this.proxiesHeader = proxiesHeader;
  }
  
  public void setRemoteIpHeader(String remoteIpHeader)
  {
    this.remoteIpHeader = remoteIpHeader;
  }
  
  public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
  {
    this.requestAttributesEnabled = requestAttributesEnabled;
  }
  
  public void setTrustedProxies(String trustedProxies)
  {
    if ((trustedProxies == null) || (trustedProxies.length() == 0)) {
      this.trustedProxies = null;
    } else {
      this.trustedProxies = Pattern.compile(trustedProxies);
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\RemoteIpValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */