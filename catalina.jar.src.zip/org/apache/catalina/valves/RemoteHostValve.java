package org.apache.catalina.valves;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;

public final class RemoteHostValve
  extends RequestFilterValve
{
  private static final String info = "org.apache.catalina.valves.RemoteHostValve/1.0";
  protected volatile boolean addConnectorPort = false;
  
  public RemoteHostValve() {}
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.RemoteHostValve/1.0";
  }
  
  public boolean getAddConnectorPort()
  {
    return this.addConnectorPort;
  }
  
  public void setAddConnectorPort(boolean addConnectorPort)
  {
    this.addConnectorPort = addConnectorPort;
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    String property;
    String property;
    if (this.addConnectorPort) {
      property = request.getRequest().getRemoteHost() + ";" + request.getConnector().getPort();
    } else {
      property = request.getRequest().getRemoteHost();
    }
    process(property, request, response);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\RemoteHostValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */