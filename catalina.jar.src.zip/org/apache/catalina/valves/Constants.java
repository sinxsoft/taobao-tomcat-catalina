package org.apache.catalina.valves;

public final class Constants
{
  public static final String Package = "org.apache.catalina.valves";
  
  public Constants() {}
  
  public static final class AccessLog
  {
    public static final String COMMON_ALIAS = "common";
    public static final String COMMON_PATTERN = "%h %l %u %t \"%r\" %s %b";
    public static final String COMBINED_ALIAS = "combined";
    public static final String COMBINED_PATTERN = "%h %l %u %t \"%r\" %s %b \"%{Referer}i\" \"%{User-Agent}i\"";
    
    public AccessLog() {}
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */