package org.apache.catalina.valves;

import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;
import javax.servlet.ServletException;
import org.apache.catalina.Container;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Request;
import org.apache.catalina.util.RequestUtil;
import org.apache.catalina.util.ServerInfo;
import org.apache.coyote.ActionCode;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public class ErrorReportValve
  extends ValveBase
{
  private boolean showReport = true;
  private boolean showServerInfo = true;
  private static final String info = "org.apache.catalina.valves.ErrorReportValve/1.0";
  
  public ErrorReportValve()
  {
    super(true);
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.ErrorReportValve/1.0";
  }
  
  public void invoke(Request request, org.apache.catalina.connector.Response response)
    throws IOException, ServletException
  {
    getNext().invoke(request, response);
    if (response.isCommitted())
    {
      if (response.setErrorReported())
      {
        try
        {
          response.flushBuffer();
        }
        catch (Throwable t)
        {
          ExceptionUtils.handleThrowable(t);
        }
        response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, null);
      }
      return;
    }
    Throwable throwable = (Throwable)request.getAttribute("javax.servlet.error.exception");
    if ((request.isAsync()) && (!request.isAsyncCompleting())) {
      return;
    }
    if ((throwable != null) && (!response.isError()))
    {
      response.reset();
      response.sendError(500);
    }
    response.setSuspended(false);
    try
    {
      report(request, response, throwable);
    }
    catch (Throwable tt)
    {
      ExceptionUtils.handleThrowable(tt);
    }
  }
  
  protected void report(Request request, org.apache.catalina.connector.Response response, Throwable throwable)
  {
    int statusCode = response.getStatus();
    if ((statusCode < 400) || (response.getContentWritten() > 0L) || (!response.setErrorReported())) {
      return;
    }
    String message = RequestUtil.filter(response.getMessage());
    if (message == null)
    {
      if (throwable != null)
      {
        String exceptionMessage = throwable.getMessage();
        if ((exceptionMessage != null) && (exceptionMessage.length() > 0)) {
          message = RequestUtil.filter(new Scanner(exceptionMessage).nextLine());
        }
      }
      if (message == null) {
        message = "";
      }
    }
    String report = null;
    StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request.getLocales());
    
    response.setLocale(smClient.getLocale());
    try
    {
      report = smClient.getString("http." + statusCode);
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
    }
    if (report == null)
    {
      if (message.length() == 0) {
        return;
      }
      report = smClient.getString("errorReportValve.noDescription");
    }
    StringBuilder sb = new StringBuilder();
    
    sb.append("<html><head>");
    if ((this.showServerInfo) || (this.showReport))
    {
      sb.append("<title>");
      if (this.showServerInfo) {
        sb.append(ServerInfo.getServerInfo()).append(" - ");
      }
      sb.append(smClient.getString("errorReportValve.errorReport"));
      sb.append("</title>");
      sb.append("<style><!--");
      sb.append("H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}HR {color : #525D76;}");
      sb.append("--></style> ");
    }
    else
    {
      sb.append("<title>");
      sb.append(smClient.getString("errorReportValve.errorReport"));
      sb.append("</title>");
    }
    sb.append("</head><body>");
    sb.append("<h1>");
    sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] { String.valueOf(statusCode), message })).append("</h1>");
    if (this.showReport)
    {
      sb.append("<HR size=\"1\" noshade=\"noshade\">");
      sb.append("<p><b>type</b> ");
      if (throwable != null) {
        sb.append(smClient.getString("errorReportValve.exceptionReport"));
      } else {
        sb.append(smClient.getString("errorReportValve.statusReport"));
      }
      sb.append("</p>");
      sb.append("<p><b>");
      sb.append(smClient.getString("errorReportValve.message"));
      sb.append("</b> <u>");
      sb.append(message).append("</u></p>");
      sb.append("<p><b>");
      sb.append(smClient.getString("errorReportValve.description"));
      sb.append("</b> <u>");
      sb.append(report);
      sb.append("</u></p>");
      if (throwable != null)
      {
        String stackTrace = getPartialServletStackTrace(throwable);
        sb.append("<p><b>");
        sb.append(smClient.getString("errorReportValve.exception"));
        sb.append("</b> <pre>");
        sb.append(RequestUtil.filter(stackTrace));
        sb.append("</pre></p>");
        
        int loops = 0;
        Throwable rootCause = throwable.getCause();
        while ((rootCause != null) && (loops < 10))
        {
          stackTrace = getPartialServletStackTrace(rootCause);
          sb.append("<p><b>");
          sb.append(smClient.getString("errorReportValve.rootCause"));
          sb.append("</b> <pre>");
          sb.append(RequestUtil.filter(stackTrace));
          sb.append("</pre></p>");
          
          rootCause = rootCause.getCause();
          loops++;
        }
        sb.append("<p><b>");
        sb.append(smClient.getString("errorReportValve.note"));
        sb.append("</b> <u>");
        sb.append(smClient.getString("errorReportValve.rootCauseInLogs", new Object[] { this.showServerInfo ? ServerInfo.getServerInfo() : "" }));
        
        sb.append("</u></p>");
      }
      sb.append("<HR size=\"1\" noshade=\"noshade\">");
    }
    if (this.showServerInfo) {
      sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
    }
    sb.append("</body></html>");
    try
    {
      try
      {
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
      }
      catch (Throwable t)
      {
        ExceptionUtils.handleThrowable(t);
        if (this.container.getLogger().isDebugEnabled()) {
          this.container.getLogger().debug("status.setContentType", t);
        }
      }
      Writer writer = response.getReporter();
      if (writer != null)
      {
        writer.write(sb.toString());
        response.finishResponse();
      }
    }
    catch (IOException e) {}catch (IllegalStateException e) {}
  }
  
  protected String getPartialServletStackTrace(Throwable t)
  {
    StringBuilder trace = new StringBuilder();
    trace.append(t.toString()).append('\n');
    StackTraceElement[] elements = t.getStackTrace();
    int pos = elements.length;
    for (int i = elements.length - 1; i >= 0; i--) {
      if ((elements[i].getClassName().startsWith("org.apache.catalina.core.ApplicationFilterChain")) && (elements[i].getMethodName().equals("internalDoFilter")))
      {
        pos = i;
        break;
      }
    }
    for (int i = 0; i < pos; i++) {
      if (!elements[i].getClassName().startsWith("org.apache.catalina.core.")) {
        trace.append('\t').append(elements[i].toString()).append('\n');
      }
    }
    return trace.toString();
  }
  
  public void setShowReport(boolean showReport)
  {
    this.showReport = showReport;
  }
  
  public boolean isShowReport()
  {
    return this.showReport;
  }
  
  public void setShowServerInfo(boolean showServerInfo)
  {
    this.showServerInfo = showServerInfo;
  }
  
  public boolean isShowServerInfo()
  {
    return this.showServerInfo;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\ErrorReportValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */