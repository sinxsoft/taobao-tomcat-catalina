package org.apache.catalina.valves;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.servlet.ServletException;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class SSLValve
  extends ValveBase
{
  private static final Log log = LogFactory.getLog(SSLValve.class);
  
  public SSLValve()
  {
    super(true);
  }
  
  public String mygetHeader(Request request, String header)
  {
    String strcert0 = request.getHeader(header);
    if (strcert0 == null) {
      return null;
    }
    if ("(null)".equals(strcert0)) {
      return null;
    }
    return strcert0;
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    String strcert0 = mygetHeader(request, "ssl_client_cert");
    if ((strcert0 != null) && (strcert0.length() > 28))
    {
      String strcert1 = strcert0.replace(' ', '\n');
      String strcert2 = strcert1.substring(28, strcert1.length() - 26);
      String strcert3 = "-----BEGIN CERTIFICATE-----\n";
      String strcert4 = strcert3.concat(strcert2);
      String strcerts = strcert4.concat("\n-----END CERTIFICATE-----\n");
      
      ByteArrayInputStream bais = new ByteArrayInputStream(strcerts.getBytes(Charset.defaultCharset()));
      
      X509Certificate[] jsseCerts = null;
      String providerName = (String)request.getConnector().getProperty("clientCertProvider");
      try
      {
        CertificateFactory cf;
        CertificateFactory cf;
        if (providerName == null) {
          cf = CertificateFactory.getInstance("X.509");
        } else {
          cf = CertificateFactory.getInstance("X.509", providerName);
        }
        X509Certificate cert = (X509Certificate)cf.generateCertificate(bais);
        jsseCerts = new X509Certificate[1];
        jsseCerts[0] = cert;
      }
      catch (CertificateException e)
      {
        log.warn(sm.getString("sslValve.certError", new Object[] { strcerts }), e);
      }
      catch (NoSuchProviderException e)
      {
        log.error(sm.getString("sslValve.invalidProvider", new Object[] { providerName }), e);
      }
      request.setAttribute("javax.servlet.request.X509Certificate", jsseCerts);
    }
    strcert0 = mygetHeader(request, "ssl_cipher");
    if (strcert0 != null) {
      request.setAttribute("javax.servlet.request.cipher_suite", strcert0);
    }
    strcert0 = mygetHeader(request, "ssl_session_id");
    if (strcert0 != null)
    {
      request.setAttribute("javax.servlet.request.ssl_session_id", strcert0);
      request.setAttribute("javax.servlet.request.ssl_session", strcert0);
    }
    strcert0 = mygetHeader(request, "ssl_cipher_usekeysize");
    if (strcert0 != null) {
      request.setAttribute("javax.servlet.request.key_size", Integer.valueOf(strcert0));
    }
    getNext().invoke(request, response);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\SSLValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */