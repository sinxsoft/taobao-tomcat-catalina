package org.apache.catalina.valves;

import java.io.IOException;
import javax.servlet.ServletException;
import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.Loader;
import org.apache.catalina.Manager;
import org.apache.catalina.Session;
import org.apache.catalina.Store;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.session.PersistentManager;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.res.StringManager;

public class PersistentValve
  extends ValveBase
{
  private static final String info = "org.apache.catalina.valves.PersistentValve/1.0";
  
  public PersistentValve()
  {
    super(true);
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.PersistentValve/1.0";
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    Context context = request.getContext();
    if (context == null)
    {
      response.sendError(500, sm.getString("standardHost.noContext"));
      
      return;
    }
    Thread.currentThread().setContextClassLoader(context.getLoader().getClassLoader());
    
    String sessionId = request.getRequestedSessionId();
    Manager manager = context.getManager();
    if ((sessionId != null) && (manager != null) && 
      ((manager instanceof PersistentManager)))
    {
      Store store = ((PersistentManager)manager).getStore();
      if (store != null)
      {
        Session session = null;
        try
        {
          session = store.load(sessionId);
        }
        catch (Exception e)
        {
          this.container.getLogger().error("deserializeError");
        }
        if (session != null) {
          if ((!session.isValid()) || (isSessionStale(session, System.currentTimeMillis())))
          {
            if (this.container.getLogger().isDebugEnabled()) {
              this.container.getLogger().debug("session swapped in is invalid or expired");
            }
            session.expire();
            store.remove(sessionId);
          }
          else
          {
            session.setManager(manager);
            
            manager.add(session);
            
            session.access();
            session.endAccess();
          }
        }
      }
    }
    if (this.container.getLogger().isDebugEnabled()) {
      this.container.getLogger().debug("sessionId: " + sessionId);
    }
    getNext().invoke(request, response);
    if (!request.isAsync())
    {
      Session hsess;
      try
      {
        hsess = request.getSessionInternal();
      }
      catch (Exception ex)
      {
        hsess = null;
      }
      String newsessionId = null;
      if (hsess != null) {
        newsessionId = hsess.getIdInternal();
      }
      if (this.container.getLogger().isDebugEnabled()) {
        this.container.getLogger().debug("newsessionId: " + newsessionId);
      }
      if (newsessionId != null) {
        if ((manager instanceof PersistentManager))
        {
          Session session = manager.findSession(newsessionId);
          Store store = ((PersistentManager)manager).getStore();
          if ((store != null) && (session != null) && (session.isValid()) && (!isSessionStale(session, System.currentTimeMillis())))
          {
            store.save(session);
            ((PersistentManager)manager).removeSuper(session);
            session.recycle();
          }
          else if (this.container.getLogger().isDebugEnabled())
          {
            this.container.getLogger().debug("newsessionId store: " + store + " session: " + session + " valid: " + (session == null ? "N/A" : Boolean.toString(session.isValid())) + " stale: " + isSessionStale(session, System.currentTimeMillis()));
          }
        }
        else if (this.container.getLogger().isDebugEnabled())
        {
          this.container.getLogger().debug("newsessionId Manager: " + manager);
        }
      }
    }
  }
  
  protected boolean isSessionStale(Session session, long timeNow)
  {
    if (session != null)
    {
      int maxInactiveInterval = session.getMaxInactiveInterval();
      if (maxInactiveInterval >= 0)
      {
        int timeIdle = (int)((timeNow - session.getThisAccessedTime()) / 1000L);
        if (timeIdle >= maxInactiveInterval) {
          return true;
        }
      }
    }
    return false;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\PersistentValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */