package org.apache.catalina.valves;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import javax.servlet.ServletException;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class StuckThreadDetectionValve
  extends ValveBase
{
  private static final String info = "org.apache.catalina.valves.StuckThreadDetectionValve/1.0";
  private static final Log log = LogFactory.getLog(StuckThreadDetectionValve.class);
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.valves");
  private final AtomicInteger stuckCount = new AtomicInteger(0);
  private AtomicLong interruptedThreadsCount = new AtomicLong();
  private int threshold = 600;
  private int interruptThreadThreshold;
  private final ConcurrentHashMap<Long, MonitoredThread> activeThreads = new ConcurrentHashMap();
  private final Queue<CompletedStuckThread> completedStuckThreadsQueue = new ConcurrentLinkedQueue();
  
  public void setThreshold(int threshold)
  {
    this.threshold = threshold;
  }
  
  public int getThreshold()
  {
    return this.threshold;
  }
  
  public int getInterruptThreadThreshold()
  {
    return this.interruptThreadThreshold;
  }
  
  public void setInterruptThreadThreshold(int interruptThreadThreshold)
  {
    this.interruptThreadThreshold = interruptThreadThreshold;
  }
  
  public StuckThreadDetectionValve()
  {
    super(true);
  }
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    if (log.isDebugEnabled()) {
      log.debug("Monitoring stuck threads with threshold = " + this.threshold + " sec");
    }
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.StuckThreadDetectionValve/1.0";
  }
  
  private void notifyStuckThreadDetected(MonitoredThread monitoredThread, long activeTime, int numStuckThreads)
  {
    if (log.isWarnEnabled())
    {
      String msg = sm.getString("stuckThreadDetectionValve.notifyStuckThreadDetected", new Object[] { monitoredThread.getThread().getName(), Long.valueOf(activeTime), monitoredThread.getStartTime(), Integer.valueOf(numStuckThreads), monitoredThread.getRequestUri(), Integer.valueOf(this.threshold), String.valueOf(monitoredThread.getThread().getId()) });
      
      Throwable th = new Throwable();
      th.setStackTrace(monitoredThread.getThread().getStackTrace());
      log.warn(msg, th);
    }
  }
  
  private void notifyStuckThreadCompleted(CompletedStuckThread thread, int numStuckThreads)
  {
    if (log.isWarnEnabled())
    {
      String msg = sm.getString("stuckThreadDetectionValve.notifyStuckThreadCompleted", new Object[] { thread.getName(), Long.valueOf(thread.getTotalActiveTime()), Integer.valueOf(numStuckThreads), String.valueOf(thread.getId()) });
      
      log.warn(msg);
    }
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    if (this.threshold <= 0)
    {
      getNext().invoke(request, response);
      return;
    }
    Long key = Long.valueOf(Thread.currentThread().getId());
    StringBuffer requestUrl = request.getRequestURL();
    if (request.getQueryString() != null)
    {
      requestUrl.append("?");
      requestUrl.append(request.getQueryString());
    }
    MonitoredThread monitoredThread = new MonitoredThread(Thread.currentThread(), requestUrl.toString(), this.interruptThreadThreshold > 0);
    
    this.activeThreads.put(key, monitoredThread);
    try
    {
      getNext().invoke(request, response);
    }
    finally
    {
      this.activeThreads.remove(key);
      if (monitoredThread.markAsDone() == MonitoredThreadState.STUCK)
      {
        if (monitoredThread.wasInterrupted()) {
          this.interruptedThreadsCount.incrementAndGet();
        }
        this.completedStuckThreadsQueue.add(new CompletedStuckThread(monitoredThread.getThread(), monitoredThread.getActiveTimeInMillis()));
      }
    }
  }
  
  public void backgroundProcess()
  {
    super.backgroundProcess();
    
    long thresholdInMillis = this.threshold * 1000L;
    for (MonitoredThread monitoredThread : this.activeThreads.values())
    {
      long activeTime = monitoredThread.getActiveTimeInMillis();
      if ((activeTime >= thresholdInMillis) && (monitoredThread.markAsStuckIfStillRunning()))
      {
        int numStuckThreads = this.stuckCount.incrementAndGet();
        notifyStuckThreadDetected(monitoredThread, activeTime, numStuckThreads);
      }
      if ((this.interruptThreadThreshold > 0) && (activeTime >= this.interruptThreadThreshold * 1000L)) {
        monitoredThread.interruptIfStuck(this.interruptThreadThreshold);
      }
    }
    for (CompletedStuckThread completedStuckThread = (CompletedStuckThread)this.completedStuckThreadsQueue.poll(); completedStuckThread != null; completedStuckThread = (CompletedStuckThread)this.completedStuckThreadsQueue.poll())
    {
      int numStuckThreads = this.stuckCount.decrementAndGet();
      notifyStuckThreadCompleted(completedStuckThread, numStuckThreads);
    }
  }
  
  public int getStuckThreadCount()
  {
    return this.stuckCount.get();
  }
  
  public long[] getStuckThreadIds()
  {
    List<Long> idList = new ArrayList();
    for (MonitoredThread monitoredThread : this.activeThreads.values()) {
      if (monitoredThread.isMarkedAsStuck()) {
        idList.add(Long.valueOf(monitoredThread.getThread().getId()));
      }
    }
    long[] result = new long[idList.size()];
    for (int i = 0; i < result.length; i++) {
      result[i] = ((Long)idList.get(i)).longValue();
    }
    return result;
  }
  
  public String[] getStuckThreadNames()
  {
    List<String> nameList = new ArrayList();
    for (MonitoredThread monitoredThread : this.activeThreads.values()) {
      if (monitoredThread.isMarkedAsStuck()) {
        nameList.add(monitoredThread.getThread().getName());
      }
    }
    return (String[])nameList.toArray(new String[nameList.size()]);
  }
  
  public long getInterruptedThreadsCount()
  {
    return this.interruptedThreadsCount.get();
  }
  
  private static class MonitoredThread
  {
    private final Thread thread;
    private final String requestUri;
    private final long start;
    private final AtomicInteger state = new AtomicInteger(StuckThreadDetectionValve.MonitoredThreadState.RUNNING.ordinal());
    private final Semaphore interruptionSemaphore;
    private boolean interrupted;
    
    public MonitoredThread(Thread thread, String requestUri, boolean interruptible)
    {
      this.thread = thread;
      this.requestUri = requestUri;
      this.start = System.currentTimeMillis();
      if (interruptible) {
        this.interruptionSemaphore = new Semaphore(1);
      } else {
        this.interruptionSemaphore = null;
      }
    }
    
    public Thread getThread()
    {
      return this.thread;
    }
    
    public String getRequestUri()
    {
      return this.requestUri;
    }
    
    public long getActiveTimeInMillis()
    {
      return System.currentTimeMillis() - this.start;
    }
    
    public Date getStartTime()
    {
      return new Date(this.start);
    }
    
    public boolean markAsStuckIfStillRunning()
    {
      return this.state.compareAndSet(StuckThreadDetectionValve.MonitoredThreadState.RUNNING.ordinal(), StuckThreadDetectionValve.MonitoredThreadState.STUCK.ordinal());
    }
    
    public StuckThreadDetectionValve.MonitoredThreadState markAsDone()
    {
      int val = this.state.getAndSet(StuckThreadDetectionValve.MonitoredThreadState.DONE.ordinal());
      StuckThreadDetectionValve.MonitoredThreadState threadState = StuckThreadDetectionValve.MonitoredThreadState.values()[val];
      if ((threadState == StuckThreadDetectionValve.MonitoredThreadState.STUCK) && (this.interruptionSemaphore != null)) {
        try
        {
          this.interruptionSemaphore.acquire();
        }
        catch (InterruptedException e)
        {
          StuckThreadDetectionValve.log.debug("thread interrupted after the request is finished, ignoring", e);
        }
      }
      return threadState;
    }
    
    boolean isMarkedAsStuck()
    {
      return this.state.get() == StuckThreadDetectionValve.MonitoredThreadState.STUCK.ordinal();
    }
    
    public boolean interruptIfStuck(long interruptThreadThreshold)
    {
      if ((!isMarkedAsStuck()) || (this.interruptionSemaphore == null) || (!this.interruptionSemaphore.tryAcquire())) {
        return false;
      }
      try
      {
        if (StuckThreadDetectionValve.log.isWarnEnabled())
        {
          String msg = StuckThreadDetectionValve.sm.getString("stuckThreadDetectionValve.notifyStuckThreadInterrupted", new Object[] { getThread().getName(), Long.valueOf(getActiveTimeInMillis()), getStartTime(), getRequestUri(), Long.valueOf(interruptThreadThreshold), String.valueOf(getThread().getId()) });
          
          Throwable th = new Throwable();
          th.setStackTrace(getThread().getStackTrace());
          StuckThreadDetectionValve.log.warn(msg, th);
        }
        this.thread.interrupt();
      }
      finally
      {
        this.interrupted = true;
        this.interruptionSemaphore.release();
      }
      return true;
    }
    
    public boolean wasInterrupted()
    {
      return this.interrupted;
    }
  }
  
  private static class CompletedStuckThread
  {
    private final String threadName;
    private final long threadId;
    private final long totalActiveTime;
    
    public CompletedStuckThread(Thread thread, long totalActiveTime)
    {
      this.threadName = thread.getName();
      this.threadId = thread.getId();
      this.totalActiveTime = totalActiveTime;
    }
    
    public String getName()
    {
      return this.threadName;
    }
    
    public long getId()
    {
      return this.threadId;
    }
    
    public long getTotalActiveTime()
    {
      return this.totalActiveTime;
    }
  }
  
  private static enum MonitoredThreadState
  {
    RUNNING,  STUCK,  DONE;
    
    private MonitoredThreadState() {}
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\StuckThreadDetectionValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */