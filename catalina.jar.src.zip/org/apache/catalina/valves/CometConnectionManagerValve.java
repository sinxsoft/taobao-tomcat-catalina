package org.apache.catalina.valves;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleEvent;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Valve;
import org.apache.catalina.Wrapper;
import org.apache.catalina.comet.CometEvent.EventSubType;
import org.apache.catalina.comet.CometEvent.EventType;
import org.apache.catalina.comet.CometProcessor;
import org.apache.catalina.connector.CometEventImpl;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.res.StringManager;

public class CometConnectionManagerValve
  extends ValveBase
  implements HttpSessionListener, LifecycleListener
{
  protected static final String info = "org.apache.catalina.valves.CometConnectionManagerValve/1.0";
  
  public CometConnectionManagerValve()
  {
    super(false);
  }
  
  protected final List<Request> cometRequests = Collections.synchronizedList(new ArrayList());
  protected final String cometRequestsAttribute = "org.apache.tomcat.comet.connectionList";
  
  protected synchronized void startInternal()
    throws LifecycleException
  {
    if ((this.container instanceof Context)) {
      this.container.addLifecycleListener(this);
    }
    setState(LifecycleState.STARTING);
  }
  
  protected synchronized void stopInternal()
    throws LifecycleException
  {
    setState(LifecycleState.STOPPING);
    if ((this.container instanceof Context)) {
      this.container.removeLifecycleListener(this);
    }
  }
  
  public void lifecycleEvent(LifecycleEvent event)
  {
    if ("before_stop".equals(event.getType()))
    {
      Iterator<Request> iterator = this.cometRequests.iterator();
      for (;;)
      {
        if (iterator.hasNext())
        {
          Request request = (Request)iterator.next();
          
          HttpSession session = request.getSession(false);
          if (session != null) {
            session.removeAttribute("org.apache.tomcat.comet.connectionList");
          }
          CometEventImpl cometEvent = request.getEvent();
          try
          {
            cometEvent.setEventType(CometEvent.EventType.END);
            cometEvent.setEventSubType(CometEvent.EventSubType.WEBAPP_RELOAD);
            
            getNext().event(request, request.getResponse(), cometEvent);
            try
            {
              cometEvent.close();
            }
            catch (IOException e)
            {
              this.container.getLogger().warn(sm.getString("cometConnectionManagerValve.event"), e);
            }
          }
          catch (Exception e)
          {
            this.container.getLogger().warn(sm.getString("cometConnectionManagerValve.event"), e);
          }
          finally
          {
            try
            {
              cometEvent.close();
            }
            catch (IOException e)
            {
              this.container.getLogger().warn(sm.getString("cometConnectionManagerValve.event"), e);
            }
          }
        }
      }
      this.cometRequests.clear();
    }
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.CometConnectionManagerValve/1.0";
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    getNext().invoke(request, response);
    if ((request.isComet()) && (!response.isClosed()))
    {
      HttpSession session = request.getSession(true);
      
      this.cometRequests.add(request);
      synchronized (session)
      {
        Request[] requests = (Request[])session.getAttribute("org.apache.tomcat.comet.connectionList");
        if (requests == null)
        {
          requests = new Request[1];
          requests[0] = request;
          session.setAttribute("org.apache.tomcat.comet.connectionList", requests);
        }
        else
        {
          Request[] newRequests = new Request[requests.length + 1];
          for (int i = 0; i < requests.length; i++) {
            newRequests[i] = requests[i];
          }
          newRequests[requests.length] = request;
          session.setAttribute("org.apache.tomcat.comet.connectionList", newRequests);
        }
      }
    }
  }
  
  /* Error */
  public void event(Request request, Response response, org.apache.catalina.comet.CometEvent event)
    throws IOException, ServletException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore 4
    //   3: aload_0
    //   4: invokevirtual 29	org/apache/catalina/valves/CometConnectionManagerValve:getNext	()Lorg/apache/catalina/Valve;
    //   7: aload_1
    //   8: aload_2
    //   9: aload_3
    //   10: invokeinterface 31 4 0
    //   15: iconst_1
    //   16: istore 4
    //   18: iload 4
    //   20: ifeq +46 -> 66
    //   23: aload_2
    //   24: invokevirtual 44	org/apache/catalina/connector/Response:isClosed	()Z
    //   27: ifne +39 -> 66
    //   30: aload_3
    //   31: invokeinterface 49 1 0
    //   36: getstatic 25	org/apache/catalina/comet/CometEvent$EventType:END	Lorg/apache/catalina/comet/CometEvent$EventType;
    //   39: if_acmpeq +27 -> 66
    //   42: aload_3
    //   43: invokeinterface 49 1 0
    //   48: getstatic 50	org/apache/catalina/comet/CometEvent$EventType:ERROR	Lorg/apache/catalina/comet/CometEvent$EventType;
    //   51: if_acmpne +493 -> 544
    //   54: aload_3
    //   55: invokeinterface 51 1 0
    //   60: getstatic 52	org/apache/catalina/comet/CometEvent$EventSubType:TIMEOUT	Lorg/apache/catalina/comet/CometEvent$EventSubType;
    //   63: if_acmpeq +481 -> 544
    //   66: aload_0
    //   67: getfield 5	org/apache/catalina/valves/CometConnectionManagerValve:cometRequests	Ljava/util/List;
    //   70: aload_1
    //   71: invokeinterface 53 2 0
    //   76: pop
    //   77: aload_1
    //   78: iconst_0
    //   79: invokevirtual 22	org/apache/catalina/connector/Request:getSession	(Z)Ljavax/servlet/http/HttpSession;
    //   82: astore 5
    //   84: aload 5
    //   86: ifnull +191 -> 277
    //   89: aload 5
    //   91: dup
    //   92: astore 6
    //   94: monitorenter
    //   95: aconst_null
    //   96: astore 7
    //   98: aload 5
    //   100: ldc 6
    //   102: invokeinterface 46 2 0
    //   107: checkcast 47	[Lorg/apache/catalina/connector/Request;
    //   110: checkcast 47	[Lorg/apache/catalina/connector/Request;
    //   113: astore 7
    //   115: goto +5 -> 120
    //   118: astore 8
    //   120: aload 7
    //   122: ifnull +141 -> 263
    //   125: iconst_0
    //   126: istore 8
    //   128: iconst_0
    //   129: istore 9
    //   131: iload 8
    //   133: ifne +33 -> 166
    //   136: iload 9
    //   138: aload 7
    //   140: arraylength
    //   141: if_icmpge +25 -> 166
    //   144: aload 7
    //   146: iload 9
    //   148: aaload
    //   149: aload_1
    //   150: if_acmpne +7 -> 157
    //   153: iconst_1
    //   154: goto +4 -> 158
    //   157: iconst_0
    //   158: istore 8
    //   160: iinc 9 1
    //   163: goto -32 -> 131
    //   166: iload 8
    //   168: ifeq +95 -> 263
    //   171: aload 7
    //   173: arraylength
    //   174: iconst_1
    //   175: if_icmple +74 -> 249
    //   178: aload 7
    //   180: arraylength
    //   181: iconst_1
    //   182: isub
    //   183: anewarray 21	org/apache/catalina/connector/Request
    //   186: astore 9
    //   188: iconst_0
    //   189: istore 10
    //   191: iconst_0
    //   192: istore 11
    //   194: iload 11
    //   196: aload 7
    //   198: arraylength
    //   199: if_icmpge +31 -> 230
    //   202: aload 7
    //   204: iload 11
    //   206: aaload
    //   207: aload_1
    //   208: if_acmpeq +16 -> 224
    //   211: aload 9
    //   213: iload 10
    //   215: iinc 10 1
    //   218: aload 7
    //   220: iload 11
    //   222: aaload
    //   223: aastore
    //   224: iinc 11 1
    //   227: goto -33 -> 194
    //   230: aload 5
    //   232: ldc 6
    //   234: aload 9
    //   236: invokeinterface 48 3 0
    //   241: goto +5 -> 246
    //   244: astore 11
    //   246: goto +17 -> 263
    //   249: aload 5
    //   251: ldc 6
    //   253: invokeinterface 23 2 0
    //   258: goto +5 -> 263
    //   261: astore 9
    //   263: aload 6
    //   265: monitorexit
    //   266: goto +11 -> 277
    //   269: astore 12
    //   271: aload 6
    //   273: monitorexit
    //   274: aload 12
    //   276: athrow
    //   277: goto +267 -> 544
    //   280: astore 13
    //   282: iload 4
    //   284: ifeq +46 -> 330
    //   287: aload_2
    //   288: invokevirtual 44	org/apache/catalina/connector/Response:isClosed	()Z
    //   291: ifne +39 -> 330
    //   294: aload_3
    //   295: invokeinterface 49 1 0
    //   300: getstatic 25	org/apache/catalina/comet/CometEvent$EventType:END	Lorg/apache/catalina/comet/CometEvent$EventType;
    //   303: if_acmpeq +27 -> 330
    //   306: aload_3
    //   307: invokeinterface 49 1 0
    //   312: getstatic 50	org/apache/catalina/comet/CometEvent$EventType:ERROR	Lorg/apache/catalina/comet/CometEvent$EventType;
    //   315: if_acmpne +226 -> 541
    //   318: aload_3
    //   319: invokeinterface 51 1 0
    //   324: getstatic 52	org/apache/catalina/comet/CometEvent$EventSubType:TIMEOUT	Lorg/apache/catalina/comet/CometEvent$EventSubType;
    //   327: if_acmpeq +214 -> 541
    //   330: aload_0
    //   331: getfield 5	org/apache/catalina/valves/CometConnectionManagerValve:cometRequests	Ljava/util/List;
    //   334: aload_1
    //   335: invokeinterface 53 2 0
    //   340: pop
    //   341: aload_1
    //   342: iconst_0
    //   343: invokevirtual 22	org/apache/catalina/connector/Request:getSession	(Z)Ljavax/servlet/http/HttpSession;
    //   346: astore 14
    //   348: aload 14
    //   350: ifnull +191 -> 541
    //   353: aload 14
    //   355: dup
    //   356: astore 15
    //   358: monitorenter
    //   359: aconst_null
    //   360: astore 16
    //   362: aload 14
    //   364: ldc 6
    //   366: invokeinterface 46 2 0
    //   371: checkcast 47	[Lorg/apache/catalina/connector/Request;
    //   374: checkcast 47	[Lorg/apache/catalina/connector/Request;
    //   377: astore 16
    //   379: goto +5 -> 384
    //   382: astore 17
    //   384: aload 16
    //   386: ifnull +141 -> 527
    //   389: iconst_0
    //   390: istore 17
    //   392: iconst_0
    //   393: istore 18
    //   395: iload 17
    //   397: ifne +33 -> 430
    //   400: iload 18
    //   402: aload 16
    //   404: arraylength
    //   405: if_icmpge +25 -> 430
    //   408: aload 16
    //   410: iload 18
    //   412: aaload
    //   413: aload_1
    //   414: if_acmpne +7 -> 421
    //   417: iconst_1
    //   418: goto +4 -> 422
    //   421: iconst_0
    //   422: istore 17
    //   424: iinc 18 1
    //   427: goto -32 -> 395
    //   430: iload 17
    //   432: ifeq +95 -> 527
    //   435: aload 16
    //   437: arraylength
    //   438: iconst_1
    //   439: if_icmple +74 -> 513
    //   442: aload 16
    //   444: arraylength
    //   445: iconst_1
    //   446: isub
    //   447: anewarray 21	org/apache/catalina/connector/Request
    //   450: astore 18
    //   452: iconst_0
    //   453: istore 19
    //   455: iconst_0
    //   456: istore 20
    //   458: iload 20
    //   460: aload 16
    //   462: arraylength
    //   463: if_icmpge +31 -> 494
    //   466: aload 16
    //   468: iload 20
    //   470: aaload
    //   471: aload_1
    //   472: if_acmpeq +16 -> 488
    //   475: aload 18
    //   477: iload 19
    //   479: iinc 19 1
    //   482: aload 16
    //   484: iload 20
    //   486: aaload
    //   487: aastore
    //   488: iinc 20 1
    //   491: goto -33 -> 458
    //   494: aload 14
    //   496: ldc 6
    //   498: aload 18
    //   500: invokeinterface 48 3 0
    //   505: goto +5 -> 510
    //   508: astore 20
    //   510: goto +17 -> 527
    //   513: aload 14
    //   515: ldc 6
    //   517: invokeinterface 23 2 0
    //   522: goto +5 -> 527
    //   525: astore 18
    //   527: aload 15
    //   529: monitorexit
    //   530: goto +11 -> 541
    //   533: astore 21
    //   535: aload 15
    //   537: monitorexit
    //   538: aload 21
    //   540: athrow
    //   541: aload 13
    //   543: athrow
    //   544: return
    // Line number table:
    //   Java source line #232	-> byte code offset #0
    //   Java source line #234	-> byte code offset #3
    //   Java source line #235	-> byte code offset #15
    //   Java source line #237	-> byte code offset #18
    //   Java source line #244	-> byte code offset #66
    //   Java source line #249	-> byte code offset #77
    //   Java source line #250	-> byte code offset #84
    //   Java source line #251	-> byte code offset #89
    //   Java source line #252	-> byte code offset #95
    //   Java source line #254	-> byte code offset #98
    //   Java source line #259	-> byte code offset #115
    //   Java source line #256	-> byte code offset #118
    //   Java source line #260	-> byte code offset #120
    //   Java source line #261	-> byte code offset #125
    //   Java source line #262	-> byte code offset #128
    //   Java source line #263	-> byte code offset #144
    //   Java source line #262	-> byte code offset #160
    //   Java source line #265	-> byte code offset #166
    //   Java source line #266	-> byte code offset #171
    //   Java source line #267	-> byte code offset #178
    //   Java source line #269	-> byte code offset #188
    //   Java source line #270	-> byte code offset #191
    //   Java source line #271	-> byte code offset #202
    //   Java source line #272	-> byte code offset #211
    //   Java source line #270	-> byte code offset #224
    //   Java source line #276	-> byte code offset #230
    //   Java source line #282	-> byte code offset #241
    //   Java source line #279	-> byte code offset #244
    //   Java source line #283	-> byte code offset #246
    //   Java source line #285	-> byte code offset #249
    //   Java source line #290	-> byte code offset #258
    //   Java source line #287	-> byte code offset #261
    //   Java source line #294	-> byte code offset #263
    //   Java source line #296	-> byte code offset #277
    //   Java source line #237	-> byte code offset #280
    //   Java source line #244	-> byte code offset #330
    //   Java source line #249	-> byte code offset #341
    //   Java source line #250	-> byte code offset #348
    //   Java source line #251	-> byte code offset #353
    //   Java source line #252	-> byte code offset #359
    //   Java source line #254	-> byte code offset #362
    //   Java source line #259	-> byte code offset #379
    //   Java source line #256	-> byte code offset #382
    //   Java source line #260	-> byte code offset #384
    //   Java source line #261	-> byte code offset #389
    //   Java source line #262	-> byte code offset #392
    //   Java source line #263	-> byte code offset #408
    //   Java source line #262	-> byte code offset #424
    //   Java source line #265	-> byte code offset #430
    //   Java source line #266	-> byte code offset #435
    //   Java source line #267	-> byte code offset #442
    //   Java source line #269	-> byte code offset #452
    //   Java source line #270	-> byte code offset #455
    //   Java source line #271	-> byte code offset #466
    //   Java source line #272	-> byte code offset #475
    //   Java source line #270	-> byte code offset #488
    //   Java source line #276	-> byte code offset #494
    //   Java source line #282	-> byte code offset #505
    //   Java source line #279	-> byte code offset #508
    //   Java source line #283	-> byte code offset #510
    //   Java source line #285	-> byte code offset #513
    //   Java source line #290	-> byte code offset #522
    //   Java source line #287	-> byte code offset #525
    //   Java source line #294	-> byte code offset #527
    //   Java source line #296	-> byte code offset #541
    //   Java source line #299	-> byte code offset #544
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	545	0	this	CometConnectionManagerValve
    //   0	545	1	request	Request
    //   0	545	2	response	Response
    //   0	545	3	event	org.apache.catalina.comet.CometEvent
    //   1	282	4	ok	boolean
    //   82	168	5	session	HttpSession
    //   96	123	7	reqs	Request[]
    //   118	3	8	ise	IllegalStateException
    //   126	41	8	found	boolean
    //   129	32	9	i	int
    //   186	49	9	newConnectionInfos	Request[]
    //   261	3	9	ise	IllegalStateException
    //   189	25	10	pos	int
    //   192	33	11	i	int
    //   244	3	11	ise	IllegalStateException
    //   269	6	12	localObject1	Object
    //   280	262	13	localObject2	Object
    //   346	168	14	session	HttpSession
    //   360	123	16	reqs	Request[]
    //   382	3	17	ise	IllegalStateException
    //   390	41	17	found	boolean
    //   393	32	18	i	int
    //   450	49	18	newConnectionInfos	Request[]
    //   525	3	18	ise	IllegalStateException
    //   453	25	19	pos	int
    //   456	33	20	i	int
    //   508	3	20	ise	IllegalStateException
    //   533	6	21	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   98	115	118	java/lang/IllegalStateException
    //   230	241	244	java/lang/IllegalStateException
    //   249	258	261	java/lang/IllegalStateException
    //   95	266	269	finally
    //   269	274	269	finally
    //   3	18	280	finally
    //   280	282	280	finally
    //   362	379	382	java/lang/IllegalStateException
    //   494	505	508	java/lang/IllegalStateException
    //   513	522	525	java/lang/IllegalStateException
    //   359	530	533	finally
    //   533	538	533	finally
  }
  
  public void sessionCreated(HttpSessionEvent se) {}
  
  public void sessionDestroyed(HttpSessionEvent se)
  {
    Request[] reqs = (Request[])se.getSession().getAttribute("org.apache.tomcat.comet.connectionList");
    if (reqs != null) {
      for (int i = 0; i < reqs.length; i++)
      {
        Request req = reqs[i];
        try
        {
          CometEventImpl event = req.getEvent();
          event.setEventType(CometEvent.EventType.END);
          event.setEventSubType(CometEvent.EventSubType.SESSION_END);
          ((CometProcessor)req.getWrapper().getServlet()).event(event);
          
          event.close();
        }
        catch (Exception e)
        {
          req.getWrapper().getParent().getLogger().warn(sm.getString("cometConnectionManagerValve.listenerEvent"), e);
        }
      }
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\CometConnectionManagerValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */