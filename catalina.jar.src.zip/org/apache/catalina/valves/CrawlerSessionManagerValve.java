package org.apache.catalina.valves;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class CrawlerSessionManagerValve
  extends ValveBase
  implements HttpSessionBindingListener
{
  private static final Log log = LogFactory.getLog(CrawlerSessionManagerValve.class);
  private final Map<String, String> clientIpSessionId = new ConcurrentHashMap();
  private final Map<String, String> sessionIdClientIp = new ConcurrentHashMap();
  private String crawlerUserAgents = ".*[bB]ot.*|.*Yahoo! Slurp.*|.*Feedfetcher-Google.*";
  private Pattern uaPattern = null;
  private int sessionInactiveInterval = 60;
  
  public CrawlerSessionManagerValve()
  {
    super(true);
  }
  
  public void setCrawlerUserAgents(String crawlerUserAgents)
  {
    this.crawlerUserAgents = crawlerUserAgents;
    if ((crawlerUserAgents == null) || (crawlerUserAgents.length() == 0)) {
      this.uaPattern = null;
    } else {
      this.uaPattern = Pattern.compile(crawlerUserAgents);
    }
  }
  
  public String getCrawlerUserAgents()
  {
    return this.crawlerUserAgents;
  }
  
  public void setSessionInactiveInterval(int sessionInactiveInterval)
  {
    this.sessionInactiveInterval = sessionInactiveInterval;
  }
  
  public int getSessionInactiveInterval()
  {
    return this.sessionInactiveInterval;
  }
  
  public Map<String, String> getClientIpSessionId()
  {
    return this.clientIpSessionId;
  }
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    
    this.uaPattern = Pattern.compile(this.crawlerUserAgents);
  }
  
  public void invoke(Request request, Response response)
    throws IOException, ServletException
  {
    boolean isBot = false;
    String sessionId = null;
    String clientIp = null;
    if (log.isDebugEnabled()) {
      log.debug(request.hashCode() + ": ClientIp=" + request.getRemoteAddr() + ", RequestedSessionId=" + request.getRequestedSessionId());
    }
    if (request.getSession(false) == null)
    {
      Enumeration<String> uaHeaders = request.getHeaders("user-agent");
      String uaHeader = null;
      if (uaHeaders.hasMoreElements()) {
        uaHeader = (String)uaHeaders.nextElement();
      }
      if ((uaHeader != null) && (!uaHeaders.hasMoreElements()))
      {
        if (log.isDebugEnabled()) {
          log.debug(request.hashCode() + ": UserAgent=" + uaHeader);
        }
        if (this.uaPattern.matcher(uaHeader).matches())
        {
          isBot = true;
          if (log.isDebugEnabled()) {
            log.debug(request.hashCode() + ": Bot found. UserAgent=" + uaHeader);
          }
        }
      }
      if (isBot)
      {
        clientIp = request.getRemoteAddr();
        sessionId = (String)this.clientIpSessionId.get(clientIp);
        if (sessionId != null)
        {
          request.setRequestedSessionId(sessionId);
          if (log.isDebugEnabled()) {
            log.debug(request.hashCode() + ": SessionID=" + sessionId);
          }
        }
      }
    }
    getNext().invoke(request, response);
    if (isBot) {
      if (sessionId == null)
      {
        HttpSession s = request.getSession(false);
        if (s != null)
        {
          this.clientIpSessionId.put(clientIp, s.getId());
          this.sessionIdClientIp.put(s.getId(), clientIp);
          
          s.setAttribute(getClass().getName(), this);
          s.setMaxInactiveInterval(this.sessionInactiveInterval);
          if (log.isDebugEnabled()) {
            log.debug(request.hashCode() + ": New bot session. SessionID=" + s.getId());
          }
        }
      }
      else if (log.isDebugEnabled())
      {
        log.debug(request.hashCode() + ": Bot session accessed. SessionID=" + sessionId);
      }
    }
  }
  
  public void valueBound(HttpSessionBindingEvent event) {}
  
  public void valueUnbound(HttpSessionBindingEvent event)
  {
    String clientIp = (String)this.sessionIdClientIp.remove(event.getSession().getId());
    if (clientIp != null) {
      this.clientIpSessionId.remove(clientIp);
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\CrawlerSessionManagerValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */