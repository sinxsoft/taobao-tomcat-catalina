package org.apache.catalina.valves;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.Valve;
import org.apache.catalina.connector.Response;
import org.apache.tomcat.util.buf.MessageBytes;
import org.apache.tomcat.util.http.MimeHeaders;
import org.apache.tomcat.util.res.StringManager;

public abstract class RequestFilterValve
  extends ValveBase
{
  private static final String info = "org.apache.catalina.valves.RequestFilterValve/1.0";
  
  public RequestFilterValve()
  {
    super(true);
  }
  
  protected volatile Pattern allow = null;
  protected volatile String allowValue = null;
  protected volatile boolean allowValid = true;
  protected volatile Pattern deny = null;
  protected volatile String denyValue = null;
  protected volatile boolean denyValid = true;
  protected int denyStatus = 403;
  private boolean invalidAuthenticationWhenDeny = false;
  
  public String getAllow()
  {
    return this.allowValue;
  }
  
  public void setAllow(String allow)
  {
    if ((allow == null) || (allow.length() == 0))
    {
      this.allow = null;
      this.allowValue = null;
      this.allowValid = true;
    }
    else
    {
      boolean success = false;
      try
      {
        this.allowValue = allow;
        this.allow = Pattern.compile(allow);
        success = true;
      }
      finally
      {
        this.allowValid = success;
      }
    }
  }
  
  public String getDeny()
  {
    return this.denyValue;
  }
  
  public void setDeny(String deny)
  {
    if ((deny == null) || (deny.length() == 0))
    {
      this.deny = null;
      this.denyValue = null;
      this.denyValid = true;
    }
    else
    {
      boolean success = false;
      try
      {
        this.denyValue = deny;
        this.deny = Pattern.compile(deny);
        success = true;
      }
      finally
      {
        this.denyValid = success;
      }
    }
  }
  
  public final boolean isAllowValid()
  {
    return this.allowValid;
  }
  
  public final boolean isDenyValid()
  {
    return this.denyValid;
  }
  
  public int getDenyStatus()
  {
    return this.denyStatus;
  }
  
  public void setDenyStatus(int denyStatus)
  {
    this.denyStatus = denyStatus;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.RequestFilterValve/1.0";
  }
  
  public boolean getInvalidAuthenticationWhenDeny()
  {
    return this.invalidAuthenticationWhenDeny;
  }
  
  public void setInvalidAuthenticationWhenDeny(boolean value)
  {
    this.invalidAuthenticationWhenDeny = value;
  }
  
  public abstract void invoke(org.apache.catalina.connector.Request paramRequest, Response paramResponse)
    throws IOException, ServletException;
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    if ((!this.allowValid) || (!this.denyValid)) {
      throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
    }
  }
  
  protected synchronized void startInternal()
    throws LifecycleException
  {
    if ((!this.allowValid) || (!this.denyValid)) {
      throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
    }
    super.startInternal();
  }
  
  protected void process(String property, org.apache.catalina.connector.Request request, Response response)
    throws IOException, ServletException
  {
    if (isAllowed(property))
    {
      getNext().invoke(request, response);
      return;
    }
    denyRequest(request, response);
  }
  
  protected void denyRequest(org.apache.catalina.connector.Request request, Response response)
    throws IOException, ServletException
  {
    if (this.invalidAuthenticationWhenDeny)
    {
      Context context = request.getContext();
      if ((context != null) && (context.getPreemptiveAuthentication()))
      {
        if (request.getCoyoteRequest().getMimeHeaders().getValue("authorization") == null) {
          request.getCoyoteRequest().getMimeHeaders().addValue("authorization").setString("invalid");
        }
        getNext().invoke(request, response);
        return;
      }
    }
    response.sendError(this.denyStatus);
  }
  
  public boolean isAllowed(String property)
  {
    Pattern deny = this.deny;
    Pattern allow = this.allow;
    if ((deny != null) && (deny.matcher(property).matches())) {
      return false;
    }
    if ((allow != null) && (allow.matcher(property).matches())) {
      return true;
    }
    if ((deny != null) && (allow == null)) {
      return true;
    }
    return false;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\RequestFilterValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */