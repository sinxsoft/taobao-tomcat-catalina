package org.apache.catalina.valves;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;
import org.apache.catalina.Context;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.util.ServerInfo;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.ExceptionUtils;

public class ExtendedAccessLogValve
  extends AccessLogValve
{
  private static final Log log = LogFactory.getLog(ExtendedAccessLogValve.class);
  protected static final String extendedAccessLogInfo = "org.apache.catalina.valves.ExtendedAccessLogValve/2.1";
  
  public ExtendedAccessLogValve() {}
  
  public String getInfo()
  {
    return "org.apache.catalina.valves.ExtendedAccessLogValve/2.1";
  }
  
  private String wrap(Object value)
  {
    if ((value == null) || ("-".equals(value))) {
      return "-";
    }
    String svalue;
    try
    {
      svalue = value.toString();
      if ("".equals(svalue)) {
        return "-";
      }
    }
    catch (Throwable e)
    {
      ExceptionUtils.handleThrowable(e);
      
      return "-";
    }
    StringBuilder buffer = new StringBuilder(svalue.length() + 2);
    buffer.append('\'');
    int i = 0;
    while (i < svalue.length())
    {
      int j = svalue.indexOf('\'', i);
      if (j == -1)
      {
        buffer.append(svalue.substring(i));
        i = svalue.length();
      }
      else
      {
        buffer.append(svalue.substring(i, j + 1));
        buffer.append('"');
        i = j + 2;
      }
    }
    buffer.append('\'');
    return buffer.toString();
  }
  
  protected synchronized void open()
  {
    super.open();
    if (this.currentLogFile.length() == 0L)
    {
      this.writer.println("#Fields: " + this.pattern);
      this.writer.println("#Version: 2.0");
      this.writer.println("#Software: " + ServerInfo.getServerInfo());
    }
  }
  
  protected static class DateElement
    implements AccessLogValve.AccessLogElement
  {
    private static final long INTERVAL = 86400000L;
    private static final ThreadLocal<ExtendedAccessLogValve.ElementTimestampStruct> currentDate = new ThreadLocal()
    {
      protected ExtendedAccessLogValve.ElementTimestampStruct initialValue()
      {
        return new ExtendedAccessLogValve.ElementTimestampStruct("yyyy-MM-dd");
      }
    };
    
    protected DateElement() {}
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      ExtendedAccessLogValve.ElementTimestampStruct eds = (ExtendedAccessLogValve.ElementTimestampStruct)currentDate.get();
      long millis = eds.currentTimestamp.getTime();
      if ((date.getTime() > millis + 86400000L - 1L) || (date.getTime() < millis))
      {
        eds.currentTimestamp.setTime(date.getTime() - date.getTime() % 86400000L);
        
        eds.currentTimestampString = eds.currentTimestampFormat.format(eds.currentTimestamp);
      }
      buf.append(eds.currentTimestampString);
    }
  }
  
  protected static class TimeElement
    implements AccessLogValve.AccessLogElement
  {
    private static final long INTERVAL = 1000L;
    private static final ThreadLocal<ExtendedAccessLogValve.ElementTimestampStruct> currentTime = new ThreadLocal()
    {
      protected ExtendedAccessLogValve.ElementTimestampStruct initialValue()
      {
        return new ExtendedAccessLogValve.ElementTimestampStruct("HH:mm:ss");
      }
    };
    
    protected TimeElement() {}
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      ExtendedAccessLogValve.ElementTimestampStruct eds = (ExtendedAccessLogValve.ElementTimestampStruct)currentTime.get();
      long millis = eds.currentTimestamp.getTime();
      if ((date.getTime() > millis + 1000L - 1L) || (date.getTime() < millis))
      {
        eds.currentTimestamp.setTime(date.getTime() - date.getTime() % 1000L);
        
        eds.currentTimestampString = eds.currentTimestampFormat.format(eds.currentTimestamp);
      }
      buf.append(eds.currentTimestampString);
    }
  }
  
  protected class RequestHeaderElement
    implements AccessLogValve.AccessLogElement
  {
    private final String header;
    
    public RequestHeaderElement(String header)
    {
      this.header = header;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      buf.append(ExtendedAccessLogValve.this.wrap(request.getHeader(this.header)));
    }
  }
  
  protected class ResponseHeaderElement
    implements AccessLogValve.AccessLogElement
  {
    private final String header;
    
    public ResponseHeaderElement(String header)
    {
      this.header = header;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      buf.append(ExtendedAccessLogValve.this.wrap(response.getHeader(this.header)));
    }
  }
  
  protected class ServletContextElement
    implements AccessLogValve.AccessLogElement
  {
    private final String attribute;
    
    public ServletContextElement(String attribute)
    {
      this.attribute = attribute;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      buf.append(ExtendedAccessLogValve.this.wrap(request.getContext().getServletContext().getAttribute(this.attribute)));
    }
  }
  
  protected class CookieElement
    implements AccessLogValve.AccessLogElement
  {
    private final String name;
    
    public CookieElement(String name)
    {
      this.name = name;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      Cookie[] c = request.getCookies();
      for (int i = 0; (c != null) && (i < c.length); i++) {
        if (this.name.equals(c[i].getName())) {
          buf.append(ExtendedAccessLogValve.this.wrap(c[i].getValue()));
        }
      }
    }
  }
  
  protected class ResponseAllHeaderElement
    implements AccessLogValve.AccessLogElement
  {
    private final String header;
    
    public ResponseAllHeaderElement(String header)
    {
      this.header = header;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      if (null != response)
      {
        Iterator<String> iter = response.getHeaders(this.header).iterator();
        if (iter.hasNext())
        {
          StringBuilder buffer = new StringBuilder();
          boolean first = true;
          while (iter.hasNext())
          {
            if (first) {
              first = false;
            } else {
              buffer.append(",");
            }
            buffer.append((String)iter.next());
          }
          buf.append(ExtendedAccessLogValve.this.wrap(buffer.toString()));
        }
        return;
      }
      buf.append("-");
    }
  }
  
  protected class RequestAttributeElement
    implements AccessLogValve.AccessLogElement
  {
    private final String attribute;
    
    public RequestAttributeElement(String attribute)
    {
      this.attribute = attribute;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      buf.append(ExtendedAccessLogValve.this.wrap(request.getAttribute(this.attribute)));
    }
  }
  
  protected class SessionAttributeElement
    implements AccessLogValve.AccessLogElement
  {
    private final String attribute;
    
    public SessionAttributeElement(String attribute)
    {
      this.attribute = attribute;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      HttpSession session = null;
      if (request != null)
      {
        session = request.getSession(false);
        if (session != null) {
          buf.append(ExtendedAccessLogValve.this.wrap(session.getAttribute(this.attribute)));
        }
      }
    }
  }
  
  protected class RequestParameterElement
    implements AccessLogValve.AccessLogElement
  {
    private final String parameter;
    
    public RequestParameterElement(String parameter)
    {
      this.parameter = parameter;
    }
    
    private String urlEncode(String value)
    {
      if ((null == value) || (value.length() == 0)) {
        return null;
      }
      try
      {
        return URLEncoder.encode(value, "UTF-8");
      }
      catch (UnsupportedEncodingException e) {}
      return null;
    }
    
    public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
    {
      buf.append(ExtendedAccessLogValve.this.wrap(urlEncode(request.getParameter(this.parameter))));
    }
  }
  
  protected static class PatternTokenizer
  {
    private StringReader sr = null;
    private StringBuilder buf = new StringBuilder();
    private boolean ended = false;
    private boolean subToken;
    private boolean parameter;
    
    public PatternTokenizer(String str)
    {
      this.sr = new StringReader(str);
    }
    
    public boolean hasSubToken()
    {
      return this.subToken;
    }
    
    public boolean hasParameter()
    {
      return this.parameter;
    }
    
    public String getToken()
      throws IOException
    {
      if (this.ended) {
        return null;
      }
      String result = null;
      this.subToken = false;
      this.parameter = false;
      
      int c = this.sr.read();
      while (c != -1)
      {
        switch (c)
        {
        case 32: 
          result = this.buf.toString();
          this.buf = new StringBuilder();
          this.buf.append((char)c);
          return result;
        case 45: 
          result = this.buf.toString();
          this.buf = new StringBuilder();
          this.subToken = true;
          return result;
        case 40: 
          result = this.buf.toString();
          this.buf = new StringBuilder();
          this.parameter = true;
          return result;
        case 41: 
          result = this.buf.toString();
          this.buf = new StringBuilder();
          break;
        default: 
          this.buf.append((char)c);
        }
        c = this.sr.read();
      }
      this.ended = true;
      if (this.buf.length() != 0) {
        return this.buf.toString();
      }
      return null;
    }
    
    public String getParameter()
      throws IOException
    {
      if (!this.parameter) {
        return null;
      }
      this.parameter = false;
      int c = this.sr.read();
      while (c != -1)
      {
        if (c == 41)
        {
          String result = this.buf.toString();
          this.buf = new StringBuilder();
          return result;
        }
        this.buf.append((char)c);
        c = this.sr.read();
      }
      return null;
    }
    
    public String getWhiteSpaces()
      throws IOException
    {
      if (isEnded()) {
        return "";
      }
      StringBuilder whiteSpaces = new StringBuilder();
      if (this.buf.length() > 0)
      {
        whiteSpaces.append(this.buf);
        this.buf = new StringBuilder();
      }
      int c = this.sr.read();
      while (Character.isWhitespace((char)c))
      {
        whiteSpaces.append((char)c);
        c = this.sr.read();
      }
      if (c == -1) {
        this.ended = true;
      } else {
        this.buf.append((char)c);
      }
      return whiteSpaces.toString();
    }
    
    public boolean isEnded()
    {
      return this.ended;
    }
    
    public String getRemains()
      throws IOException
    {
      StringBuilder remains = new StringBuilder();
      for (int c = this.sr.read(); c != -1; c = this.sr.read()) {
        remains.append((char)c);
      }
      return remains.toString();
    }
  }
  
  protected AccessLogValve.AccessLogElement[] createLogElements()
  {
    if (log.isDebugEnabled()) {
      log.debug("decodePattern, pattern =" + this.pattern);
    }
    List<AccessLogValve.AccessLogElement> list = new ArrayList();
    
    PatternTokenizer tokenizer = new PatternTokenizer(this.pattern);
    try
    {
      tokenizer.getWhiteSpaces();
      if (tokenizer.isEnded())
      {
        log.info("pattern was just empty or whitespace");
        return null;
      }
      String token = tokenizer.getToken();
      while (token != null)
      {
        if (log.isDebugEnabled()) {
          log.debug("token = " + token);
        }
        AccessLogValve.AccessLogElement element = getLogElement(token, tokenizer);
        if (element == null) {
          break;
        }
        list.add(element);
        String whiteSpaces = tokenizer.getWhiteSpaces();
        if (whiteSpaces.length() > 0) {
          list.add(new AccessLogValve.StringElement(whiteSpaces));
        }
        if (tokenizer.isEnded()) {
          break;
        }
        token = tokenizer.getToken();
      }
      if (log.isDebugEnabled()) {
        log.debug("finished decoding with element size of: " + list.size());
      }
      return (AccessLogValve.AccessLogElement[])list.toArray(new AccessLogValve.AccessLogElement[0]);
    }
    catch (IOException e)
    {
      log.error("parse error", e);
    }
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getLogElement(String token, PatternTokenizer tokenizer)
    throws IOException
  {
    if ("date".equals(token)) {
      return new DateElement();
    }
    if ("time".equals(token))
    {
      if (tokenizer.hasSubToken())
      {
        String nextToken = tokenizer.getToken();
        if ("taken".equals(nextToken)) {
          return new AccessLogValve.ElapsedTimeElement(false);
        }
      }
      else
      {
        return new TimeElement();
      }
    }
    else
    {
      if ("bytes".equals(token)) {
        return new AccessLogValve.ByteSentElement(true);
      }
      if ("cached".equals(token)) {
        return new AccessLogValve.StringElement("-");
      }
      if ("c".equals(token))
      {
        String nextToken = tokenizer.getToken();
        if ("ip".equals(nextToken)) {
          return new AccessLogValve.RemoteAddrElement(this);
        }
        if ("dns".equals(nextToken)) {
          return new AccessLogValve.HostElement(this);
        }
      }
      else if ("s".equals(token))
      {
        String nextToken = tokenizer.getToken();
        if ("ip".equals(nextToken)) {
          return new AccessLogValve.LocalAddrElement();
        }
        if ("dns".equals(nextToken)) {
          new AccessLogValve.AccessLogElement()
          {
            public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
            {
              String value;
              try
              {
                value = InetAddress.getLocalHost().getHostName();
              }
              catch (Throwable e)
              {
                ExceptionUtils.handleThrowable(e);
                value = "localhost";
              }
              buf.append(value);
            }
          };
        }
      }
      else
      {
        if ("cs".equals(token)) {
          return getClientToServerElement(tokenizer);
        }
        if ("sc".equals(token)) {
          return getServerToClientElement(tokenizer);
        }
        if (("sr".equals(token)) || ("rs".equals(token))) {
          return getProxyElement(tokenizer);
        }
        if ("x".equals(token)) {
          return getXParameterElement(tokenizer);
        }
      }
    }
    log.error("unable to decode with rest of chars starting: " + token);
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getClientToServerElement(PatternTokenizer tokenizer)
    throws IOException
  {
    if (tokenizer.hasSubToken())
    {
      String token = tokenizer.getToken();
      if ("method".equals(token)) {
        return new AccessLogValve.MethodElement();
      }
      if ("uri".equals(token)) {
        if (tokenizer.hasSubToken())
        {
          token = tokenizer.getToken();
          if ("stem".equals(token)) {
            return new AccessLogValve.RequestURIElement();
          }
          if ("query".equals(token)) {
            new AccessLogValve.AccessLogElement()
            {
              public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
              {
                String query = request.getQueryString();
                if (query != null) {
                  buf.append(query);
                } else {
                  buf.append('-');
                }
              }
            };
          }
        }
        else
        {
          new AccessLogValve.AccessLogElement()
          {
            public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
            {
              String query = request.getQueryString();
              if (query == null)
              {
                buf.append(request.getRequestURI());
              }
              else
              {
                buf.append(request.getRequestURI());
                buf.append('?');
                buf.append(request.getQueryString());
              }
            }
          };
        }
      }
    }
    else if (tokenizer.hasParameter())
    {
      String parameter = tokenizer.getParameter();
      if (parameter == null)
      {
        log.error("No closing ) found for in decode");
        return null;
      }
      return new RequestHeaderElement(parameter);
    }
    log.error("The next characters couldn't be decoded: " + tokenizer.getRemains());
    
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getServerToClientElement(PatternTokenizer tokenizer)
    throws IOException
  {
    if (tokenizer.hasSubToken())
    {
      String token = tokenizer.getToken();
      if ("status".equals(token)) {
        return new AccessLogValve.HttpStatusCodeElement();
      }
      if ("comment".equals(token)) {
        return new AccessLogValve.StringElement("?");
      }
    }
    else if (tokenizer.hasParameter())
    {
      String parameter = tokenizer.getParameter();
      if (parameter == null)
      {
        log.error("No closing ) found for in decode");
        return null;
      }
      return new ResponseHeaderElement(parameter);
    }
    log.error("The next characters couldn't be decoded: " + tokenizer.getRemains());
    
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getProxyElement(PatternTokenizer tokenizer)
    throws IOException
  {
    String token = null;
    if (tokenizer.hasSubToken())
    {
      tokenizer.getToken();
      return new AccessLogValve.StringElement("-");
    }
    if (tokenizer.hasParameter())
    {
      tokenizer.getParameter();
      return new AccessLogValve.StringElement("-");
    }
    log.error("The next characters couldn't be decoded: " + token);
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getXParameterElement(PatternTokenizer tokenizer)
    throws IOException
  {
    if (!tokenizer.hasSubToken())
    {
      log.error("x param in wrong format. Needs to be 'x-#(...)' read the docs!");
      return null;
    }
    String token = tokenizer.getToken();
    if ("threadname".equals(token)) {
      return new AccessLogValve.ThreadNameElement();
    }
    if (!tokenizer.hasParameter())
    {
      log.error("x param in wrong format. Needs to be 'x-#(...)' read the docs!");
      return null;
    }
    String parameter = tokenizer.getParameter();
    if (parameter == null)
    {
      log.error("No closing ) found for in decode");
      return null;
    }
    if ("A".equals(token)) {
      return new ServletContextElement(parameter);
    }
    if ("C".equals(token)) {
      return new CookieElement(parameter);
    }
    if ("R".equals(token)) {
      return new RequestAttributeElement(parameter);
    }
    if ("S".equals(token)) {
      return new SessionAttributeElement(parameter);
    }
    if ("H".equals(token)) {
      return getServletRequestElement(parameter);
    }
    if ("P".equals(token)) {
      return new RequestParameterElement(parameter);
    }
    if ("O".equals(token)) {
      return new ResponseAllHeaderElement(parameter);
    }
    log.error("x param for servlet request, couldn't decode value: " + token);
    
    return null;
  }
  
  protected AccessLogValve.AccessLogElement getServletRequestElement(String parameter)
  {
    if ("authType".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getAuthType()));
        }
      };
    }
    if ("remoteUser".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getRemoteUser()));
        }
      };
    }
    if ("requestedSessionId".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getRequestedSessionId()));
        }
      };
    }
    if ("requestedSessionIdFromCookie".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap("" + request.isRequestedSessionIdFromCookie()));
        }
      };
    }
    if ("requestedSessionIdValid".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap("" + request.isRequestedSessionIdValid()));
        }
      };
    }
    if ("contentLength".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap("" + request.getContentLength()));
        }
      };
    }
    if ("characterEncoding".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getCharacterEncoding()));
        }
      };
    }
    if ("locale".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getLocale()));
        }
      };
    }
    if ("protocol".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap(request.getProtocol()));
        }
      };
    }
    if ("scheme".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(request.getScheme());
        }
      };
    }
    if ("secure".equals(parameter)) {
      new AccessLogValve.AccessLogElement()
      {
        public void addElement(StringBuilder buf, Date date, Request request, Response response, long time)
        {
          buf.append(ExtendedAccessLogValve.this.wrap("" + request.isSecure()));
        }
      };
    }
    log.error("x param for servlet request, couldn't decode value: " + parameter);
    
    return null;
  }
  
  private static class ElementTimestampStruct
  {
    private final Date currentTimestamp = new Date(0L);
    private final SimpleDateFormat currentTimestampFormat;
    private String currentTimestampString;
    
    ElementTimestampStruct(String format)
    {
      this.currentTimestampFormat = new SimpleDateFormat(format, Locale.US);
      this.currentTimestampFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\valves\ExtendedAccessLogValve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */