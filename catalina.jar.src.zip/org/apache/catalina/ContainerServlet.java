package org.apache.catalina;

public abstract interface ContainerServlet
{
  public abstract Wrapper getWrapper();
  
  public abstract void setWrapper(Wrapper paramWrapper);
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\ContainerServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */