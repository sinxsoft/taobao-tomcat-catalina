package org.apache.catalina.websocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import org.apache.tomcat.util.res.StringManager;

@Deprecated
public abstract class MessageInbound
  extends StreamInbound
{
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.websocket");
  private int byteBufferMaxSize = 2097152;
  private int charBufferMaxSize = 2097152;
  private ByteBuffer bb = ByteBuffer.allocate(8192);
  private CharBuffer cb = CharBuffer.allocate(8192);
  
  public MessageInbound() {}
  
  protected final void onBinaryData(InputStream is)
    throws IOException
  {
    int read = 0;
    while (read > -1)
    {
      this.bb.position(this.bb.position() + read);
      if (this.bb.remaining() == 0) {
        resizeByteBuffer();
      }
      read = is.read(this.bb.array(), this.bb.position(), this.bb.remaining());
    }
    this.bb.flip();
    onBinaryMessage(this.bb);
    this.bb.clear();
  }
  
  protected final void onTextData(Reader r)
    throws IOException
  {
    int read = 0;
    while (read > -1)
    {
      this.cb.position(this.cb.position() + read);
      if (this.cb.remaining() == 0) {
        resizeCharBuffer();
      }
      read = r.read(this.cb.array(), this.cb.position(), this.cb.remaining());
    }
    this.cb.flip();
    onTextMessage(this.cb);
    this.cb.clear();
  }
  
  private void resizeByteBuffer()
    throws IOException
  {
    int maxSize = getByteBufferMaxSize();
    if (this.bb.limit() >= maxSize) {
      throw new IOException(sm.getString("message.bufferTooSmall"));
    }
    long newSize = this.bb.limit() * 2;
    if (newSize > maxSize) {
      newSize = maxSize;
    }
    ByteBuffer newBuffer = ByteBuffer.allocate((int)newSize);
    this.bb.rewind();
    newBuffer.put(this.bb);
    this.bb = newBuffer;
  }
  
  private void resizeCharBuffer()
    throws IOException
  {
    int maxSize = getCharBufferMaxSize();
    if (this.cb.limit() >= maxSize) {
      throw new IOException(sm.getString("message.bufferTooSmall"));
    }
    long newSize = this.cb.limit() * 2;
    if (newSize > maxSize) {
      newSize = maxSize;
    }
    CharBuffer newBuffer = CharBuffer.allocate((int)newSize);
    this.cb.rewind();
    newBuffer.put(this.cb);
    this.cb = newBuffer;
  }
  
  public final int getByteBufferMaxSize()
  {
    return this.byteBufferMaxSize;
  }
  
  public final void setByteBufferMaxSize(int byteBufferMaxSize)
  {
    this.byteBufferMaxSize = byteBufferMaxSize;
  }
  
  public final int getCharBufferMaxSize()
  {
    return this.charBufferMaxSize;
  }
  
  public final void setCharBufferMaxSize(int charBufferMaxSize)
  {
    this.charBufferMaxSize = charBufferMaxSize;
  }
  
  protected abstract void onBinaryMessage(ByteBuffer paramByteBuffer)
    throws IOException;
  
  protected abstract void onTextMessage(CharBuffer paramCharBuffer)
    throws IOException;
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\websocket\MessageInbound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */