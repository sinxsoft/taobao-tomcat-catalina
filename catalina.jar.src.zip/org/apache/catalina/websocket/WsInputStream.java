package org.apache.catalina.websocket;

import java.io.IOException;
import java.io.InputStream;
import org.apache.coyote.http11.upgrade.UpgradeProcessor;
import org.apache.tomcat.util.res.StringManager;

@Deprecated
public class WsInputStream
  extends InputStream
{
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.websocket");
  private final UpgradeProcessor<?> processor;
  private final WsOutbound outbound;
  private WsFrame frame;
  private long remaining;
  private long readThisFragment;
  private String error = null;
  
  public WsInputStream(UpgradeProcessor<?> processor, WsOutbound outbound)
  {
    this.processor = processor;
    this.outbound = outbound;
  }
  
  public WsFrame nextFrame(boolean block)
    throws IOException
  {
    this.frame = WsFrame.nextFrame(this.processor, block);
    if (this.frame != null)
    {
      this.readThisFragment = 0L;
      this.remaining = this.frame.getPayLoadLength();
    }
    return this.frame;
  }
  
  public int read()
    throws IOException
  {
    makePayloadDataAvailable();
    if (this.remaining == 0L) {
      return -1;
    }
    this.remaining -= 1L;
    this.readThisFragment += 1L;
    
    int masked = this.processor.read();
    if (masked == -1) {
      return -1;
    }
    return masked ^ this.frame.getMask()[((int)((this.readThisFragment - 1L) % 4L))] & 0xFF;
  }
  
  public int read(byte[] b, int off, int len)
    throws IOException
  {
    makePayloadDataAvailable();
    if (this.remaining == 0L) {
      return -1;
    }
    if (len > this.remaining) {
      len = (int)this.remaining;
    }
    int result = this.processor.read(true, b, off, len);
    if (result == -1) {
      return -1;
    }
    for (int i = off; i < off + result; i++) {
      b[i] = ((byte)(b[i] ^ this.frame.getMask()[((int)((this.readThisFragment + i - off) % 4L))]));
    }
    this.remaining -= result;
    this.readThisFragment += result;
    return result;
  }
  
  private void makePayloadDataAvailable()
    throws IOException
  {
    if (this.error != null) {
      throw new IOException(this.error);
    }
    while ((this.remaining == 0L) && (!this.frame.getFin()))
    {
      nextFrame(true);
      while (this.frame.isControl())
      {
        if (this.frame.getOpCode() == 9) {
          this.outbound.pong(this.frame.getPayLoad());
        } else if (this.frame.getOpCode() != 10) {
          if (this.frame.getOpCode() == 8) {
            this.outbound.close(this.frame);
          } else {
            throw new IOException(sm.getString("is.unknownOpCode", new Object[] { Byte.valueOf(this.frame.getOpCode()) }));
          }
        }
        nextFrame(true);
      }
      if (this.frame.getOpCode() != 0)
      {
        this.error = sm.getString("is.notContinuation", new Object[] { Byte.valueOf(this.frame.getOpCode()) });
        
        throw new IOException(this.error);
      }
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\websocket\WsInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */