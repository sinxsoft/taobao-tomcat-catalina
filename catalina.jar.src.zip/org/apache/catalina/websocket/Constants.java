package org.apache.catalina.websocket;

@Deprecated
public class Constants
{
  public static final String Package = "org.apache.catalina.websocket";
  public static final byte OPCODE_CONTINUATION = 0;
  public static final byte OPCODE_TEXT = 1;
  public static final byte OPCODE_BINARY = 2;
  public static final byte OPCODE_CLOSE = 8;
  public static final byte OPCODE_PING = 9;
  public static final byte OPCODE_PONG = 10;
  public static final int STATUS_CLOSE_NORMAL = 1000;
  public static final int STATUS_SHUTDOWN = 1001;
  public static final int STATUS_PROTOCOL_ERROR = 1002;
  public static final int STATUS_UNEXPECTED_DATA_TYPE = 1003;
  public static final int STATUS_CODE_MISSING = 1005;
  public static final int STATUS_CLOSED_UNEXPECTEDLY = 1006;
  public static final int STATUS_BAD_DATA = 1007;
  public static final int STATUS_POLICY_VIOLATION = 1008;
  public static final int STATUS_MESSAGE_TOO_LARGE = 1009;
  public static final int STATUS_REQUIRED_EXTENSION = 1010;
  public static final int STATUS_UNEXPECTED_CONDITION = 1011;
  
  public Constants() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\websocket\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */