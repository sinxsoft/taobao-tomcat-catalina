package org.apache.catalina.websocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.charset.MalformedInputException;
import java.nio.charset.UnmappableCharacterException;
import org.apache.coyote.http11.upgrade.UpgradeInbound;
import org.apache.coyote.http11.upgrade.UpgradeOutbound;
import org.apache.coyote.http11.upgrade.UpgradeProcessor;
import org.apache.tomcat.util.buf.Utf8Decoder;
import org.apache.tomcat.util.net.AbstractEndpoint.Handler.SocketState;

@Deprecated
public abstract class StreamInbound
  implements UpgradeInbound
{
  private final ClassLoader applicationClassLoader;
  private UpgradeProcessor<?> processor = null;
  private WsOutbound outbound;
  private int outboundByteBufferSize = 8192;
  private int outboundCharBufferSize = 8192;
  
  public StreamInbound()
  {
    this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
  }
  
  public int getOutboundByteBufferSize()
  {
    return this.outboundByteBufferSize;
  }
  
  public void setOutboundByteBufferSize(int outboundByteBufferSize)
  {
    this.outboundByteBufferSize = outboundByteBufferSize;
  }
  
  public int getOutboundCharBufferSize()
  {
    return this.outboundCharBufferSize;
  }
  
  public void setOutboundCharBufferSize(int outboundCharBufferSize)
  {
    this.outboundCharBufferSize = outboundCharBufferSize;
  }
  
  public final void setUpgradeOutbound(UpgradeOutbound upgradeOutbound)
  {
    this.outbound = new WsOutbound(upgradeOutbound, this, this.outboundByteBufferSize, this.outboundCharBufferSize);
  }
  
  public final void setUpgradeProcessor(UpgradeProcessor<?> processor)
  {
    this.processor = processor;
  }
  
  public final WsOutbound getWsOutbound()
  {
    return this.outbound;
  }
  
  public final AbstractEndpoint.Handler.SocketState onData()
    throws IOException
  {
    WsInputStream wsIs = new WsInputStream(this.processor, getWsOutbound());
    try
    {
      WsFrame frame = wsIs.nextFrame(false);
      while (frame != null)
      {
        if (frame.getRsv() > 0)
        {
          closeOutboundConnection(1002, null);
          
          return AbstractEndpoint.Handler.SocketState.CLOSED;
        }
        byte opCode = frame.getOpCode();
        if (opCode == 2)
        {
          doOnBinaryData(wsIs);
        }
        else if (opCode == 1)
        {
          InputStreamReader r = new InputStreamReader(wsIs, new Utf8Decoder());
          
          doOnTextData(r);
        }
        else
        {
          if (opCode == 8)
          {
            closeOutboundConnection(frame);
            return AbstractEndpoint.Handler.SocketState.CLOSED;
          }
          if (opCode == 9)
          {
            getWsOutbound().pong(frame.getPayLoad());
          }
          else if (opCode == 10)
          {
            doOnPong(frame.getPayLoad());
          }
          else
          {
            closeOutboundConnection(1002, null);
            
            return AbstractEndpoint.Handler.SocketState.CLOSED;
          }
        }
        frame = wsIs.nextFrame(false);
      }
    }
    catch (MalformedInputException mie)
    {
      closeOutboundConnection(1007, null);
      return AbstractEndpoint.Handler.SocketState.CLOSED;
    }
    catch (UnmappableCharacterException uce)
    {
      closeOutboundConnection(1007, null);
      return AbstractEndpoint.Handler.SocketState.CLOSED;
    }
    catch (IOException ioe)
    {
      closeOutboundConnection(1002, null);
      return AbstractEndpoint.Handler.SocketState.CLOSED;
    }
    return AbstractEndpoint.Handler.SocketState.UPGRADED;
  }
  
  private void doOnBinaryData(InputStream is)
    throws IOException
  {
    Thread t = Thread.currentThread();
    ClassLoader cl = t.getContextClassLoader();
    t.setContextClassLoader(this.applicationClassLoader);
    try
    {
      onBinaryData(is);
    }
    finally
    {
      t.setContextClassLoader(cl);
    }
  }
  
  private void doOnTextData(Reader r)
    throws IOException
  {
    Thread t = Thread.currentThread();
    ClassLoader cl = t.getContextClassLoader();
    t.setContextClassLoader(this.applicationClassLoader);
    try
    {
      onTextData(r);
    }
    finally
    {
      t.setContextClassLoader(cl);
    }
  }
  
  private void closeOutboundConnection(int status, ByteBuffer data)
    throws IOException
  {
    try
    {
      getWsOutbound().close(status, data);
    }
    finally
    {
      doOnClose(status);
    }
  }
  
  private void closeOutboundConnection(WsFrame frame)
    throws IOException
  {
    try
    {
      getWsOutbound().close(frame);
    }
    finally
    {
      doOnClose(1000);
    }
  }
  
  void doOnClose(int status)
  {
    Thread t = Thread.currentThread();
    ClassLoader cl = t.getContextClassLoader();
    t.setContextClassLoader(this.applicationClassLoader);
    try
    {
      onClose(status);
    }
    finally
    {
      t.setContextClassLoader(cl);
    }
  }
  
  private void doOnPong(ByteBuffer payload)
  {
    Thread t = Thread.currentThread();
    ClassLoader cl = t.getContextClassLoader();
    t.setContextClassLoader(this.applicationClassLoader);
    try
    {
      onPong(payload);
    }
    finally
    {
      t.setContextClassLoader(cl);
    }
  }
  
  public final void onUpgradeComplete()
  {
    Thread t = Thread.currentThread();
    ClassLoader cl = t.getContextClassLoader();
    t.setContextClassLoader(this.applicationClassLoader);
    try
    {
      onOpen(this.outbound);
    }
    finally
    {
      t.setContextClassLoader(cl);
    }
  }
  
  protected void onOpen(WsOutbound outbound) {}
  
  protected void onClose(int status) {}
  
  protected void onPong(ByteBuffer payload) {}
  
  protected abstract void onBinaryData(InputStream paramInputStream)
    throws IOException;
  
  protected abstract void onTextData(Reader paramReader)
    throws IOException;
  
  public int getReadTimeout()
  {
    return -1;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\websocket\StreamInbound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */