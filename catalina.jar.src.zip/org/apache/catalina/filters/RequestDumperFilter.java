package org.apache.catalina.filters;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class RequestDumperFilter
  implements Filter
{
  private static final String NON_HTTP_REQ_MSG = "Not available. Non-http request.";
  private static final String NON_HTTP_RES_MSG = "Not available. Non-http response.";
  private static final ThreadLocal<Timestamp> timestamp = new ThreadLocal()
  {
    protected RequestDumperFilter.Timestamp initialValue()
    {
      return new RequestDumperFilter.Timestamp(null);
    }
  };
  private static final Log log = LogFactory.getLog(RequestDumperFilter.class);
  
  public RequestDumperFilter() {}
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    HttpServletRequest hRequest = null;
    HttpServletResponse hResponse = null;
    if ((request instanceof HttpServletRequest)) {
      hRequest = (HttpServletRequest)request;
    }
    if ((response instanceof HttpServletResponse)) {
      hResponse = (HttpServletResponse)response;
    }
    doLog("START TIME        ", getTimestamp());
    if (hRequest == null)
    {
      doLog("        requestURI", "Not available. Non-http request.");
      doLog("          authType", "Not available. Non-http request.");
    }
    else
    {
      doLog("        requestURI", hRequest.getRequestURI());
      doLog("          authType", hRequest.getAuthType());
    }
    doLog(" characterEncoding", request.getCharacterEncoding());
    doLog("     contentLength", Integer.valueOf(request.getContentLength()).toString());
    
    doLog("       contentType", request.getContentType());
    if (hRequest == null)
    {
      doLog("       contextPath", "Not available. Non-http request.");
      doLog("            cookie", "Not available. Non-http request.");
      doLog("            header", "Not available. Non-http request.");
    }
    else
    {
      doLog("       contextPath", hRequest.getContextPath());
      Cookie[] cookies = hRequest.getCookies();
      if (cookies != null) {
        for (int i = 0; i < cookies.length; i++) {
          doLog("            cookie", cookies[i].getName() + "=" + cookies[i].getValue());
        }
      }
      Enumeration<String> hnames = hRequest.getHeaderNames();
      while (hnames.hasMoreElements())
      {
        String hname = (String)hnames.nextElement();
        Enumeration<String> hvalues = hRequest.getHeaders(hname);
        while (hvalues.hasMoreElements())
        {
          String hvalue = (String)hvalues.nextElement();
          doLog("            header", hname + "=" + hvalue);
        }
      }
    }
    doLog("            locale", request.getLocale().toString());
    if (hRequest == null) {
      doLog("            method", "Not available. Non-http request.");
    } else {
      doLog("            method", hRequest.getMethod());
    }
    Enumeration<String> pnames = request.getParameterNames();
    while (pnames.hasMoreElements())
    {
      String pname = (String)pnames.nextElement();
      String[] pvalues = request.getParameterValues(pname);
      StringBuilder result = new StringBuilder(pname);
      result.append('=');
      for (int i = 0; i < pvalues.length; i++)
      {
        if (i > 0) {
          result.append(", ");
        }
        result.append(pvalues[i]);
      }
      doLog("         parameter", result.toString());
    }
    if (hRequest == null) {
      doLog("          pathInfo", "Not available. Non-http request.");
    } else {
      doLog("          pathInfo", hRequest.getPathInfo());
    }
    doLog("          protocol", request.getProtocol());
    if (hRequest == null) {
      doLog("       queryString", "Not available. Non-http request.");
    } else {
      doLog("       queryString", hRequest.getQueryString());
    }
    doLog("        remoteAddr", request.getRemoteAddr());
    doLog("        remoteHost", request.getRemoteHost());
    if (hRequest == null)
    {
      doLog("        remoteUser", "Not available. Non-http request.");
      doLog("requestedSessionId", "Not available. Non-http request.");
    }
    else
    {
      doLog("        remoteUser", hRequest.getRemoteUser());
      doLog("requestedSessionId", hRequest.getRequestedSessionId());
    }
    doLog("            scheme", request.getScheme());
    doLog("        serverName", request.getServerName());
    doLog("        serverPort", Integer.valueOf(request.getServerPort()).toString());
    if (hRequest == null) {
      doLog("       servletPath", "Not available. Non-http request.");
    } else {
      doLog("       servletPath", hRequest.getServletPath());
    }
    doLog("          isSecure", Boolean.valueOf(request.isSecure()).toString());
    
    doLog("------------------", "--------------------------------------------");
    
    chain.doFilter(request, response);
    
    doLog("------------------", "--------------------------------------------");
    if (hRequest == null) {
      doLog("          authType", "Not available. Non-http request.");
    } else {
      doLog("          authType", hRequest.getAuthType());
    }
    doLog("       contentType", response.getContentType());
    Iterator i$;
    if (hResponse == null)
    {
      doLog("            header", "Not available. Non-http response.");
    }
    else
    {
      Iterable<String> rhnames = hResponse.getHeaderNames();
      for (i$ = rhnames.iterator(); i$.hasNext();)
      {
        rhname = (String)i$.next();
        Iterable<String> rhvalues = hResponse.getHeaders(rhname);
        for (String rhvalue : rhvalues) {
          doLog("            header", rhname + "=" + rhvalue);
        }
      }
    }
    String rhname;
    if (hRequest == null) {
      doLog("        remoteUser", "Not available. Non-http request.");
    } else {
      doLog("        remoteUser", hRequest.getRemoteUser());
    }
    if (hResponse == null) {
      doLog("        remoteUser", "Not available. Non-http response.");
    } else {
      doLog("            status", Integer.valueOf(hResponse.getStatus()).toString());
    }
    doLog("END TIME          ", getTimestamp());
    doLog("==================", "============================================");
  }
  
  private void doLog(String attribute, String value)
  {
    StringBuilder sb = new StringBuilder(80);
    sb.append(Thread.currentThread().getName());
    sb.append(' ');
    sb.append(attribute);
    sb.append('=');
    sb.append(value);
    log.info(sb.toString());
  }
  
  private String getTimestamp()
  {
    Timestamp ts = (Timestamp)timestamp.get();
    long currentTime = System.currentTimeMillis();
    if (ts.date.getTime() + 999L < currentTime)
    {
      ts.date.setTime(currentTime - currentTime % 1000L);
      ts.update();
    }
    return ts.dateString;
  }
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {}
  
  public void destroy() {}
  
  private static final class Timestamp
  {
    private final Date date = new Date(0L);
    private final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
    private String dateString = this.format.format(this.date);
    
    private Timestamp() {}
    
    private void update()
    {
      this.dateString = this.format.format(this.date);
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\RequestDumperFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */