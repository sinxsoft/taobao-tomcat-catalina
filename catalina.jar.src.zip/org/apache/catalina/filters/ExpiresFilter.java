package org.apache.catalina.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class ExpiresFilter
  extends FilterBase
{
  public ExpiresFilter() {}
  
  protected static class Duration
  {
    protected final int amount;
    protected final ExpiresFilter.DurationUnit unit;
    
    public Duration(int amount, ExpiresFilter.DurationUnit unit)
    {
      this.amount = amount;
      this.unit = unit;
    }
    
    public int getAmount()
    {
      return this.amount;
    }
    
    public ExpiresFilter.DurationUnit getUnit()
    {
      return this.unit;
    }
    
    public String toString()
    {
      return this.amount + " " + this.unit;
    }
  }
  
  protected static enum DurationUnit
  {
    DAY(6),  HOUR(10),  MINUTE(12),  MONTH(2),  SECOND(13),  WEEK(3),  YEAR(1);
    
    private final int calendardField;
    
    private DurationUnit(int calendardField)
    {
      this.calendardField = calendardField;
    }
    
    public int getCalendardField()
    {
      return this.calendardField;
    }
  }
  
  protected static class ExpiresConfiguration
  {
    private final List<ExpiresFilter.Duration> durations;
    private final ExpiresFilter.StartingPoint startingPoint;
    
    public ExpiresConfiguration(ExpiresFilter.StartingPoint startingPoint, List<ExpiresFilter.Duration> durations)
    {
      this.startingPoint = startingPoint;
      this.durations = durations;
    }
    
    public List<ExpiresFilter.Duration> getDurations()
    {
      return this.durations;
    }
    
    public ExpiresFilter.StartingPoint getStartingPoint()
    {
      return this.startingPoint;
    }
    
    public String toString()
    {
      return "ExpiresConfiguration[startingPoint=" + this.startingPoint + ", duration=" + this.durations + "]";
    }
  }
  
  protected static enum StartingPoint
  {
    ACCESS_TIME,  LAST_MODIFICATION_TIME;
    
    private StartingPoint() {}
  }
  
  public class XHttpServletResponse
    extends HttpServletResponseWrapper
  {
    private String cacheControlHeader;
    private long lastModifiedHeader;
    private boolean lastModifiedHeaderSet;
    private PrintWriter printWriter;
    private final HttpServletRequest request;
    private ServletOutputStream servletOutputStream;
    private boolean writeResponseBodyStarted;
    
    public XHttpServletResponse(HttpServletRequest request, HttpServletResponse response)
    {
      super();
      this.request = request;
    }
    
    public void addDateHeader(String name, long date)
    {
      super.addDateHeader(name, date);
      if (!this.lastModifiedHeaderSet)
      {
        this.lastModifiedHeader = date;
        this.lastModifiedHeaderSet = true;
      }
    }
    
    public void addHeader(String name, String value)
    {
      super.addHeader(name, value);
      if (("Cache-Control".equalsIgnoreCase(name)) && (this.cacheControlHeader == null)) {
        this.cacheControlHeader = value;
      }
    }
    
    public String getCacheControlHeader()
    {
      return this.cacheControlHeader;
    }
    
    public long getLastModifiedHeader()
    {
      return this.lastModifiedHeader;
    }
    
    public ServletOutputStream getOutputStream()
      throws IOException
    {
      if (this.servletOutputStream == null) {
        this.servletOutputStream = new ExpiresFilter.XServletOutputStream(ExpiresFilter.this, super.getOutputStream(), this.request, this);
      }
      return this.servletOutputStream;
    }
    
    public PrintWriter getWriter()
      throws IOException
    {
      if (this.printWriter == null) {
        this.printWriter = new ExpiresFilter.XPrintWriter(ExpiresFilter.this, super.getWriter(), this.request, this);
      }
      return this.printWriter;
    }
    
    public boolean isLastModifiedHeaderSet()
    {
      return this.lastModifiedHeaderSet;
    }
    
    public boolean isWriteResponseBodyStarted()
    {
      return this.writeResponseBodyStarted;
    }
    
    public void reset()
    {
      super.reset();
      this.lastModifiedHeader = 0L;
      this.lastModifiedHeaderSet = false;
      this.cacheControlHeader = null;
    }
    
    public void setDateHeader(String name, long date)
    {
      super.setDateHeader(name, date);
      if ("Last-Modified".equalsIgnoreCase(name))
      {
        this.lastModifiedHeader = date;
        this.lastModifiedHeaderSet = true;
      }
    }
    
    public void setHeader(String name, String value)
    {
      super.setHeader(name, value);
      if ("Cache-Control".equalsIgnoreCase(name)) {
        this.cacheControlHeader = value;
      }
    }
    
    public void setWriteResponseBodyStarted(boolean writeResponseBodyStarted)
    {
      this.writeResponseBodyStarted = writeResponseBodyStarted;
    }
  }
  
  public class XPrintWriter
    extends PrintWriter
  {
    private final PrintWriter out;
    private final HttpServletRequest request;
    private final ExpiresFilter.XHttpServletResponse response;
    
    public XPrintWriter(PrintWriter out, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
    {
      super();
      this.out = out;
      this.request = request;
      this.response = response;
    }
    
    public PrintWriter append(char c)
    {
      fireBeforeWriteResponseBodyEvent();
      return this.out.append(c);
    }
    
    public PrintWriter append(CharSequence csq)
    {
      fireBeforeWriteResponseBodyEvent();
      return this.out.append(csq);
    }
    
    public PrintWriter append(CharSequence csq, int start, int end)
    {
      fireBeforeWriteResponseBodyEvent();
      return this.out.append(csq, start, end);
    }
    
    public void close()
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.close();
    }
    
    private void fireBeforeWriteResponseBodyEvent()
    {
      if (!this.response.isWriteResponseBodyStarted())
      {
        this.response.setWriteResponseBodyStarted(true);
        ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
      }
    }
    
    public void flush()
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.flush();
    }
    
    public void print(boolean b)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(b);
    }
    
    public void print(char c)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(c);
    }
    
    public void print(char[] s)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(s);
    }
    
    public void print(double d)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(d);
    }
    
    public void print(float f)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(f);
    }
    
    public void print(int i)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(i);
    }
    
    public void print(long l)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(l);
    }
    
    public void print(Object obj)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(obj);
    }
    
    public void print(String s)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.print(s);
    }
    
    public PrintWriter printf(Locale l, String format, Object... args)
    {
      fireBeforeWriteResponseBodyEvent();
      return this.out.printf(l, format, args);
    }
    
    public PrintWriter printf(String format, Object... args)
    {
      fireBeforeWriteResponseBodyEvent();
      return this.out.printf(format, args);
    }
    
    public void println()
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println();
    }
    
    public void println(boolean x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(char x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(char[] x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(double x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(float x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(int x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(long x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(Object x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void println(String x)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.println(x);
    }
    
    public void write(char[] buf)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.write(buf);
    }
    
    public void write(char[] buf, int off, int len)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.write(buf, off, len);
    }
    
    public void write(int c)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.write(c);
    }
    
    public void write(String s)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.write(s);
    }
    
    public void write(String s, int off, int len)
    {
      fireBeforeWriteResponseBodyEvent();
      this.out.write(s, off, len);
    }
  }
  
  public class XServletOutputStream
    extends ServletOutputStream
  {
    private final HttpServletRequest request;
    private final ExpiresFilter.XHttpServletResponse response;
    private final ServletOutputStream servletOutputStream;
    
    public XServletOutputStream(ServletOutputStream servletOutputStream, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
    {
      this.servletOutputStream = servletOutputStream;
      this.response = response;
      this.request = request;
    }
    
    public void close()
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.close();
    }
    
    private void fireOnBeforeWriteResponseBodyEvent()
    {
      if (!this.response.isWriteResponseBodyStarted())
      {
        this.response.setWriteResponseBodyStarted(true);
        ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
      }
    }
    
    public void flush()
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.flush();
    }
    
    public void print(boolean b)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(b);
    }
    
    public void print(char c)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(c);
    }
    
    public void print(double d)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(d);
    }
    
    public void print(float f)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(f);
    }
    
    public void print(int i)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(i);
    }
    
    public void print(long l)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(l);
    }
    
    public void print(String s)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.print(s);
    }
    
    public void println()
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println();
    }
    
    public void println(boolean b)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(b);
    }
    
    public void println(char c)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(c);
    }
    
    public void println(double d)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(d);
    }
    
    public void println(float f)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(f);
    }
    
    public void println(int i)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(i);
    }
    
    public void println(long l)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(l);
    }
    
    public void println(String s)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.println(s);
    }
    
    public void write(byte[] b)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.write(b);
    }
    
    public void write(byte[] b, int off, int len)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.write(b, off, len);
    }
    
    public void write(int b)
      throws IOException
    {
      fireOnBeforeWriteResponseBodyEvent();
      this.servletOutputStream.write(b);
    }
  }
  
  private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
  private static final String HEADER_CACHE_CONTROL = "Cache-Control";
  private static final String HEADER_EXPIRES = "Expires";
  private static final String HEADER_LAST_MODIFIED = "Last-Modified";
  private static final Log log = LogFactory.getLog(ExpiresFilter.class);
  private static final String PARAMETER_EXPIRES_BY_TYPE = "ExpiresByType";
  private static final String PARAMETER_EXPIRES_DEFAULT = "ExpiresDefault";
  private static final String PARAMETER_EXPIRES_EXCLUDED_RESPONSE_STATUS_CODES = "ExpiresExcludedResponseStatusCodes";
  private ExpiresConfiguration defaultExpiresConfiguration;
  
  protected static int[] commaDelimitedListToIntArray(String commaDelimitedInts)
  {
    String[] intsAsStrings = commaDelimitedListToStringArray(commaDelimitedInts);
    int[] ints = new int[intsAsStrings.length];
    for (int i = 0; i < intsAsStrings.length; i++)
    {
      String intAsString = intsAsStrings[i];
      try
      {
        ints[i] = Integer.parseInt(intAsString);
      }
      catch (NumberFormatException e)
      {
        throw new RuntimeException("Exception parsing number '" + i + "' (zero based) of comma delimited list '" + commaDelimitedInts + "'");
      }
    }
    return ints;
  }
  
  protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
  {
    return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern.split(commaDelimitedStrings);
  }
  
  protected static boolean contains(String str, String searchStr)
  {
    if ((str == null) || (searchStr == null)) {
      return false;
    }
    return str.indexOf(searchStr) >= 0;
  }
  
  protected static String intsToCommaDelimitedString(int[] ints)
  {
    if (ints == null) {
      return "";
    }
    StringBuilder result = new StringBuilder();
    for (int i = 0; i < ints.length; i++)
    {
      result.append(ints[i]);
      if (i < ints.length - 1) {
        result.append(", ");
      }
    }
    return result.toString();
  }
  
  protected static boolean isEmpty(String str)
  {
    return (str == null) || (str.length() == 0);
  }
  
  protected static boolean isNotEmpty(String str)
  {
    return !isEmpty(str);
  }
  
  protected static boolean startsWithIgnoreCase(String string, String prefix)
  {
    if ((string == null) || (prefix == null)) {
      return (string == null) && (prefix == null);
    }
    if (prefix.length() > string.length()) {
      return false;
    }
    return string.regionMatches(true, 0, prefix, 0, prefix.length());
  }
  
  protected static String substringBefore(String str, String separator)
  {
    if ((str == null) || (str.isEmpty()) || (separator == null)) {
      return null;
    }
    if (separator.isEmpty()) {
      return "";
    }
    int separatorIndex = str.indexOf(separator);
    if (separatorIndex == -1) {
      return str;
    }
    return str.substring(0, separatorIndex);
  }
  
  private int[] excludedResponseStatusCodes = { 304 };
  private Map<String, ExpiresConfiguration> expiresConfigurationByContentType = new LinkedHashMap();
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
    {
      HttpServletRequest httpRequest = (HttpServletRequest)request;
      HttpServletResponse httpResponse = (HttpServletResponse)response;
      if (response.isCommitted())
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("expiresFilter.responseAlreadyCommited", new Object[] { httpRequest.getRequestURL() }));
        }
        chain.doFilter(request, response);
      }
      else
      {
        XHttpServletResponse xResponse = new XHttpServletResponse(httpRequest, httpResponse);
        
        chain.doFilter(request, xResponse);
        if (!xResponse.isWriteResponseBodyStarted()) {
          onBeforeWriteResponseBody(httpRequest, xResponse);
        }
      }
    }
    else
    {
      chain.doFilter(request, response);
    }
  }
  
  public ExpiresConfiguration getDefaultExpiresConfiguration()
  {
    return this.defaultExpiresConfiguration;
  }
  
  public String getExcludedResponseStatusCodes()
  {
    return intsToCommaDelimitedString(this.excludedResponseStatusCodes);
  }
  
  public int[] getExcludedResponseStatusCodesAsInts()
  {
    return this.excludedResponseStatusCodes;
  }
  
  protected Date getExpirationDate(XHttpServletResponse response)
  {
    String contentType = response.getContentType();
    
    ExpiresConfiguration configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentType);
    if (configuration != null)
    {
      Date result = getExpirationDate(configuration, response);
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentType, contentType, result }));
      }
      return result;
    }
    if (contains(contentType, ";"))
    {
      String contentTypeWithoutCharset = substringBefore(contentType, ";").trim();
      configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentTypeWithoutCharset);
      if (configuration != null)
      {
        Date result = getExpirationDate(configuration, response);
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentTypeWithoutCharset, contentType, result }));
        }
        return result;
      }
    }
    if (contains(contentType, "/"))
    {
      String majorType = substringBefore(contentType, "/");
      configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(majorType);
      if (configuration != null)
      {
        Date result = getExpirationDate(configuration, response);
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, majorType, contentType, result }));
        }
        return result;
      }
    }
    if (this.defaultExpiresConfiguration != null)
    {
      Date result = getExpirationDate(this.defaultExpiresConfiguration, response);
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("expiresFilter.useDefaultConfiguration", new Object[] { this.defaultExpiresConfiguration, contentType, result }));
      }
      return result;
    }
    if (log.isDebugEnabled()) {
      log.debug(sm.getString("expiresFilter.noExpirationConfiguredForContentType", new Object[] { contentType }));
    }
    return null;
  }
  
  protected Date getExpirationDate(ExpiresConfiguration configuration, XHttpServletResponse response)
  {
    Calendar calendar;
    Calendar calendar;
    switch (configuration.getStartingPoint())
    {
    case ACCESS_TIME: 
      calendar = Calendar.getInstance();
      break;
    case LAST_MODIFICATION_TIME: 
      if (response.isLastModifiedHeaderSet()) {
        try
        {
          long lastModified = response.getLastModifiedHeader();
          calendar = Calendar.getInstance();
          calendar.setTimeInMillis(lastModified);
        }
        catch (NumberFormatException e)
        {
          calendar = Calendar.getInstance();
        }
      } else {
        calendar = Calendar.getInstance();
      }
      break;
    default: 
      throw new IllegalStateException(sm.getString("expiresFilter.unsupportedStartingPoint", new Object[] { configuration.getStartingPoint() }));
    }
    for (Duration duration : configuration.getDurations()) {
      calendar.add(duration.getUnit().getCalendardField(), duration.getAmount());
    }
    return calendar.getTime();
  }
  
  public Map<String, ExpiresConfiguration> getExpiresConfigurationByContentType()
  {
    return this.expiresConfigurationByContentType;
  }
  
  protected Log getLogger()
  {
    return log;
  }
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    for (Enumeration<String> names = filterConfig.getInitParameterNames(); names.hasMoreElements();)
    {
      String name = (String)names.nextElement();
      String value = filterConfig.getInitParameter(name);
      try
      {
        if (name.startsWith("ExpiresByType"))
        {
          String contentType = name.substring("ExpiresByType".length()).trim();
          
          ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
          this.expiresConfigurationByContentType.put(contentType, expiresConfiguration);
        }
        else if (name.equalsIgnoreCase("ExpiresDefault"))
        {
          ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
          this.defaultExpiresConfiguration = expiresConfiguration;
        }
        else if (name.equalsIgnoreCase("ExpiresExcludedResponseStatusCodes"))
        {
          this.excludedResponseStatusCodes = commaDelimitedListToIntArray(value);
        }
        else
        {
          log.warn(sm.getString("expiresFilter.unknownParameterIgnored", new Object[] { name, value }));
        }
      }
      catch (RuntimeException e)
      {
        throw new ServletException(sm.getString("expiresFilter.exceptionProcessingParameter", new Object[] { name, value }), e);
      }
    }
    log.debug(sm.getString("expiresFilter.filterInitialized", new Object[] { toString() }));
  }
  
  protected boolean isEligibleToExpirationHeaderGeneration(HttpServletRequest request, XHttpServletResponse response)
  {
    boolean expirationHeaderHasBeenSet = (response.containsHeader("Expires")) || (contains(response.getCacheControlHeader(), "max-age"));
    if (expirationHeaderHasBeenSet)
    {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("expiresFilter.expirationHeaderAlreadyDefined", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
      }
      return false;
    }
    for (int skippedStatusCode : this.excludedResponseStatusCodes) {
      if (response.getStatus() == skippedStatusCode)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("expiresFilter.skippedStatusCode", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
        }
        return false;
      }
    }
    return true;
  }
  
  public void onBeforeWriteResponseBody(HttpServletRequest request, XHttpServletResponse response)
  {
    if (!isEligibleToExpirationHeaderGeneration(request, response)) {
      return;
    }
    Date expirationDate = getExpirationDate(response);
    if (expirationDate == null)
    {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("expiresFilter.noExpirationConfigured", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType() }));
      }
    }
    else
    {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("expiresFilter.setExpirationDate", new Object[] { request.getRequestURI(), Integer.valueOf(response.getStatus()), response.getContentType(), expirationDate }));
      }
      String maxAgeDirective = "max-age=" + (expirationDate.getTime() - System.currentTimeMillis()) / 1000L;
      
      String cacheControlHeader = response.getCacheControlHeader();
      String newCacheControlHeader = cacheControlHeader + ", " + maxAgeDirective;
      
      response.setHeader("Cache-Control", newCacheControlHeader);
      response.setDateHeader("Expires", expirationDate.getTime());
    }
  }
  
  protected ExpiresConfiguration parseExpiresConfiguration(String inputLine)
  {
    String line = inputLine.trim();
    
    StringTokenizer tokenizer = new StringTokenizer(line, " ");
    String currentToken;
    try
    {
      currentToken = tokenizer.nextToken();
    }
    catch (NoSuchElementException e)
    {
      throw new IllegalStateException(sm.getString("expiresFilter.startingPointNotFound", new Object[] { line }));
    }
    StartingPoint startingPoint;
    if (("access".equalsIgnoreCase(currentToken)) || ("now".equalsIgnoreCase(currentToken)))
    {
      startingPoint = StartingPoint.ACCESS_TIME;
    }
    else
    {
      StartingPoint startingPoint;
      if ("modification".equalsIgnoreCase(currentToken))
      {
        startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
      }
      else if ((!tokenizer.hasMoreTokens()) && (startsWithIgnoreCase(currentToken, "a")))
      {
        StartingPoint startingPoint = StartingPoint.ACCESS_TIME;
        
        tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
      }
      else if ((!tokenizer.hasMoreTokens()) && (startsWithIgnoreCase(currentToken, "m")))
      {
        StartingPoint startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
        
        tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
      }
      else
      {
        throw new IllegalStateException(sm.getString("expiresFilter.startingPointInvalid", new Object[] { currentToken, line }));
      }
    }
    StartingPoint startingPoint;
    try
    {
      currentToken = tokenizer.nextToken();
    }
    catch (NoSuchElementException e)
    {
      throw new IllegalStateException(sm.getString("Duration not found in directive '{}'", new Object[] { line }));
    }
    if ("plus".equalsIgnoreCase(currentToken)) {
      try
      {
        currentToken = tokenizer.nextToken();
      }
      catch (NoSuchElementException e)
      {
        throw new IllegalStateException(sm.getString("Duration not found in directive '{}'", new Object[] { line }));
      }
    }
    List<Duration> durations = new ArrayList();
    while (currentToken != null)
    {
      int amount;
      try
      {
        amount = Integer.parseInt(currentToken);
      }
      catch (NumberFormatException e)
      {
        throw new IllegalStateException(sm.getString("Invalid duration (number) '{}' in directive '{}'", new Object[] { currentToken, line }));
      }
      try
      {
        currentToken = tokenizer.nextToken();
      }
      catch (NoSuchElementException e)
      {
        throw new IllegalStateException(sm.getString("Duration unit not found after amount {} in directive '{}'", new Object[] { Integer.valueOf(amount), line }));
      }
      DurationUnit durationUnit;
      if (("year".equalsIgnoreCase(currentToken)) || ("years".equalsIgnoreCase(currentToken)))
      {
        durationUnit = DurationUnit.YEAR;
      }
      else
      {
        DurationUnit durationUnit;
        if (("month".equalsIgnoreCase(currentToken)) || ("months".equalsIgnoreCase(currentToken)))
        {
          durationUnit = DurationUnit.MONTH;
        }
        else
        {
          DurationUnit durationUnit;
          if (("week".equalsIgnoreCase(currentToken)) || ("weeks".equalsIgnoreCase(currentToken)))
          {
            durationUnit = DurationUnit.WEEK;
          }
          else
          {
            DurationUnit durationUnit;
            if (("day".equalsIgnoreCase(currentToken)) || ("days".equalsIgnoreCase(currentToken)))
            {
              durationUnit = DurationUnit.DAY;
            }
            else
            {
              DurationUnit durationUnit;
              if (("hour".equalsIgnoreCase(currentToken)) || ("hours".equalsIgnoreCase(currentToken)))
              {
                durationUnit = DurationUnit.HOUR;
              }
              else
              {
                DurationUnit durationUnit;
                if (("minute".equalsIgnoreCase(currentToken)) || ("minutes".equalsIgnoreCase(currentToken)))
                {
                  durationUnit = DurationUnit.MINUTE;
                }
                else
                {
                  DurationUnit durationUnit;
                  if (("second".equalsIgnoreCase(currentToken)) || ("seconds".equalsIgnoreCase(currentToken))) {
                    durationUnit = DurationUnit.SECOND;
                  } else {
                    throw new IllegalStateException(sm.getString("Invalid duration unit (years|months|weeks|days|hours|minutes|seconds) '{}' in directive '{}'", new Object[] { currentToken, line }));
                  }
                }
              }
            }
          }
        }
      }
      DurationUnit durationUnit;
      Duration duration = new Duration(amount, durationUnit);
      durations.add(duration);
      if (tokenizer.hasMoreTokens()) {
        currentToken = tokenizer.nextToken();
      } else {
        currentToken = null;
      }
    }
    return new ExpiresConfiguration(startingPoint, durations);
  }
  
  public void setDefaultExpiresConfiguration(ExpiresConfiguration defaultExpiresConfiguration)
  {
    this.defaultExpiresConfiguration = defaultExpiresConfiguration;
  }
  
  public void setExcludedResponseStatusCodes(int[] excludedResponseStatusCodes)
  {
    this.excludedResponseStatusCodes = excludedResponseStatusCodes;
  }
  
  public void setExpiresConfigurationByContentType(Map<String, ExpiresConfiguration> expiresConfigurationByContentType)
  {
    this.expiresConfigurationByContentType = expiresConfigurationByContentType;
  }
  
  public String toString()
  {
    return getClass().getSimpleName() + "[excludedResponseStatusCode=[" + intsToCommaDelimitedString(this.excludedResponseStatusCodes) + "], default=" + this.defaultExpiresConfiguration + ", byType=" + this.expiresConfigurationByContentType + "]";
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\ExpiresFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */