package org.apache.catalina.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import org.apache.catalina.comet.CometEvent;
import org.apache.catalina.comet.CometFilter;
import org.apache.catalina.comet.CometFilterChain;
import org.apache.tomcat.util.res.StringManager;

public abstract class RequestFilter
  extends FilterBase
  implements CometFilter
{
  protected Pattern allow = null;
  protected Pattern deny = null;
  protected int denyStatus = 403;
  private static final String PLAIN_TEXT_MIME_TYPE = "text/plain";
  
  public RequestFilter() {}
  
  public String getAllow()
  {
    if (this.allow == null) {
      return null;
    }
    return this.allow.toString();
  }
  
  public void setAllow(String allow)
  {
    if ((allow == null) || (allow.length() == 0)) {
      this.allow = null;
    } else {
      this.allow = Pattern.compile(allow);
    }
  }
  
  public String getDeny()
  {
    if (this.deny == null) {
      return null;
    }
    return this.deny.toString();
  }
  
  public void setDeny(String deny)
  {
    if ((deny == null) || (deny.length() == 0)) {
      this.deny = null;
    } else {
      this.deny = Pattern.compile(deny);
    }
  }
  
  public int getDenyStatus()
  {
    return this.denyStatus;
  }
  
  public void setDenyStatus(int denyStatus)
  {
    this.denyStatus = denyStatus;
  }
  
  public abstract void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
    throws IOException, ServletException;
  
  protected boolean isConfigProblemFatal()
  {
    return true;
  }
  
  protected void process(String property, ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if (isAllowed(property)) {
      chain.doFilter(request, response);
    } else if ((response instanceof HttpServletResponse)) {
      ((HttpServletResponse)response).sendError(this.denyStatus);
    } else {
      sendErrorWhenNotHttp(response);
    }
  }
  
  protected void processCometEvent(String property, CometEvent event, CometFilterChain chain)
    throws IOException, ServletException
  {
    HttpServletResponse response = event.getHttpServletResponse();
    if (isAllowed(property))
    {
      chain.doFilterEvent(event);
    }
    else
    {
      response.sendError(this.denyStatus);
      event.close();
    }
  }
  
  private boolean isAllowed(String property)
  {
    if ((this.deny != null) && (this.deny.matcher(property).matches())) {
      return false;
    }
    if ((this.allow != null) && (this.allow.matcher(property).matches())) {
      return true;
    }
    if ((this.deny != null) && (this.allow == null)) {
      return true;
    }
    return false;
  }
  
  private void sendErrorWhenNotHttp(ServletResponse response)
    throws IOException
  {
    response.setContentType("text/plain");
    response.getWriter().write(sm.getString("http.403"));
    response.getWriter().flush();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\RequestFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */