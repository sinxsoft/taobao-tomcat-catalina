package org.apache.catalina.filters;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class RemoteIpFilter
  implements Filter
{
  public RemoteIpFilter() {}
  
  public static class XForwardedRequest
    extends HttpServletRequestWrapper
  {
    static final ThreadLocal<SimpleDateFormat[]> threadLocalDateFormats = new ThreadLocal()
    {
      protected SimpleDateFormat[] initialValue()
      {
        return new SimpleDateFormat[] { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US) };
      }
    };
    protected Map<String, List<String>> headers;
    protected int localPort;
    protected String remoteAddr;
    protected String remoteHost;
    protected String scheme;
    protected boolean secure;
    protected int serverPort;
    
    public XForwardedRequest(HttpServletRequest request)
    {
      super();
      this.localPort = request.getLocalPort();
      this.remoteAddr = request.getRemoteAddr();
      this.remoteHost = request.getRemoteHost();
      this.scheme = request.getScheme();
      this.secure = request.isSecure();
      this.serverPort = request.getServerPort();
      
      this.headers = new HashMap();
      for (Enumeration<String> headerNames = request.getHeaderNames(); headerNames.hasMoreElements();)
      {
        String header = (String)headerNames.nextElement();
        this.headers.put(header, Collections.list(request.getHeaders(header)));
      }
    }
    
    public long getDateHeader(String name)
    {
      String value = getHeader(name);
      if (value == null) {
        return -1L;
      }
      DateFormat[] dateFormats = (DateFormat[])threadLocalDateFormats.get();
      Date date = null;
      for (int i = 0; (i < dateFormats.length) && (date == null); i++)
      {
        DateFormat dateFormat = dateFormats[i];
        try
        {
          date = dateFormat.parse(value);
        }
        catch (Exception ParseException) {}
      }
      if (date == null) {
        throw new IllegalArgumentException(value);
      }
      return date.getTime();
    }
    
    public String getHeader(String name)
    {
      Map.Entry<String, List<String>> header = getHeaderEntry(name);
      if ((header == null) || (header.getValue() == null) || (((List)header.getValue()).isEmpty())) {
        return null;
      }
      return (String)((List)header.getValue()).get(0);
    }
    
    protected Map.Entry<String, List<String>> getHeaderEntry(String name)
    {
      for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
        if (((String)entry.getKey()).equalsIgnoreCase(name)) {
          return entry;
        }
      }
      return null;
    }
    
    public Enumeration<String> getHeaderNames()
    {
      return Collections.enumeration(this.headers.keySet());
    }
    
    public Enumeration<String> getHeaders(String name)
    {
      Map.Entry<String, List<String>> header = getHeaderEntry(name);
      if ((header == null) || (header.getValue() == null)) {
        return Collections.enumeration(Collections.emptyList());
      }
      return Collections.enumeration((Collection)header.getValue());
    }
    
    public int getIntHeader(String name)
    {
      String value = getHeader(name);
      if (value == null) {
        return -1;
      }
      return Integer.parseInt(value);
    }
    
    public int getLocalPort()
    {
      return this.localPort;
    }
    
    public String getRemoteAddr()
    {
      return this.remoteAddr;
    }
    
    public String getRemoteHost()
    {
      return this.remoteHost;
    }
    
    public String getScheme()
    {
      return this.scheme;
    }
    
    public int getServerPort()
    {
      return this.serverPort;
    }
    
    public boolean isSecure()
    {
      return this.secure;
    }
    
    public void removeHeader(String name)
    {
      Map.Entry<String, List<String>> header = getHeaderEntry(name);
      if (header != null) {
        this.headers.remove(header.getKey());
      }
    }
    
    public void setHeader(String name, String value)
    {
      List<String> values = Arrays.asList(new String[] { value });
      Map.Entry<String, List<String>> header = getHeaderEntry(name);
      if (header == null) {
        this.headers.put(name, values);
      } else {
        header.setValue(values);
      }
    }
    
    public void setLocalPort(int localPort)
    {
      this.localPort = localPort;
    }
    
    public void setRemoteAddr(String remoteAddr)
    {
      this.remoteAddr = remoteAddr;
    }
    
    public void setRemoteHost(String remoteHost)
    {
      this.remoteHost = remoteHost;
    }
    
    public void setScheme(String scheme)
    {
      this.scheme = scheme;
    }
    
    public void setSecure(boolean secure)
    {
      this.secure = secure;
    }
    
    public void setServerPort(int serverPort)
    {
      this.serverPort = serverPort;
    }
  }
  
  private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
  protected static final String HTTP_SERVER_PORT_PARAMETER = "httpServerPort";
  protected static final String HTTPS_SERVER_PORT_PARAMETER = "httpsServerPort";
  protected static final String INTERNAL_PROXIES_PARAMETER = "internalProxies";
  private static final Log log = LogFactory.getLog(RemoteIpFilter.class);
  protected static final String PROTOCOL_HEADER_PARAMETER = "protocolHeader";
  protected static final String PROTOCOL_HEADER_HTTPS_VALUE_PARAMETER = "protocolHeaderHttpsValue";
  protected static final String PORT_HEADER_PARAMETER = "portHeader";
  protected static final String CHANGE_LOCAL_PORT_PARAMETER = "changeLocalPort";
  protected static final String PROXIES_HEADER_PARAMETER = "proxiesHeader";
  protected static final String REMOTE_IP_HEADER_PARAMETER = "remoteIpHeader";
  protected static final String TRUSTED_PROXIES_PARAMETER = "trustedProxies";
  
  protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
  {
    return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern.split(commaDelimitedStrings);
  }
  
  protected static String listToCommaDelimitedString(List<String> stringList)
  {
    if (stringList == null) {
      return "";
    }
    StringBuilder result = new StringBuilder();
    for (Iterator<String> it = stringList.iterator(); it.hasNext();)
    {
      Object element = it.next();
      if (element != null)
      {
        result.append(element);
        if (it.hasNext()) {
          result.append(", ");
        }
      }
    }
    return result.toString();
  }
  
  private int httpServerPort = 80;
  private int httpsServerPort = 443;
  private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
  private String protocolHeader = null;
  private String protocolHeaderHttpsValue = "https";
  private String portHeader = null;
  private boolean changeLocalPort = false;
  private String proxiesHeader = "X-Forwarded-By";
  private String remoteIpHeader = "X-Forwarded-For";
  private boolean requestAttributesEnabled = true;
  private Pattern trustedProxies = null;
  
  public void destroy() {}
  
  public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if ((this.internalProxies != null) && (this.internalProxies.matcher(request.getRemoteAddr()).matches()))
    {
      String remoteIp = null;
      
      LinkedList<String> proxiesHeaderValue = new LinkedList();
      StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
      for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements();)
      {
        if (concatRemoteIpHeaderValue.length() > 0) {
          concatRemoteIpHeaderValue.append(", ");
        }
        concatRemoteIpHeaderValue.append((String)e.nextElement());
      }
      String[] remoteIpHeaderValue = commaDelimitedListToStringArray(concatRemoteIpHeaderValue.toString());
      for (int idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--)
      {
        String currentRemoteIp = remoteIpHeaderValue[idx];
        remoteIp = currentRemoteIp;
        if (!this.internalProxies.matcher(currentRemoteIp).matches()) {
          if ((this.trustedProxies != null) && (this.trustedProxies.matcher(currentRemoteIp).matches()))
          {
            proxiesHeaderValue.addFirst(currentRemoteIp);
          }
          else
          {
            idx--;
            break;
          }
        }
      }
      LinkedList<String> newRemoteIpHeaderValue = new LinkedList();
      for (; idx >= 0; idx--)
      {
        String currentRemoteIp = remoteIpHeaderValue[idx];
        newRemoteIpHeaderValue.addFirst(currentRemoteIp);
      }
      XForwardedRequest xRequest = new XForwardedRequest(request);
      if (remoteIp != null)
      {
        xRequest.setRemoteAddr(remoteIp);
        xRequest.setRemoteHost(remoteIp);
        if (proxiesHeaderValue.size() == 0)
        {
          xRequest.removeHeader(this.proxiesHeader);
        }
        else
        {
          String commaDelimitedListOfProxies = listToCommaDelimitedString(proxiesHeaderValue);
          xRequest.setHeader(this.proxiesHeader, commaDelimitedListOfProxies);
        }
        if (newRemoteIpHeaderValue.size() == 0)
        {
          xRequest.removeHeader(this.remoteIpHeader);
        }
        else
        {
          String commaDelimitedRemoteIpHeaderValue = listToCommaDelimitedString(newRemoteIpHeaderValue);
          xRequest.setHeader(this.remoteIpHeader, commaDelimitedRemoteIpHeaderValue);
        }
      }
      if (this.protocolHeader != null)
      {
        String protocolHeaderValue = request.getHeader(this.protocolHeader);
        if (protocolHeaderValue != null) {
          if (this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue))
          {
            xRequest.setSecure(true);
            xRequest.setScheme("https");
            setPorts(xRequest, this.httpsServerPort);
          }
          else
          {
            xRequest.setSecure(false);
            xRequest.setScheme("http");
            setPorts(xRequest, this.httpServerPort);
          }
        }
      }
      if (log.isDebugEnabled()) {
        log.debug("Incoming request " + request.getRequestURI() + " with originalRemoteAddr '" + request.getRemoteAddr() + "', originalRemoteHost='" + request.getRemoteHost() + "', originalSecure='" + request.isSecure() + "', originalScheme='" + request.getScheme() + "', original[" + this.remoteIpHeader + "]='" + concatRemoteIpHeaderValue + "', original[" + this.protocolHeader + "]='" + (this.protocolHeader == null ? null : request.getHeader(this.protocolHeader)) + "' will be seen as newRemoteAddr='" + xRequest.getRemoteAddr() + "', newRemoteHost='" + xRequest.getRemoteHost() + "', newScheme='" + xRequest.getScheme() + "', newSecure='" + xRequest.isSecure() + "', new[" + this.remoteIpHeader + "]='" + xRequest.getHeader(this.remoteIpHeader) + "', new[" + this.proxiesHeader + "]='" + xRequest.getHeader(this.proxiesHeader) + "'");
      }
      if (this.requestAttributesEnabled)
      {
        request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", xRequest.getRemoteAddr());
        
        request.setAttribute("org.apache.tomcat.remoteAddr", xRequest.getRemoteAddr());
        
        request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", xRequest.getRemoteHost());
        
        request.setAttribute("org.apache.catalina.AccessLog.Protocol", xRequest.getProtocol());
        
        request.setAttribute("org.apache.catalina.AccessLog.ServerPort", Integer.valueOf(xRequest.getServerPort()));
      }
      chain.doFilter(xRequest, response);
    }
    else
    {
      if (log.isDebugEnabled()) {
        log.debug("Skip RemoteIpFilter for request " + request.getRequestURI() + " with originalRemoteAddr '" + request.getRemoteAddr() + "'");
      }
      chain.doFilter(request, response);
    }
  }
  
  private void setPorts(XForwardedRequest xrequest, int defaultPort)
  {
    int port = defaultPort;
    if (getPortHeader() != null)
    {
      String portHeaderValue = xrequest.getHeader(getPortHeader());
      if (portHeaderValue != null) {
        try
        {
          port = Integer.parseInt(portHeaderValue);
        }
        catch (NumberFormatException nfe)
        {
          log.debug("Invalid port value [" + portHeaderValue + "] provided in header [" + getPortHeader() + "]");
        }
      }
    }
    xrequest.setServerPort(port);
    if (isChangeLocalPort()) {
      xrequest.setLocalPort(port);
    }
  }
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse))) {
      doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
    } else {
      chain.doFilter(request, response);
    }
  }
  
  public boolean isChangeLocalPort()
  {
    return this.changeLocalPort;
  }
  
  public int getHttpsServerPort()
  {
    return this.httpsServerPort;
  }
  
  public Pattern getInternalProxies()
  {
    return this.internalProxies;
  }
  
  public String getProtocolHeader()
  {
    return this.protocolHeader;
  }
  
  public String getPortHeader()
  {
    return this.portHeader;
  }
  
  public String getProtocolHeaderHttpsValue()
  {
    return this.protocolHeaderHttpsValue;
  }
  
  public String getProxiesHeader()
  {
    return this.proxiesHeader;
  }
  
  public String getRemoteIpHeader()
  {
    return this.remoteIpHeader;
  }
  
  public boolean getRequestAttributesEnabled()
  {
    return this.requestAttributesEnabled;
  }
  
  public Pattern getTrustedProxies()
  {
    return this.trustedProxies;
  }
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    if (filterConfig.getInitParameter("internalProxies") != null) {
      setInternalProxies(filterConfig.getInitParameter("internalProxies"));
    }
    if (filterConfig.getInitParameter("protocolHeader") != null) {
      setProtocolHeader(filterConfig.getInitParameter("protocolHeader"));
    }
    if (filterConfig.getInitParameter("protocolHeaderHttpsValue") != null) {
      setProtocolHeaderHttpsValue(filterConfig.getInitParameter("protocolHeaderHttpsValue"));
    }
    if (filterConfig.getInitParameter("portHeader") != null) {
      setPortHeader(filterConfig.getInitParameter("portHeader"));
    }
    if (filterConfig.getInitParameter("changeLocalPort") != null) {
      setChangeLocalPort(Boolean.parseBoolean(filterConfig.getInitParameter("changeLocalPort")));
    }
    if (filterConfig.getInitParameter("proxiesHeader") != null) {
      setProxiesHeader(filterConfig.getInitParameter("proxiesHeader"));
    }
    if (filterConfig.getInitParameter("remoteIpHeader") != null) {
      setRemoteIpHeader(filterConfig.getInitParameter("remoteIpHeader"));
    }
    if (filterConfig.getInitParameter("trustedProxies") != null) {
      setTrustedProxies(filterConfig.getInitParameter("trustedProxies"));
    }
    if (filterConfig.getInitParameter("httpServerPort") != null) {
      try
      {
        setHttpServerPort(Integer.parseInt(filterConfig.getInitParameter("httpServerPort")));
      }
      catch (NumberFormatException e)
      {
        throw new NumberFormatException("Illegal httpServerPort : " + e.getMessage());
      }
    }
    if (filterConfig.getInitParameter("httpsServerPort") != null) {
      try
      {
        setHttpsServerPort(Integer.parseInt(filterConfig.getInitParameter("httpsServerPort")));
      }
      catch (NumberFormatException e)
      {
        throw new NumberFormatException("Illegal httpsServerPort : " + e.getMessage());
      }
    }
  }
  
  public void setChangeLocalPort(boolean changeLocalPort)
  {
    this.changeLocalPort = changeLocalPort;
  }
  
  public void setHttpServerPort(int httpServerPort)
  {
    this.httpServerPort = httpServerPort;
  }
  
  public void setHttpsServerPort(int httpsServerPort)
  {
    this.httpsServerPort = httpsServerPort;
  }
  
  public void setInternalProxies(String internalProxies)
  {
    if ((internalProxies == null) || (internalProxies.length() == 0)) {
      this.internalProxies = null;
    } else {
      this.internalProxies = Pattern.compile(internalProxies);
    }
  }
  
  public void setPortHeader(String portHeader)
  {
    this.portHeader = portHeader;
  }
  
  public void setProtocolHeader(String protocolHeader)
  {
    this.protocolHeader = protocolHeader;
  }
  
  public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue)
  {
    this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
  }
  
  public void setProxiesHeader(String proxiesHeader)
  {
    this.proxiesHeader = proxiesHeader;
  }
  
  public void setRemoteIpHeader(String remoteIpHeader)
  {
    this.remoteIpHeader = remoteIpHeader;
  }
  
  public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
  {
    this.requestAttributesEnabled = requestAttributesEnabled;
  }
  
  public void setTrustedProxies(String trustedProxies)
  {
    if ((trustedProxies == null) || (trustedProxies.length() == 0)) {
      this.trustedProxies = null;
    } else {
      this.trustedProxies = Pattern.compile(trustedProxies);
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\RemoteIpFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */