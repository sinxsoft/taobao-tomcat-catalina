package org.apache.catalina.filters;

public final class Constants
{
  public static final String Package = "org.apache.catalina.filters";
  public static final String CSRF_NONCE_SESSION_ATTR_NAME = "org.apache.catalina.filters.CSRF_NONCE";
  public static final String CSRF_NONCE_REQUEST_PARAM = "org.apache.catalina.filters.CSRF_NONCE";
  public static final String METHOD_GET = "GET";
  
  public Constants() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */