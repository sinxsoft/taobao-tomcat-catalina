package org.apache.catalina.filters;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.catalina.comet.CometEvent;
import org.apache.catalina.comet.CometFilterChain;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public final class RemoteAddrFilter
  extends RequestFilter
{
  private static final Log log = LogFactory.getLog(RemoteAddrFilter.class);
  
  public RemoteAddrFilter() {}
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    process(request.getRemoteAddr(), request, response, chain);
  }
  
  public void doFilterEvent(CometEvent event, CometFilterChain chain)
    throws IOException, ServletException
  {
    processCometEvent(event.getHttpServletRequest().getRemoteAddr(), event, chain);
  }
  
  protected Log getLogger()
  {
    return log;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\RemoteAddrFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */