package org.apache.catalina.filters;

import java.util.Enumeration;
import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.IntrospectionUtils;
import org.apache.tomcat.util.res.StringManager;

public abstract class FilterBase
  implements Filter
{
  protected static final StringManager sm = StringManager.getManager("org.apache.catalina.filters");
  
  public FilterBase() {}
  
  protected abstract Log getLogger();
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    Enumeration<String> paramNames = filterConfig.getInitParameterNames();
    while (paramNames.hasMoreElements())
    {
      String paramName = (String)paramNames.nextElement();
      if (!IntrospectionUtils.setProperty(this, paramName, filterConfig.getInitParameter(paramName)))
      {
        String msg = sm.getString("filterbase.noSuchProperty", new Object[] { paramName, getClass().getName() });
        if (isConfigProblemFatal()) {
          throw new ServletException(msg);
        }
        getLogger().warn(msg);
      }
    }
  }
  
  public void destroy() {}
  
  protected boolean isConfigProblemFatal()
  {
    return false;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\FilterBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */