package org.apache.catalina.filters;

import java.io.IOException;
import java.io.Serializable;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpSession;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class CsrfPreventionFilter
  extends FilterBase
{
  private static final Log log = LogFactory.getLog(CsrfPreventionFilter.class);
  private String randomClass;
  private Random randomSource;
  private int denyStatus;
  private final Set<String> entryPoints;
  private int nonceCacheSize;
  
  public CsrfPreventionFilter()
  {
    this.randomClass = SecureRandom.class.getName();
    
    this.denyStatus = 403;
    
    this.entryPoints = new HashSet();
    
    this.nonceCacheSize = 5;
  }
  
  protected Log getLogger()
  {
    return log;
  }
  
  public int getDenyStatus()
  {
    return this.denyStatus;
  }
  
  public void setDenyStatus(int denyStatus)
  {
    this.denyStatus = denyStatus;
  }
  
  public void setEntryPoints(String entryPoints)
  {
    String[] values = entryPoints.split(",");
    for (String value : values) {
      this.entryPoints.add(value.trim());
    }
  }
  
  public void setNonceCacheSize(int nonceCacheSize)
  {
    this.nonceCacheSize = nonceCacheSize;
  }
  
  public void setRandomClass(String randomClass)
  {
    this.randomClass = randomClass;
  }
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    super.init(filterConfig);
    try
    {
      Class<?> clazz = Class.forName(this.randomClass);
      this.randomSource = ((Random)clazz.newInstance());
    }
    catch (ClassNotFoundException e)
    {
      ServletException se = new ServletException(sm.getString("csrfPrevention.invalidRandomClass", new Object[] { this.randomClass }), e);
      
      throw se;
    }
    catch (InstantiationException e)
    {
      ServletException se = new ServletException(sm.getString("csrfPrevention.invalidRandomClass", new Object[] { this.randomClass }), e);
      
      throw se;
    }
    catch (IllegalAccessException e)
    {
      ServletException se = new ServletException(sm.getString("csrfPrevention.invalidRandomClass", new Object[] { this.randomClass }), e);
      
      throw se;
    }
  }
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    ServletResponse wResponse = null;
    if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
    {
      HttpServletRequest req = (HttpServletRequest)request;
      HttpServletResponse res = (HttpServletResponse)response;
      
      boolean skipNonceCheck = false;
      if ("GET".equals(req.getMethod()))
      {
        String path = req.getServletPath();
        if (req.getPathInfo() != null) {
          path = path + req.getPathInfo();
        }
        if (this.entryPoints.contains(path)) {
          skipNonceCheck = true;
        }
      }
      HttpSession session = req.getSession(false);
      
      LruCache<String> nonceCache = session == null ? null : (LruCache)session.getAttribute("org.apache.catalina.filters.CSRF_NONCE");
      if (!skipNonceCheck)
      {
        String previousNonce = req.getParameter("org.apache.catalina.filters.CSRF_NONCE");
        if ((nonceCache == null) || (previousNonce == null) || (!nonceCache.contains(previousNonce)))
        {
          res.sendError(this.denyStatus);
          return;
        }
      }
      if (nonceCache == null)
      {
        nonceCache = new LruCache(this.nonceCacheSize);
        if (session == null) {
          session = req.getSession(true);
        }
        session.setAttribute("org.apache.catalina.filters.CSRF_NONCE", nonceCache);
      }
      String newNonce = generateNonce();
      
      nonceCache.add(newNonce);
      
      wResponse = new CsrfResponseWrapper(res, newNonce);
    }
    else
    {
      wResponse = response;
    }
    chain.doFilter(request, wResponse);
  }
  
  protected boolean isConfigProblemFatal()
  {
    return true;
  }
  
  protected String generateNonce()
  {
    byte[] random = new byte[16];
    
    StringBuilder buffer = new StringBuilder();
    
    this.randomSource.nextBytes(random);
    for (int j = 0; j < random.length; j++)
    {
      byte b1 = (byte)((random[j] & 0xF0) >> 4);
      byte b2 = (byte)(random[j] & 0xF);
      if (b1 < 10) {
        buffer.append((char)(48 + b1));
      } else {
        buffer.append((char)(65 + (b1 - 10)));
      }
      if (b2 < 10) {
        buffer.append((char)(48 + b2));
      } else {
        buffer.append((char)(65 + (b2 - 10)));
      }
    }
    return buffer.toString();
  }
  
  protected static class CsrfResponseWrapper
    extends HttpServletResponseWrapper
  {
    private final String nonce;
    
    public CsrfResponseWrapper(HttpServletResponse response, String nonce)
    {
      super();
      this.nonce = nonce;
    }
    
    @Deprecated
    public String encodeRedirectUrl(String url)
    {
      return encodeRedirectURL(url);
    }
    
    public String encodeRedirectURL(String url)
    {
      return addNonce(super.encodeRedirectURL(url));
    }
    
    @Deprecated
    public String encodeUrl(String url)
    {
      return encodeURL(url);
    }
    
    public String encodeURL(String url)
    {
      return addNonce(super.encodeURL(url));
    }
    
    private String addNonce(String url)
    {
      if ((url == null) || (this.nonce == null)) {
        return url;
      }
      String path = url;
      String query = "";
      String anchor = "";
      int pound = path.indexOf('#');
      if (pound >= 0)
      {
        anchor = path.substring(pound);
        path = path.substring(0, pound);
      }
      int question = path.indexOf('?');
      if (question >= 0)
      {
        query = path.substring(question);
        path = path.substring(0, question);
      }
      StringBuilder sb = new StringBuilder(path);
      if (query.length() > 0)
      {
        sb.append(query);
        sb.append('&');
      }
      else
      {
        sb.append('?');
      }
      sb.append("org.apache.catalina.filters.CSRF_NONCE");
      sb.append('=');
      sb.append(this.nonce);
      sb.append(anchor);
      return sb.toString();
    }
  }
  
  protected static class LruCache<T>
    implements Serializable
  {
    private static final long serialVersionUID = 1L;
    private final Map<T, T> cache;
    
    public LruCache(final int cacheSize)
    {
      this.cache = new LinkedHashMap()
      {
        private static final long serialVersionUID = 1L;
        
        protected boolean removeEldestEntry(Map.Entry<T, T> eldest)
        {
          if (size() > cacheSize) {
            return true;
          }
          return false;
        }
      };
    }
    
    public void add(T key)
    {
      synchronized (this.cache)
      {
        this.cache.put(key, null);
      }
    }
    
    /* Error */
    public boolean contains(T key)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 4	org/apache/catalina/filters/CsrfPreventionFilter$LruCache:cache	Ljava/util/Map;
      //   4: dup
      //   5: astore_2
      //   6: monitorenter
      //   7: aload_0
      //   8: getfield 4	org/apache/catalina/filters/CsrfPreventionFilter$LruCache:cache	Ljava/util/Map;
      //   11: aload_1
      //   12: invokeinterface 6 2 0
      //   17: aload_2
      //   18: monitorexit
      //   19: ireturn
      //   20: astore_3
      //   21: aload_2
      //   22: monitorexit
      //   23: aload_3
      //   24: athrow
      // Line number table:
      //   Java source line #355	-> byte code offset #0
      //   Java source line #356	-> byte code offset #7
      //   Java source line #357	-> byte code offset #20
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	25	0	this	LruCache<T>
      //   0	25	1	key	T
      //   5	17	2	Ljava/lang/Object;	Object
      //   20	4	3	localObject1	Object
      // Exception table:
      //   from	to	target	type
      //   7	19	20	finally
      //   20	23	20	finally
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\CsrfPreventionFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */