package org.apache.catalina.filters;

import java.io.IOException;
import java.nio.charset.Charset;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class AddDefaultCharsetFilter
  extends FilterBase
{
  private static final Log log = LogFactory.getLog(AddDefaultCharsetFilter.class);
  private static final String DEFAULT_ENCODING = "ISO-8859-1";
  private String encoding;
  
  public AddDefaultCharsetFilter() {}
  
  public void setEncoding(String encoding)
  {
    this.encoding = encoding;
  }
  
  protected Log getLogger()
  {
    return log;
  }
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    super.init(filterConfig);
    if ((this.encoding == null) || (this.encoding.length() == 0) || (this.encoding.equalsIgnoreCase("default"))) {
      this.encoding = "ISO-8859-1";
    } else if (this.encoding.equalsIgnoreCase("system")) {
      this.encoding = Charset.defaultCharset().name();
    } else if (!Charset.isSupported(this.encoding)) {
      throw new IllegalArgumentException(sm.getString("addDefaultCharset.unsupportedCharset", new Object[] { this.encoding }));
    }
  }
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if ((response instanceof HttpServletResponse))
    {
      ResponseWrapper wrapped = new ResponseWrapper((HttpServletResponse)response, this.encoding);
      
      chain.doFilter(request, wrapped);
    }
    else
    {
      chain.doFilter(request, response);
    }
  }
  
  public static class ResponseWrapper
    extends HttpServletResponseWrapper
  {
    private String encoding;
    
    public ResponseWrapper(HttpServletResponse response, String encoding)
    {
      super();
      this.encoding = encoding;
    }
    
    public void setContentType(String ct)
    {
      if ((ct != null) && (ct.startsWith("text/")))
      {
        if (ct.indexOf("charset=") < 0)
        {
          super.setContentType(ct + ";charset=" + this.encoding);
        }
        else
        {
          super.setContentType(ct);
          this.encoding = getCharacterEncoding();
        }
      }
      else {
        super.setContentType(ct);
      }
    }
    
    public void setCharacterEncoding(String charset)
    {
      super.setCharacterEncoding(charset);
      this.encoding = charset;
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\filters\AddDefaultCharsetFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */