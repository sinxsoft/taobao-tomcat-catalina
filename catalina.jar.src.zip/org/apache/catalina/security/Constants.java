package org.apache.catalina.security;

public class Constants
{
  public static final String PACKAGE = "org.apache.catalina.security";
  public static final String LINE_SEP = System.getProperty("line.separator");
  public static final String CRLF = "\r\n";
  
  public Constants() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\security\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */