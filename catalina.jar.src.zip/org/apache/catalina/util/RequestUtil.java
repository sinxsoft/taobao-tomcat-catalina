package org.apache.catalina.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Map;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.buf.B2CConverter;
import org.apache.tomcat.util.res.StringManager;

public final class RequestUtil
{
  private static final Log log = LogFactory.getLog(RequestUtil.class);
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
  
  public RequestUtil() {}
  
  public static String filter(String message)
  {
    if (message == null) {
      return null;
    }
    char[] content = new char[message.length()];
    message.getChars(0, message.length(), content, 0);
    StringBuilder result = new StringBuilder(content.length + 50);
    for (int i = 0; i < content.length; i++) {
      switch (content[i])
      {
      case '<': 
        result.append("&lt;");
        break;
      case '>': 
        result.append("&gt;");
        break;
      case '&': 
        result.append("&amp;");
        break;
      case '"': 
        result.append("&quot;");
        break;
      default: 
        result.append(content[i]);
      }
    }
    return result.toString();
  }
  
  @Deprecated
  public static String normalize(String path)
  {
    return org.apache.tomcat.util.http.RequestUtil.normalize(path);
  }
  
  @Deprecated
  public static String normalize(String path, boolean replaceBackSlash)
  {
    return org.apache.tomcat.util.http.RequestUtil.normalize(path, replaceBackSlash);
  }
  
  public static void parseParameters(Map<String, String[]> map, String data, String encoding)
  {
    if ((data != null) && (data.length() > 0))
    {
      byte[] bytes = null;
      try
      {
        bytes = data.getBytes(B2CConverter.getCharset(encoding));
        parseParameters(map, bytes, encoding);
      }
      catch (UnsupportedEncodingException uee)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("requestUtil.parseParameters.uee", new Object[] { encoding }), uee);
        }
      }
    }
  }
  
  public static String URLDecode(String str)
  {
    return URLDecode(str, null);
  }
  
  public static String URLDecode(String str, String enc)
  {
    return URLDecode(str, enc, false);
  }
  
  public static String URLDecode(String str, String enc, boolean isQuery)
  {
    if (str == null) {
      return null;
    }
    byte[] bytes = null;
    try
    {
      if (enc == null) {
        bytes = str.getBytes(Charset.defaultCharset());
      } else {
        bytes = str.getBytes(B2CConverter.getCharset(enc));
      }
    }
    catch (UnsupportedEncodingException uee)
    {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("requestUtil.urlDecode.uee", new Object[] { enc }), uee);
      }
    }
    return URLDecode(bytes, enc, isQuery);
  }
  
  public static String URLDecode(byte[] bytes)
  {
    return URLDecode(bytes, null);
  }
  
  @Deprecated
  public static String URLDecode(byte[] bytes, String enc)
  {
    return URLDecode(bytes, enc, false);
  }
  
  public static String URLDecode(byte[] bytes, String enc, boolean isQuery)
  {
    if (bytes == null) {
      return null;
    }
    int len = bytes.length;
    int ix = 0;
    int ox = 0;
    while (ix < len)
    {
      byte b = bytes[(ix++)];
      if ((b == 43) && (isQuery))
      {
        b = 32;
      }
      else if (b == 37)
      {
        if (ix + 2 > len) {
          throw new IllegalArgumentException(sm.getString("requestUtil.urlDecode.missingDigit"));
        }
        b = (byte)((convertHexDigit(bytes[(ix++)]) << 4) + convertHexDigit(bytes[(ix++)]));
      }
      bytes[(ox++)] = b;
    }
    if (enc != null) {
      try
      {
        return new String(bytes, 0, ox, B2CConverter.getCharset(enc));
      }
      catch (UnsupportedEncodingException uee)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("requestUtil.urlDecode.uee", new Object[] { enc }), uee);
        }
        return null;
      }
    }
    return new String(bytes, 0, ox);
  }
  
  private static byte convertHexDigit(byte b)
  {
    if ((b >= 48) && (b <= 57)) {
      return (byte)(b - 48);
    }
    if ((b >= 97) && (b <= 102)) {
      return (byte)(b - 97 + 10);
    }
    if ((b >= 65) && (b <= 70)) {
      return (byte)(b - 65 + 10);
    }
    throw new IllegalArgumentException(sm.getString("requestUtil.convertHexDigit.notHex", new Object[] { Character.valueOf((char)b) }));
  }
  
  private static void putMapEntry(Map<String, String[]> map, String name, String value)
  {
    String[] newValues = null;
    String[] oldValues = (String[])map.get(name);
    if (oldValues == null)
    {
      newValues = new String[1];
      newValues[0] = value;
    }
    else
    {
      newValues = new String[oldValues.length + 1];
      System.arraycopy(oldValues, 0, newValues, 0, oldValues.length);
      newValues[oldValues.length] = value;
    }
    map.put(name, newValues);
  }
  
  public static void parseParameters(Map<String, String[]> map, byte[] data, String encoding)
    throws UnsupportedEncodingException
  {
    Charset charset = B2CConverter.getCharset(encoding);
    if ((data != null) && (data.length > 0))
    {
      int ix = 0;
      int ox = 0;
      String key = null;
      String value = null;
      while (ix < data.length)
      {
        byte c = data[(ix++)];
        switch ((char)c)
        {
        case '&': 
          value = new String(data, 0, ox, charset);
          if (key != null)
          {
            putMapEntry(map, key, value);
            key = null;
          }
          ox = 0;
          break;
        case '=': 
          if (key == null)
          {
            key = new String(data, 0, ox, charset);
            ox = 0;
          }
          else
          {
            data[(ox++)] = c;
          }
          break;
        case '+': 
          data[(ox++)] = 32;
          break;
        case '%': 
          data[(ox++)] = ((byte)((convertHexDigit(data[(ix++)]) << 4) + convertHexDigit(data[(ix++)])));
          
          break;
        default: 
          data[(ox++)] = c;
        }
      }
      if (key != null)
      {
        value = new String(data, 0, ox, charset);
        putMapEntry(map, key, value);
      }
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\RequestUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */