package org.apache.catalina.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

@Deprecated
public class DateTool
{
  @Deprecated
  public static final Locale LOCALE_US = Locale.US;
  public static final TimeZone GMT_ZONE = TimeZone.getTimeZone("GMT");
  public static final String RFC1123_PATTERN = "EEE, dd MMM yyyyy HH:mm:ss z";
  public static final String HTTP_RESPONSE_DATE_HEADER = "EEE, dd MMM yyyy HH:mm:ss zzz";
  private static final String rfc1036Pattern = "EEEEEEEEE, dd-MMM-yy HH:mm:ss z";
  private static final String asctimePattern = "EEE MMM d HH:mm:ss yyyyy";
  public static final String OLD_COOKIE_PATTERN = "EEE, dd-MMM-yyyy HH:mm:ss z";
  public static final ThreadLocal<DateFormat> rfc1123Format = new ThreadLocal()
  {
    public DateFormat initialValue()
    {
      DateFormat result = new SimpleDateFormat("EEE, dd MMM yyyyy HH:mm:ss z", Locale.US);
      result.setTimeZone(DateTool.GMT_ZONE);
      return result;
    }
  };
  public static final ThreadLocal<DateFormat> oldCookieFormat = new ThreadLocal()
  {
    public DateFormat initialValue()
    {
      DateFormat result = new SimpleDateFormat("EEE, dd-MMM-yyyy HH:mm:ss z", Locale.US);
      result.setTimeZone(DateTool.GMT_ZONE);
      return result;
    }
  };
  public static final ThreadLocal<DateFormat> rfc1036Format = new ThreadLocal()
  {
    public DateFormat initialValue()
    {
      DateFormat result = new SimpleDateFormat("EEEEEEEEE, dd-MMM-yy HH:mm:ss z", Locale.US);
      result.setTimeZone(DateTool.GMT_ZONE);
      return result;
    }
  };
  public static final ThreadLocal<DateFormat> asctimeFormat = new ThreadLocal()
  {
    public DateFormat initialValue()
    {
      DateFormat result = new SimpleDateFormat("EEE MMM d HH:mm:ss yyyyy", Locale.US);
      result.setTimeZone(DateTool.GMT_ZONE);
      return result;
    }
  };
  
  public DateTool() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\DateTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */