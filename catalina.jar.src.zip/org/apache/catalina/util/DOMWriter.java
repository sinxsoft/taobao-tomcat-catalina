package org.apache.catalina.util;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOMWriter
{
  private static String PRINTWRITER_ENCODING = "UTF8";
  private static String[] MIME2JAVA_ENCODINGS = { "Default", "UTF-8", "US-ASCII", "ISO-8859-1", "ISO-8859-2", "ISO-8859-3", "ISO-8859-4", "ISO-8859-5", "ISO-8859-6", "ISO-8859-7", "ISO-8859-8", "ISO-8859-9", "ISO-2022-JP", "SHIFT_JIS", "EUC-JP", "GB2312", "BIG5", "EUC-KR", "ISO-2022-KR", "KOI8-R", "EBCDIC-CP-US", "EBCDIC-CP-CA", "EBCDIC-CP-NL", "EBCDIC-CP-DK", "EBCDIC-CP-NO", "EBCDIC-CP-FI", "EBCDIC-CP-SE", "EBCDIC-CP-IT", "EBCDIC-CP-ES", "EBCDIC-CP-GB", "EBCDIC-CP-FR", "EBCDIC-CP-AR1", "EBCDIC-CP-HE", "EBCDIC-CP-CH", "EBCDIC-CP-ROECE", "EBCDIC-CP-YU", "EBCDIC-CP-IS", "EBCDIC-CP-AR2", "UTF-16" };
  private boolean qualifiedNames = true;
  protected PrintWriter out;
  protected boolean canonical;
  
  @Deprecated
  public DOMWriter(String encoding, boolean canonical)
    throws UnsupportedEncodingException
  {
    this.out = new PrintWriter(new OutputStreamWriter(System.out, encoding));
    this.canonical = canonical;
  }
  
  @Deprecated
  public DOMWriter(boolean canonical)
    throws UnsupportedEncodingException
  {
    this(getWriterEncoding(), canonical);
  }
  
  public DOMWriter(Writer writer, boolean canonical)
  {
    this.out = new PrintWriter(writer);
    this.canonical = canonical;
  }
  
  @Deprecated
  public boolean getQualifiedNames()
  {
    return this.qualifiedNames;
  }
  
  @Deprecated
  public void setQualifiedNames(boolean qualifiedNames)
  {
    this.qualifiedNames = qualifiedNames;
  }
  
  public static String getWriterEncoding()
  {
    return PRINTWRITER_ENCODING;
  }
  
  @Deprecated
  public static void setWriterEncoding(String encoding)
  {
    if (encoding.equalsIgnoreCase("DEFAULT")) {
      PRINTWRITER_ENCODING = "UTF8";
    } else if (encoding.equalsIgnoreCase("UTF-16")) {
      PRINTWRITER_ENCODING = "Unicode";
    } else {
      PRINTWRITER_ENCODING = MIME2Java.convert(encoding);
    }
  }
  
  @Deprecated
  public static boolean isValidJavaEncoding(String encoding)
  {
    for (int i = 0; i < MIME2JAVA_ENCODINGS.length; i++) {
      if (encoding.equals(MIME2JAVA_ENCODINGS[i])) {
        return true;
      }
    }
    return false;
  }
  
  public void print(Node node)
  {
    if (node == null) {
      return;
    }
    int type = node.getNodeType();
    switch (type)
    {
    case 9: 
      if (!this.canonical)
      {
        String Encoding = getWriterEncoding();
        if (Encoding.equalsIgnoreCase("DEFAULT")) {
          Encoding = "UTF-8";
        } else if (Encoding.equalsIgnoreCase("Unicode")) {
          Encoding = "UTF-16";
        } else {
          Encoding = MIME2Java.reverse(Encoding);
        }
        this.out.println("<?xml version=\"1.0\" encoding=\"" + Encoding + "\"?>");
      }
      print(((Document)node).getDocumentElement());
      this.out.flush();
      break;
    case 1: 
      this.out.print('<');
      if (this.qualifiedNames) {
        this.out.print(node.getNodeName());
      } else {
        this.out.print(node.getLocalName());
      }
      Attr[] attrs = sortAttributes(node.getAttributes());
      for (int i = 0; i < attrs.length; i++)
      {
        Attr attr = attrs[i];
        this.out.print(' ');
        if (this.qualifiedNames) {
          this.out.print(attr.getNodeName());
        } else {
          this.out.print(attr.getLocalName());
        }
        this.out.print("=\"");
        this.out.print(normalize(attr.getNodeValue()));
        this.out.print('"');
      }
      this.out.print('>');
      NodeList children = node.getChildNodes();
      if (children != null)
      {
        int len = children.getLength();
        for (int i = 0; i < len; i++) {
          print(children.item(i));
        }
      }
      break;
    case 5: 
      if (this.canonical)
      {
        NodeList children = node.getChildNodes();
        if (children != null)
        {
          int len = children.getLength();
          for (int i = 0; i < len; i++) {
            print(children.item(i));
          }
        }
      }
      else
      {
        this.out.print('&');
        if (this.qualifiedNames) {
          this.out.print(node.getNodeName());
        } else {
          this.out.print(node.getLocalName());
        }
        this.out.print(';');
      }
      break;
    case 4: 
      if (this.canonical)
      {
        this.out.print(normalize(node.getNodeValue()));
      }
      else
      {
        this.out.print("<![CDATA[");
        this.out.print(node.getNodeValue());
        this.out.print("]]>");
      }
      break;
    case 3: 
      this.out.print(normalize(node.getNodeValue()));
      break;
    case 7: 
      this.out.print("<?");
      if (this.qualifiedNames) {
        this.out.print(node.getNodeName());
      } else {
        this.out.print(node.getLocalName());
      }
      String data = node.getNodeValue();
      if ((data != null) && (data.length() > 0))
      {
        this.out.print(' ');
        this.out.print(data);
      }
      this.out.print("?>");
      break;
    }
    if (type == 1)
    {
      this.out.print("</");
      if (this.qualifiedNames) {
        this.out.print(node.getNodeName());
      } else {
        this.out.print(node.getLocalName());
      }
      this.out.print('>');
    }
    this.out.flush();
  }
  
  protected Attr[] sortAttributes(NamedNodeMap attrs)
  {
    if (attrs == null) {
      return new Attr[0];
    }
    int len = attrs.getLength();
    Attr[] array = new Attr[len];
    for (int i = 0; i < len; i++) {
      array[i] = ((Attr)attrs.item(i));
    }
    for (int i = 0; i < len - 1; i++)
    {
      String name = null;
      if (this.qualifiedNames) {
        name = array[i].getNodeName();
      } else {
        name = array[i].getLocalName();
      }
      int index = i;
      for (int j = i + 1; j < len; j++)
      {
        String curName = null;
        if (this.qualifiedNames) {
          curName = array[j].getNodeName();
        } else {
          curName = array[j].getLocalName();
        }
        if (curName.compareTo(name) < 0)
        {
          name = curName;
          index = j;
        }
      }
      if (index != i)
      {
        Attr temp = array[i];
        array[i] = array[index];
        array[index] = temp;
      }
    }
    return array;
  }
  
  protected String normalize(String s)
  {
    if (s == null) {
      return "";
    }
    StringBuilder str = new StringBuilder();
    
    int len = s.length();
    for (int i = 0; i < len; i++)
    {
      char ch = s.charAt(i);
      switch (ch)
      {
      case '<': 
        str.append("&lt;");
        break;
      case '>': 
        str.append("&gt;");
        break;
      case '&': 
        str.append("&amp;");
        break;
      case '"': 
        str.append("&quot;");
        break;
      case '\n': 
      case '\r': 
        if (this.canonical)
        {
          str.append("&#");
          str.append(Integer.toString(ch));
          str.append(';');
        }
        break;
      }
      str.append(ch);
    }
    return str.toString();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\DOMWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */