package org.apache.catalina.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;
import org.apache.tomcat.util.ExceptionUtils;

public class CharsetMapper
{
  public static final String DEFAULT_RESOURCE = "/org/apache/catalina/util/CharsetMapperDefault.properties";
  
  public CharsetMapper()
  {
    this("/org/apache/catalina/util/CharsetMapperDefault.properties");
  }
  
  public CharsetMapper(String name)
  {
    InputStream stream = null;
    try
    {
      stream = getClass().getResourceAsStream(name);
      this.map.load(stream); return;
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      throw new IllegalArgumentException(t.toString());
    }
    finally
    {
      if (stream != null) {
        try
        {
          stream.close();
        }
        catch (IOException e) {}
      }
    }
  }
  
  private Properties map = new Properties();
  
  public String getCharset(Locale locale)
  {
    String charset = this.map.getProperty(locale.toString());
    if (charset == null)
    {
      charset = this.map.getProperty(locale.getLanguage() + "_" + locale.getCountry());
      if (charset == null) {
        charset = this.map.getProperty(locale.getLanguage());
      }
    }
    return charset;
  }
  
  public void addCharsetMappingFromDeploymentDescriptor(String locale, String charset)
  {
    this.map.put(locale, charset);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\CharsetMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */