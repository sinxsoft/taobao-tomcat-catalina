package org.apache.catalina.util;

public class StandardSessionIdGenerator
  extends SessionIdGeneratorBase
{
  public StandardSessionIdGenerator() {}
  
  public String generateSessionId(String route)
  {
    byte[] random = new byte[16];
    int sessionIdLength = getSessionIdLength();
    
    StringBuilder buffer = new StringBuilder(2 * sessionIdLength + 20);
    
    int resultLenBytes = 0;
    for (; resultLenBytes < sessionIdLength; goto 42)
    {
      getRandomBytes(random);
      int j = 0;
      if ((j < random.length) && (resultLenBytes < sessionIdLength))
      {
        byte b1 = (byte)((random[j] & 0xF0) >> 4);
        byte b2 = (byte)(random[j] & 0xF);
        if (b1 < 10) {
          buffer.append((char)(48 + b1));
        } else {
          buffer.append((char)(65 + (b1 - 10)));
        }
        if (b2 < 10) {
          buffer.append((char)(48 + b2));
        } else {
          buffer.append((char)(65 + (b2 - 10)));
        }
        resultLenBytes++;j++;
      }
    }
    if ((route != null) && (route.length() > 0))
    {
      buffer.append('.').append(route);
    }
    else
    {
      String jvmRoute = getJvmRoute();
      if ((jvmRoute != null) && (jvmRoute.length() > 0)) {
        buffer.append('.').append(jvmRoute);
      }
    }
    return buffer.toString();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\StandardSessionIdGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */