package org.apache.catalina.util;

import java.beans.Introspector;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.apache.catalina.Container;
import org.apache.catalina.Globals;
import org.apache.catalina.Loader;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public class Introspection
{
  private static StringManager sm = StringManager.getManager("org.apache.catalina.util");
  
  public Introspection() {}
  
  public static String getPropertyName(Method setter)
  {
    return Introspector.decapitalize(setter.getName().substring(3));
  }
  
  public static boolean isValidSetter(Method method)
  {
    if ((method.getName().startsWith("set")) && (method.getName().length() > 3) && (method.getParameterTypes().length == 1) && (method.getReturnType().getName().equals("void"))) {
      return true;
    }
    return false;
  }
  
  public static boolean isValidLifecycleCallback(Method method)
  {
    if ((method.getParameterTypes().length != 0) || (Modifier.isStatic(method.getModifiers())) || (method.getExceptionTypes().length > 0) || (!method.getReturnType().getName().equals("void"))) {
      return false;
    }
    return true;
  }
  
  public static Field[] getDeclaredFields(Class<?> clazz)
  {
    Field[] fields = null;
    if (Globals.IS_SECURITY_ENABLED) {
      fields = (Field[])AccessController.doPrivileged(new PrivilegedAction()
      {
        public Field[] run()
        {
          return this.val$clazz.getDeclaredFields();
        }
      });
    } else {
      fields = clazz.getDeclaredFields();
    }
    return fields;
  }
  
  public static Method[] getDeclaredMethods(Class<?> clazz)
  {
    Method[] methods = null;
    if (Globals.IS_SECURITY_ENABLED) {
      methods = (Method[])AccessController.doPrivileged(new PrivilegedAction()
      {
        public Method[] run()
        {
          return this.val$clazz.getDeclaredMethods();
        }
      });
    } else {
      methods = clazz.getDeclaredMethods();
    }
    return methods;
  }
  
  public static Class<?> loadClass(Container container, String className)
  {
    ClassLoader cl = container.getLoader().getClassLoader();
    Log log = container.getLogger();
    Class<?> clazz = null;
    try
    {
      clazz = cl.loadClass(className);
    }
    catch (ClassNotFoundException e)
    {
      log.debug(sm.getString("introspection.classLoadFailed"), e);
    }
    catch (NoClassDefFoundError e)
    {
      log.debug(sm.getString("introspection.classLoadFailed"), e);
    }
    catch (ClassFormatError e)
    {
      log.debug(sm.getString("introspection.classLoadFailed"), e);
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      log.debug(sm.getString("introspection.classLoadFailed"), t);
    }
    return clazz;
  }
  
  public static Class<?> convertPrimitiveType(Class<?> clazz)
  {
    if (clazz.equals(Character.TYPE)) {
      return Character.class;
    }
    if (clazz.equals(Integer.TYPE)) {
      return Integer.class;
    }
    if (clazz.equals(Boolean.TYPE)) {
      return Boolean.class;
    }
    if (clazz.equals(Double.TYPE)) {
      return Double.class;
    }
    if (clazz.equals(Byte.TYPE)) {
      return Byte.class;
    }
    if (clazz.equals(Short.TYPE)) {
      return Short.class;
    }
    if (clazz.equals(Long.TYPE)) {
      return Long.class;
    }
    if (clazz.equals(Float.TYPE)) {
      return Float.class;
    }
    return clazz;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\Introspection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */