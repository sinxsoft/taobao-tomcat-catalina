package org.apache.catalina.util;

import javax.servlet.ServletContext;
import javax.servlet.SessionCookieConfig;
import org.apache.catalina.Context;

public class SessionConfig
{
  private static final String DEFAULT_SESSION_COOKIE_NAME = "JSESSIONID";
  private static final String DEFAULT_SESSION_PARAMETER_NAME = "jsessionid";
  
  public static String getSessionCookieName(Context context)
  {
    String result = getConfiguredSessionCookieName(context);
    if (result == null) {
      result = "JSESSIONID";
    }
    return result;
  }
  
  public static String getSessionUriParamName(Context context)
  {
    String result = getConfiguredSessionCookieName(context);
    if (result == null) {
      result = "jsessionid";
    }
    return result;
  }
  
  private static String getConfiguredSessionCookieName(Context context)
  {
    if (context != null)
    {
      String cookieName = context.getSessionCookieName();
      if ((cookieName != null) && (cookieName.length() > 0)) {
        return cookieName;
      }
      SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
      
      cookieName = scc.getName();
      if ((cookieName != null) && (cookieName.length() > 0)) {
        return cookieName;
      }
    }
    return null;
  }
  
  private SessionConfig() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\SessionConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */