package org.apache.catalina.util;

import java.util.Collection;
import java.util.HashSet;
import org.apache.tomcat.util.res.StringManager;

public final class ResourceSet<T>
  extends HashSet<T>
{
  private static final long serialVersionUID = 1L;
  
  public ResourceSet() {}
  
  public ResourceSet(int initialCapacity)
  {
    super(initialCapacity);
  }
  
  public ResourceSet(int initialCapacity, float loadFactor)
  {
    super(initialCapacity, loadFactor);
  }
  
  public ResourceSet(Collection<T> coll)
  {
    super(coll);
  }
  
  private boolean locked = false;
  
  public boolean isLocked()
  {
    return this.locked;
  }
  
  public void setLocked(boolean locked)
  {
    this.locked = locked;
  }
  
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
  
  public boolean add(T o)
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("resourceSet.locked"));
    }
    return super.add(o);
  }
  
  public void clear()
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("resourceSet.locked"));
    }
    super.clear();
  }
  
  public boolean remove(Object o)
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("resourceSet.locked"));
    }
    return super.remove(o);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\ResourceSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */