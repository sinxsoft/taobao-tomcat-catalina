package org.apache.catalina.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@Deprecated
public final class Enumerator<T>
  implements Enumeration<T>
{
  public Enumerator(Collection<T> collection)
  {
    this(collection.iterator());
  }
  
  public Enumerator(Collection<T> collection, boolean clone)
  {
    this(collection.iterator(), clone);
  }
  
  public Enumerator(Iterator<T> iterator)
  {
    this.iterator = iterator;
  }
  
  public Enumerator(Iterator<T> iterator, boolean clone)
  {
    if (!clone)
    {
      this.iterator = iterator;
    }
    else
    {
      List<T> list = new ArrayList();
      while (iterator.hasNext()) {
        list.add(iterator.next());
      }
      this.iterator = list.iterator();
    }
  }
  
  public Enumerator(Map<?, T> map)
  {
    this(map.values().iterator());
  }
  
  public Enumerator(Map<?, T> map, boolean clone)
  {
    this(map.values().iterator(), clone);
  }
  
  private Iterator<T> iterator = null;
  
  public boolean hasMoreElements()
  {
    return this.iterator.hasNext();
  }
  
  public T nextElement()
    throws NoSuchElementException
  {
    return (T)this.iterator.next();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\Enumerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */