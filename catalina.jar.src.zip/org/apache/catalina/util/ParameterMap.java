package org.apache.catalina.util;

import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.tomcat.util.res.StringManager;

public final class ParameterMap<K, V>
  extends LinkedHashMap<K, V>
{
  private static final long serialVersionUID = 1L;
  
  public ParameterMap() {}
  
  public ParameterMap(int initialCapacity)
  {
    super(initialCapacity);
  }
  
  public ParameterMap(int initialCapacity, float loadFactor)
  {
    super(initialCapacity, loadFactor);
  }
  
  public ParameterMap(Map<K, V> map)
  {
    super(map);
  }
  
  private boolean locked = false;
  
  public boolean isLocked()
  {
    return this.locked;
  }
  
  public void setLocked(boolean locked)
  {
    this.locked = locked;
  }
  
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
  
  public void clear()
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("parameterMap.locked"));
    }
    super.clear();
  }
  
  public V put(K key, V value)
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("parameterMap.locked"));
    }
    return (V)super.put(key, value);
  }
  
  public void putAll(Map<? extends K, ? extends V> map)
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("parameterMap.locked"));
    }
    super.putAll(map);
  }
  
  public V remove(Object key)
  {
    if (this.locked) {
      throw new IllegalStateException(sm.getString("parameterMap.locked"));
    }
    return (V)super.remove(key);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\ParameterMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */