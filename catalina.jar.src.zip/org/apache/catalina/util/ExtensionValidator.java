package org.apache.catalina.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.jar.JarInputStream;
import java.util.jar.Manifest;
import javax.naming.Binding;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import org.apache.catalina.Context;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.naming.resources.Resource;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public final class ExtensionValidator
{
  private static final Log log = LogFactory.getLog(ExtensionValidator.class);
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
  private static volatile ArrayList<Extension> containerAvailableExtensions = null;
  private static ArrayList<ManifestResource> containerManifestResources = new ArrayList();
  
  static
  {
    String systemClasspath = System.getProperty("java.class.path");
    
    StringTokenizer strTok = new StringTokenizer(systemClasspath, File.pathSeparator);
    while (strTok.hasMoreTokens())
    {
      String classpathItem = strTok.nextToken();
      if (classpathItem.toLowerCase(Locale.ENGLISH).endsWith(".jar"))
      {
        File item = new File(classpathItem);
        if (item.isFile()) {
          try
          {
            addSystemResource(item);
          }
          catch (IOException e)
          {
            log.error(sm.getString("extensionValidator.failload", new Object[] { item }), e);
          }
        }
      }
    }
    addFolderList("java.ext.dirs");
  }
  
  public static synchronized boolean validateApplication(DirContext dirContext, Context context)
    throws IOException
  {
    appName = context.getName();
    appManifestResources = new ArrayList();
    if (dirContext == null) {
      return false;
    }
    InputStream inputStream = null;
    try
    {
      NamingEnumeration<Binding> wne = dirContext.listBindings("/META-INF/");
      
      Binding binding = (Binding)wne.nextElement();
      if (binding.getName().toUpperCase(Locale.ENGLISH).equals("MANIFEST.MF"))
      {
        Resource resource = (Resource)dirContext.lookup("/META-INF/" + binding.getName());
        
        inputStream = resource.streamContent();
        Manifest manifest = new Manifest(inputStream);
        inputStream.close();
        inputStream = null;
        ManifestResource mre = new ManifestResource(sm.getString("extensionValidator.web-application-manifest"), manifest, 2);
        
        appManifestResources.add(mre);
      }
      if (inputStream != null) {
        try
        {
          inputStream.close();
        }
        catch (Throwable t)
        {
          ExceptionUtils.handleThrowable(t);
        }
      }
      ne = null;
    }
    catch (NamingException nex) {}catch (NoSuchElementException nse) {}finally
    {
      if (inputStream != null) {
        try
        {
          inputStream.close();
        }
        catch (Throwable t)
        {
          ExceptionUtils.handleThrowable(t);
        }
      }
    }
    NamingEnumeration<Binding> ne;
    String jarName = null;
    try
    {
      ne = dirContext.listBindings("WEB-INF/lib/");
      while ((ne != null) && (ne.hasMoreElements()))
      {
        Binding binding = (Binding)ne.nextElement();
        jarName = binding.getName();
        if (jarName.toLowerCase(Locale.ENGLISH).endsWith(".jar"))
        {
          Object obj = dirContext.lookup("/WEB-INF/lib/" + jarName);
          if ((obj instanceof Resource))
          {
            Resource resource = (Resource)obj;
            inputStream = resource.streamContent();
            Manifest jmanifest = getManifest(inputStream);
            if (jmanifest != null)
            {
              ManifestResource mre = new ManifestResource(jarName, jmanifest, 3);
              
              appManifestResources.add(mre);
            }
          }
        }
      }
      return validateManifestResources(appName, appManifestResources);
    }
    catch (NamingException nex) {}catch (IOException ioe)
    {
      throw new IOException("Jar: " + jarName, ioe);
    }
    finally
    {
      if (inputStream != null) {
        try
        {
          inputStream.close();
        }
        catch (Throwable t)
        {
          ExceptionUtils.handleThrowable(t);
        }
      }
    }
  }
  
  public static void addSystemResource(File jarFile)
    throws IOException
  {
    InputStream is = null;
    try
    {
      is = new FileInputStream(jarFile);
      Manifest manifest = getManifest(is);
      if (manifest != null)
      {
        ManifestResource mre = new ManifestResource(jarFile.getAbsolutePath(), manifest, 1);
        
        containerManifestResources.add(mre);
      }
      return;
    }
    finally
    {
      if (is != null) {
        try
        {
          is.close();
        }
        catch (IOException e) {}
      }
    }
  }
  
  private static boolean validateManifestResources(String appName, ArrayList<ManifestResource> resources)
  {
    boolean passes = true;
    int failureCount = 0;
    ArrayList<Extension> availableExtensions = null;
    
    Iterator<ManifestResource> it = resources.iterator();
    while (it.hasNext())
    {
      ManifestResource mre = (ManifestResource)it.next();
      ArrayList<Extension> requiredList = mre.getRequiredExtensions();
      if (requiredList != null)
      {
        if (availableExtensions == null) {
          availableExtensions = buildAvailableExtensionsList(resources);
        }
        if (containerAvailableExtensions == null) {
          containerAvailableExtensions = buildAvailableExtensionsList(containerManifestResources);
        }
        Iterator<Extension> rit = requiredList.iterator();
        while (rit.hasNext())
        {
          boolean found = false;
          Extension requiredExt = (Extension)rit.next();
          if (availableExtensions != null)
          {
            Iterator<Extension> ait = availableExtensions.iterator();
            while (ait.hasNext())
            {
              Extension targetExt = (Extension)ait.next();
              if (targetExt.isCompatibleWith(requiredExt))
              {
                requiredExt.setFulfilled(true);
                found = true;
                break;
              }
            }
          }
          if ((!found) && (containerAvailableExtensions != null))
          {
            Iterator<Extension> cit = containerAvailableExtensions.iterator();
            while (cit.hasNext())
            {
              Extension targetExt = (Extension)cit.next();
              if (targetExt.isCompatibleWith(requiredExt))
              {
                requiredExt.setFulfilled(true);
                found = true;
                break;
              }
            }
          }
          if (!found)
          {
            log.info(sm.getString("extensionValidator.extension-not-found-error", new Object[] { appName, mre.getResourceName(), requiredExt.getExtensionName() }));
            
            passes = false;
            failureCount++;
          }
        }
      }
    }
    if (!passes) {
      log.info(sm.getString("extensionValidator.extension-validation-error", new Object[] { appName, failureCount + "" }));
    }
    return passes;
  }
  
  private static ArrayList<Extension> buildAvailableExtensionsList(ArrayList<ManifestResource> resources)
  {
    ArrayList<Extension> availableList = null;
    
    Iterator<ManifestResource> it = resources.iterator();
    while (it.hasNext())
    {
      ManifestResource mre = (ManifestResource)it.next();
      ArrayList<Extension> list = mre.getAvailableExtensions();
      if (list != null)
      {
        Iterator<Extension> values = list.iterator();
        while (values.hasNext())
        {
          Extension ext = (Extension)values.next();
          if (availableList == null)
          {
            availableList = new ArrayList();
            availableList.add(ext);
          }
          else
          {
            availableList.add(ext);
          }
        }
      }
    }
    return availableList;
  }
  
  private static Manifest getManifest(InputStream inStream)
    throws IOException
  {
    manifest = null;
    JarInputStream jin = null;
    try
    {
      jin = new JarInputStream(inStream);
      manifest = jin.getManifest();
      jin.close();
      jin = null;
      
      return manifest;
    }
    finally
    {
      if (jin != null) {
        try
        {
          jin.close();
        }
        catch (Throwable t)
        {
          ExceptionUtils.handleThrowable(t);
        }
      }
    }
  }
  
  private static void addFolderList(String property)
  {
    String extensionsDir = System.getProperty(property);
    if (extensionsDir != null)
    {
      StringTokenizer extensionsTok = new StringTokenizer(extensionsDir, File.pathSeparator);
      while (extensionsTok.hasMoreTokens())
      {
        File targetDir = new File(extensionsTok.nextToken());
        if (targetDir.isDirectory())
        {
          File[] files = targetDir.listFiles();
          for (int i = 0; i < files.length; i++) {
            if ((files[i].getName().toLowerCase(Locale.ENGLISH).endsWith(".jar")) && (files[i].isFile())) {
              try
              {
                addSystemResource(files[i]);
              }
              catch (IOException e)
              {
                log.error(sm.getString("extensionValidator.failload", new Object[] { files[i] }), e);
              }
            }
          }
        }
      }
    }
  }
  
  public ExtensionValidator() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\ExtensionValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */