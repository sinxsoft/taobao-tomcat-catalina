package org.apache.catalina.util;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.SessionIdGenerator;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public abstract class SessionIdGeneratorBase
  extends LifecycleBase
  implements SessionIdGenerator
{
  private static final Log log = LogFactory.getLog(SessionIdGeneratorBase.class);
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
  private final Queue<SecureRandom> randoms = new ConcurrentLinkedQueue();
  private String secureRandomClass = null;
  private String secureRandomAlgorithm = "SHA1PRNG";
  private String secureRandomProvider = null;
  private String jvmRoute = "";
  private int sessionIdLength = 16;
  
  public SessionIdGeneratorBase() {}
  
  public void setSecureRandomClass(String secureRandomClass)
  {
    this.secureRandomClass = secureRandomClass;
  }
  
  public void setSecureRandomAlgorithm(String secureRandomAlgorithm)
  {
    this.secureRandomAlgorithm = secureRandomAlgorithm;
  }
  
  public void setSecureRandomProvider(String secureRandomProvider)
  {
    this.secureRandomProvider = secureRandomProvider;
  }
  
  public String getJvmRoute()
  {
    return this.jvmRoute;
  }
  
  public void setJvmRoute(String jvmRoute)
  {
    this.jvmRoute = jvmRoute;
  }
  
  public int getSessionIdLength()
  {
    return this.sessionIdLength;
  }
  
  public void setSessionIdLength(int sessionIdLength)
  {
    this.sessionIdLength = sessionIdLength;
  }
  
  public String generateSessionId()
  {
    return generateSessionId(this.jvmRoute);
  }
  
  protected void getRandomBytes(byte[] bytes)
  {
    SecureRandom random = (SecureRandom)this.randoms.poll();
    if (random == null) {
      random = createSecureRandom();
    }
    random.nextBytes(bytes);
    this.randoms.add(random);
  }
  
  private SecureRandom createSecureRandom()
  {
    SecureRandom result = null;
    
    long t1 = System.currentTimeMillis();
    if (this.secureRandomClass != null) {
      try
      {
        Class<?> clazz = Class.forName(this.secureRandomClass);
        result = (SecureRandom)clazz.newInstance();
      }
      catch (Exception e)
      {
        log.error(sm.getString("sessionIdGeneratorBase.random", new Object[] { this.secureRandomClass }), e);
      }
    }
    if (result == null) {
      try
      {
        if ((this.secureRandomProvider != null) && (this.secureRandomProvider.length() > 0)) {
          result = SecureRandom.getInstance(this.secureRandomAlgorithm, this.secureRandomProvider);
        } else if ((this.secureRandomAlgorithm != null) && (this.secureRandomAlgorithm.length() > 0)) {
          result = SecureRandom.getInstance(this.secureRandomAlgorithm);
        }
      }
      catch (NoSuchAlgorithmException e)
      {
        log.error(sm.getString("sessionIdGeneratorBase.randomAlgorithm", new Object[] { this.secureRandomAlgorithm }), e);
      }
      catch (NoSuchProviderException e)
      {
        log.error(sm.getString("sessionIdGeneratorBase.randomProvider", new Object[] { this.secureRandomProvider }), e);
      }
    }
    if (result == null) {
      try
      {
        result = SecureRandom.getInstance("SHA1PRNG");
      }
      catch (NoSuchAlgorithmException e)
      {
        log.error(sm.getString("sessionIdGeneratorBase.randomAlgorithm", new Object[] { this.secureRandomAlgorithm }), e);
      }
    }
    if (result == null) {
      result = new SecureRandom();
    }
    result.nextInt();
    
    long t2 = System.currentTimeMillis();
    if (t2 - t1 > 100L) {
      log.info(sm.getString("sessionIdGeneratorBase.createRandom", new Object[] { result.getAlgorithm(), Long.valueOf(t2 - t1) }));
    }
    return result;
  }
  
  protected void initInternal()
    throws LifecycleException
  {}
  
  protected void startInternal()
    throws LifecycleException
  {
    generateSessionId();
    
    setState(LifecycleState.STARTING);
  }
  
  protected void stopInternal()
    throws LifecycleException
  {
    setState(LifecycleState.STOPPING);
    this.randoms.clear();
  }
  
  protected void destroyInternal()
    throws LifecycleException
  {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\SessionIdGeneratorBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */