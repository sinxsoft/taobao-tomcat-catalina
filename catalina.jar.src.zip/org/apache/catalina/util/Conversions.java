package org.apache.catalina.util;

import java.io.IOException;

public class Conversions
{
  private Conversions() {}
  
  public static long byteArrayToLong(byte[] input)
    throws IOException
  {
    if (input.length > 8) {
      throw new IOException();
    }
    int shift = 0;
    long result = 0L;
    for (int i = input.length - 1; i >= 0; i--)
    {
      result += ((input[i] & 0xFF) << shift);
      shift += 8;
    }
    return result;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\Conversions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */