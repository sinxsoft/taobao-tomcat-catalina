package org.apache.catalina.util;

import org.apache.catalina.Lifecycle;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.LifecycleState;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public abstract class LifecycleBase
  implements Lifecycle
{
  private static Log log = LogFactory.getLog(LifecycleBase.class);
  private static StringManager sm = StringManager.getManager("org.apache.catalina.util");
  private LifecycleSupport lifecycle = new LifecycleSupport(this);
  private volatile LifecycleState state = LifecycleState.NEW;
  
  public LifecycleBase() {}
  
  public void addLifecycleListener(LifecycleListener listener)
  {
    this.lifecycle.addLifecycleListener(listener);
  }
  
  public LifecycleListener[] findLifecycleListeners()
  {
    return this.lifecycle.findLifecycleListeners();
  }
  
  public void removeLifecycleListener(LifecycleListener listener)
  {
    this.lifecycle.removeLifecycleListener(listener);
  }
  
  protected void fireLifecycleEvent(String type, Object data)
  {
    this.lifecycle.fireLifecycleEvent(type, data);
  }
  
  public final synchronized void init()
    throws LifecycleException
  {
    if (!this.state.equals(LifecycleState.NEW)) {
      invalidTransition("before_init");
    }
    setStateInternal(LifecycleState.INITIALIZING, null, false);
    try
    {
      initInternal();
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      setStateInternal(LifecycleState.FAILED, null, false);
      throw new LifecycleException(sm.getString("lifecycleBase.initFail", new Object[] { toString() }), t);
    }
    setStateInternal(LifecycleState.INITIALIZED, null, false);
  }
  
  protected abstract void initInternal()
    throws LifecycleException;
  
  public final synchronized void start()
    throws LifecycleException
  {
    if ((LifecycleState.STARTING_PREP.equals(this.state)) || (LifecycleState.STARTING.equals(this.state)) || (LifecycleState.STARTED.equals(this.state)))
    {
      if (log.isDebugEnabled())
      {
        Exception e = new LifecycleException();
        log.debug(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }), e);
      }
      else if (log.isInfoEnabled())
      {
        log.info(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }));
      }
      return;
    }
    if (this.state.equals(LifecycleState.NEW)) {
      init();
    } else if (this.state.equals(LifecycleState.FAILED)) {
      stop();
    } else if ((!this.state.equals(LifecycleState.INITIALIZED)) && (!this.state.equals(LifecycleState.STOPPED))) {
      invalidTransition("before_start");
    }
    setStateInternal(LifecycleState.STARTING_PREP, null, false);
    try
    {
      startInternal();
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      setStateInternal(LifecycleState.FAILED, null, false);
      throw new LifecycleException(sm.getString("lifecycleBase.startFail", new Object[] { toString() }), t);
    }
    if ((this.state.equals(LifecycleState.FAILED)) || (this.state.equals(LifecycleState.MUST_STOP)))
    {
      stop();
    }
    else
    {
      if (!this.state.equals(LifecycleState.STARTING)) {
        invalidTransition("after_start");
      }
      setStateInternal(LifecycleState.STARTED, null, false);
    }
  }
  
  protected abstract void startInternal()
    throws LifecycleException;
  
  public final synchronized void stop()
    throws LifecycleException
  {
    if ((LifecycleState.STOPPING_PREP.equals(this.state)) || (LifecycleState.STOPPING.equals(this.state)) || (LifecycleState.STOPPED.equals(this.state)))
    {
      if (log.isDebugEnabled())
      {
        Exception e = new LifecycleException();
        log.debug(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }), e);
      }
      else if (log.isInfoEnabled())
      {
        log.info(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }));
      }
      return;
    }
    if (this.state.equals(LifecycleState.NEW))
    {
      this.state = LifecycleState.STOPPED;
      return;
    }
    if ((!this.state.equals(LifecycleState.STARTED)) && (!this.state.equals(LifecycleState.FAILED)) && (!this.state.equals(LifecycleState.MUST_STOP))) {
      invalidTransition("before_stop");
    }
    if (this.state.equals(LifecycleState.FAILED)) {
      fireLifecycleEvent("before_stop", null);
    } else {
      setStateInternal(LifecycleState.STOPPING_PREP, null, false);
    }
    try
    {
      stopInternal();
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      setStateInternal(LifecycleState.FAILED, null, false);
      throw new LifecycleException(sm.getString("lifecycleBase.stopFail", new Object[] { toString() }), t);
    }
    if (this.state.equals(LifecycleState.MUST_DESTROY))
    {
      setStateInternal(LifecycleState.STOPPED, null, false);
      
      destroy();
    }
    else if (!this.state.equals(LifecycleState.FAILED))
    {
      if (!this.state.equals(LifecycleState.STOPPING)) {
        invalidTransition("after_stop");
      }
      setStateInternal(LifecycleState.STOPPED, null, false);
    }
  }
  
  protected abstract void stopInternal()
    throws LifecycleException;
  
  public final synchronized void destroy()
    throws LifecycleException
  {
    if (LifecycleState.FAILED.equals(this.state)) {
      try
      {
        stop();
      }
      catch (LifecycleException e)
      {
        log.warn(sm.getString("lifecycleBase.destroyStopFail", new Object[] { toString() }), e);
      }
    }
    if ((LifecycleState.DESTROYING.equals(this.state)) || (LifecycleState.DESTROYED.equals(this.state)))
    {
      if (log.isDebugEnabled())
      {
        Exception e = new LifecycleException();
        log.debug(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }), e);
      }
      else if (log.isInfoEnabled())
      {
        log.info(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }));
      }
      return;
    }
    if ((!this.state.equals(LifecycleState.STOPPED)) && (!this.state.equals(LifecycleState.FAILED)) && (!this.state.equals(LifecycleState.NEW)) && (!this.state.equals(LifecycleState.INITIALIZED))) {
      invalidTransition("before_destroy");
    }
    setStateInternal(LifecycleState.DESTROYING, null, false);
    try
    {
      destroyInternal();
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      setStateInternal(LifecycleState.FAILED, null, false);
      throw new LifecycleException(sm.getString("lifecycleBase.destroyFail", new Object[] { toString() }), t);
    }
    setStateInternal(LifecycleState.DESTROYED, null, false);
  }
  
  protected abstract void destroyInternal()
    throws LifecycleException;
  
  public LifecycleState getState()
  {
    return this.state;
  }
  
  public String getStateName()
  {
    return getState().toString();
  }
  
  protected synchronized void setState(LifecycleState state)
    throws LifecycleException
  {
    setStateInternal(state, null, true);
  }
  
  protected synchronized void setState(LifecycleState state, Object data)
    throws LifecycleException
  {
    setStateInternal(state, data, true);
  }
  
  private synchronized void setStateInternal(LifecycleState state, Object data, boolean check)
    throws LifecycleException
  {
    if (log.isDebugEnabled()) {
      log.debug(sm.getString("lifecycleBase.setState", new Object[] { this, state }));
    }
    if (check)
    {
      if (state == null)
      {
        invalidTransition("null");
        
        return;
      }
      if ((state != LifecycleState.FAILED) && ((this.state != LifecycleState.STARTING_PREP) || (state != LifecycleState.STARTING)) && ((this.state != LifecycleState.STOPPING_PREP) || (state != LifecycleState.STOPPING)) && ((this.state != LifecycleState.FAILED) || (state != LifecycleState.STOPPING))) {
        invalidTransition(state.name());
      }
    }
    this.state = state;
    String lifecycleEvent = state.getLifecycleEvent();
    if (lifecycleEvent != null) {
      fireLifecycleEvent(lifecycleEvent, data);
    }
  }
  
  private void invalidTransition(String type)
    throws LifecycleException
  {
    String msg = sm.getString("lifecycleBase.invalidTransition", new Object[] { type, toString(), this.state });
    
    throw new LifecycleException(msg);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\LifecycleBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */