package org.apache.catalina.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;
import org.apache.tomcat.util.ExceptionUtils;

public class ServerInfo
{
  private static String serverInfo = null;
  private static String serverBuilt = null;
  private static String serverNumber = null;
  
  static
  {
    Properties props = new Properties();
    InputStream is = null;
    try
    {
      is = ServerInfo.class.getResourceAsStream("/org/apache/catalina/util/ServerInfo.properties");
      
      props.load(is);
      serverInfo = props.getProperty("server.info");
      serverBuilt = props.getProperty("server.built");
      serverNumber = props.getProperty("server.number");
      if (is != null) {
        try
        {
          is.close();
        }
        catch (IOException e) {}
      }
      if (serverInfo != null) {
        break label125;
      }
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
    }
    finally
    {
      if (is != null) {
        try
        {
          is.close();
        }
        catch (IOException e) {}
      }
    }
    serverInfo = "Apache Tomcat 7.0.x-dev";
    label125:
    if (serverBuilt == null) {
      serverBuilt = "unknown";
    }
    if (serverNumber == null) {
      serverNumber = "7.0.x";
    }
  }
  
  public static String getServerInfo()
  {
    return serverInfo;
  }
  
  public static String getServerBuilt()
  {
    return serverBuilt;
  }
  
  public static String getServerNumber()
  {
    return serverNumber;
  }
  
  public static void main(String[] args)
  {
    System.out.println("Server version: " + getServerInfo());
    System.out.println("Server built:   " + getServerBuilt());
    System.out.println("Server number:  " + getServerNumber());
    System.out.println("OS Name:        " + System.getProperty("os.name"));
    
    System.out.println("OS Version:     " + System.getProperty("os.version"));
    
    System.out.println("Architecture:   " + System.getProperty("os.arch"));
    
    System.out.println("JVM Version:    " + System.getProperty("java.runtime.version"));
    
    System.out.println("JVM Vendor:     " + System.getProperty("java.vm.vendor"));
  }
  
  public ServerInfo() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\ServerInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */