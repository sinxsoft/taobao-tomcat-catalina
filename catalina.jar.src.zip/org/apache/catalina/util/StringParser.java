package org.apache.catalina.util;

public final class StringParser
{
  public StringParser()
  {
    this(null);
  }
  
  public StringParser(String string)
  {
    setString(string);
  }
  
  private char[] chars = null;
  private int index = 0;
  private int length = 0;
  private String string = null;
  
  public int getIndex()
  {
    return this.index;
  }
  
  public int getLength()
  {
    return this.length;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public void setString(String string)
  {
    this.string = string;
    if (string != null)
    {
      this.length = string.length();
      this.chars = this.string.toCharArray();
    }
    else
    {
      this.length = 0;
      this.chars = new char[0];
    }
    reset();
  }
  
  public void advance()
  {
    if (this.index < this.length) {
      this.index += 1;
    }
  }
  
  public String extract(int start)
  {
    if ((start < 0) || (start >= this.length)) {
      return "";
    }
    return this.string.substring(start);
  }
  
  public String extract(int start, int end)
  {
    if ((start < 0) || (start >= end) || (end > this.length)) {
      return "";
    }
    return this.string.substring(start, end);
  }
  
  public int findChar(char ch)
  {
    while ((this.index < this.length) && (ch != this.chars[this.index])) {
      this.index += 1;
    }
    return this.index;
  }
  
  public int findText()
  {
    while ((this.index < this.length) && (isWhite(this.chars[this.index]))) {
      this.index += 1;
    }
    return this.index;
  }
  
  public int findWhite()
  {
    while ((this.index < this.length) && (!isWhite(this.chars[this.index]))) {
      this.index += 1;
    }
    return this.index;
  }
  
  public void reset()
  {
    this.index = 0;
  }
  
  public int skipChar(char ch)
  {
    while ((this.index < this.length) && (ch == this.chars[this.index])) {
      this.index += 1;
    }
    return this.index;
  }
  
  public int skipText()
  {
    while ((this.index < this.length) && (!isWhite(this.chars[this.index]))) {
      this.index += 1;
    }
    return this.index;
  }
  
  public int skipWhite()
  {
    while ((this.index < this.length) && (isWhite(this.chars[this.index]))) {
      this.index += 1;
    }
    return this.index;
  }
  
  protected boolean isWhite(char ch)
  {
    if ((ch == ' ') || (ch == '\t') || (ch == '\r') || (ch == '\n')) {
      return true;
    }
    return false;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\StringParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */