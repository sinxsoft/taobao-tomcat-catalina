package org.apache.catalina.util;

import javax.servlet.Filter;
import javax.servlet.Servlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.apache.catalina.InstanceEvent;
import org.apache.catalina.InstanceListener;
import org.apache.catalina.Wrapper;

public final class InstanceSupport
{
  public InstanceSupport(Wrapper wrapper)
  {
    this.wrapper = wrapper;
  }
  
  private InstanceListener[] listeners = new InstanceListener[0];
  private final Object listenersLock = new Object();
  private Wrapper wrapper = null;
  
  public Wrapper getWrapper()
  {
    return this.wrapper;
  }
  
  public void addInstanceListener(InstanceListener listener)
  {
    synchronized (this.listenersLock)
    {
      InstanceListener[] results = new InstanceListener[this.listeners.length + 1];
      for (int i = 0; i < this.listeners.length; i++) {
        results[i] = this.listeners[i];
      }
      results[this.listeners.length] = listener;
      this.listeners = results;
    }
  }
  
  public void fireInstanceEvent(String type, Filter filter)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, filter, type);
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Filter filter, Throwable exception)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, filter, type, exception);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Filter filter, ServletRequest request, ServletResponse response)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, filter, type, request, response);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Filter filter, ServletRequest request, ServletResponse response, Throwable exception)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, filter, type, request, response, exception);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Servlet servlet)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, servlet, type);
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Servlet servlet, Throwable exception)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, servlet, type, exception);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Servlet servlet, ServletRequest request, ServletResponse response)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, servlet, type, request, response);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void fireInstanceEvent(String type, Servlet servlet, ServletRequest request, ServletResponse response, Throwable exception)
  {
    if (this.listeners.length == 0) {
      return;
    }
    InstanceEvent event = new InstanceEvent(this.wrapper, servlet, type, request, response, exception);
    
    InstanceListener[] interested = this.listeners;
    for (int i = 0; i < interested.length; i++) {
      interested[i].instanceEvent(event);
    }
  }
  
  public void removeInstanceListener(InstanceListener listener)
  {
    synchronized (this.listenersLock)
    {
      int n = -1;
      for (int i = 0; i < this.listeners.length; i++) {
        if (this.listeners[i] == listener)
        {
          n = i;
          break;
        }
      }
      if (n < 0) {
        return;
      }
      InstanceListener[] results = new InstanceListener[this.listeners.length - 1];
      
      int j = 0;
      for (int i = 0; i < this.listeners.length; i++) {
        if (i != n) {
          results[(j++)] = this.listeners[i];
        }
      }
      this.listeners = results;
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\InstanceSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */