package org.apache.catalina.util;

import javax.xml.bind.DatatypeConverter;
import org.apache.tomcat.util.buf.ByteChunk;
import org.apache.tomcat.util.buf.CharChunk;

@Deprecated
public final class Base64
{
  private static final int BASELENGTH = 255;
  private static final int LOOKUPLENGTH = 64;
  private static final int FOURBYTE = 4;
  private static final byte PAD = 61;
  private static final byte[] base64Alphabet = new byte['ÿ'];
  private static final byte[] lookUpBase64Alphabet = new byte[64];
  
  static
  {
    for (int i = 0; i < 255; i++) {
      base64Alphabet[i] = -1;
    }
    for (int i = 90; i >= 65; i--) {
      base64Alphabet[i] = ((byte)(i - 65));
    }
    for (int i = 122; i >= 97; i--) {
      base64Alphabet[i] = ((byte)(i - 97 + 26));
    }
    for (int i = 57; i >= 48; i--) {
      base64Alphabet[i] = ((byte)(i - 48 + 52));
    }
    base64Alphabet[43] = 62;
    base64Alphabet[47] = 63;
    for (int i = 0; i <= 25; i++) {
      lookUpBase64Alphabet[i] = ((byte)(65 + i));
    }
    int i = 26;
    for (int j = 0; i <= 51; j++)
    {
      lookUpBase64Alphabet[i] = ((byte)(97 + j));i++;
    }
    int i = 52;
    for (int j = 0; i <= 61; j++)
    {
      lookUpBase64Alphabet[i] = ((byte)(48 + j));i++;
    }
    lookUpBase64Alphabet[62] = 43;
    lookUpBase64Alphabet[63] = 47;
  }
  
  @Deprecated
  public static String encode(byte[] binaryData)
  {
    return DatatypeConverter.printBase64Binary(binaryData);
  }
  
  public static void decode(ByteChunk base64DataBC, CharChunk decodedDataCC)
  {
    int start = base64DataBC.getStart();
    int end = base64DataBC.getEnd();
    byte[] base64Data = base64DataBC.getBuffer();
    
    decodedDataCC.recycle();
    if (end - start == 0) {
      return;
    }
    int numberQuadruple = (end - start) / 4;
    byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;byte marker0 = 0;byte marker1 = 0;
    
    int encodedIndex = 0;
    int dataIndex = start;
    char[] decodedData = null;
    
    int lastData = end - start;
    while (base64Data[(start + lastData - 1)] == 61)
    {
      lastData--;
      if (lastData == 0) {
        return;
      }
    }
    decodedDataCC.allocate(lastData - numberQuadruple, -1);
    decodedDataCC.setEnd(lastData - numberQuadruple);
    decodedData = decodedDataCC.getBuffer();
    for (int i = 0; i < numberQuadruple; i++)
    {
      dataIndex = start + i * 4;
      marker0 = base64Data[(dataIndex + 2)];
      marker1 = base64Data[(dataIndex + 3)];
      
      b1 = base64Alphabet[base64Data[dataIndex]];
      b2 = base64Alphabet[base64Data[(dataIndex + 1)]];
      if ((marker0 != 61) && (marker1 != 61))
      {
        b3 = base64Alphabet[marker0];
        b4 = base64Alphabet[marker1];
        
        decodedData[encodedIndex] = ((char)((b1 << 2 | b2 >> 4) & 0xFF));
        decodedData[(encodedIndex + 1)] = ((char)(((b2 & 0xF) << 4 | b3 >> 2 & 0xF) & 0xFF));
        
        decodedData[(encodedIndex + 2)] = ((char)((b3 << 6 | b4) & 0xFF));
      }
      else if (marker0 == 61)
      {
        decodedData[encodedIndex] = ((char)((b1 << 2 | b2 >> 4) & 0xFF));
      }
      else if (marker1 == 61)
      {
        b3 = base64Alphabet[marker0];
        
        decodedData[encodedIndex] = ((char)((b1 << 2 | b2 >> 4) & 0xFF));
        decodedData[(encodedIndex + 1)] = ((char)(((b2 & 0xF) << 4 | b3 >> 2 & 0xF) & 0xFF));
      }
      encodedIndex += 3;
    }
  }
  
  public static void decode(ByteChunk base64DataBC, ByteChunk decodedDataBC)
  {
    int start = base64DataBC.getStart();
    int end = base64DataBC.getEnd();
    byte[] base64Data = base64DataBC.getBuffer();
    
    decodedDataBC.recycle();
    if (end - start == 0) {
      return;
    }
    int numberQuadruple = (end - start) / 4;
    byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;byte marker0 = 0;byte marker1 = 0;
    
    int encodedIndex = 0;
    int dataIndex = start;
    byte[] decodedData = null;
    
    int lastData = end - start;
    while (base64Data[(start + lastData - 1)] == 61)
    {
      lastData--;
      if (lastData == 0) {
        return;
      }
    }
    decodedDataBC.allocate(lastData - numberQuadruple, -1);
    decodedDataBC.setEnd(lastData - numberQuadruple);
    decodedData = decodedDataBC.getBuffer();
    for (int i = 0; i < numberQuadruple; i++)
    {
      dataIndex = start + i * 4;
      marker0 = base64Data[(dataIndex + 2)];
      marker1 = base64Data[(dataIndex + 3)];
      
      b1 = base64Alphabet[base64Data[dataIndex]];
      b2 = base64Alphabet[base64Data[(dataIndex + 1)]];
      if ((marker0 != 61) && (marker1 != 61))
      {
        b3 = base64Alphabet[marker0];
        b4 = base64Alphabet[marker1];
        
        decodedData[encodedIndex] = ((byte)((b1 << 2 | b2 >> 4) & 0xFF));
        decodedData[(encodedIndex + 1)] = ((byte)(((b2 & 0xF) << 4 | b3 >> 2 & 0xF) & 0xFF));
        
        decodedData[(encodedIndex + 2)] = ((byte)((b3 << 6 | b4) & 0xFF));
      }
      else if (marker0 == 61)
      {
        decodedData[encodedIndex] = ((byte)((b1 << 2 | b2 >> 4) & 0xFF));
      }
      else if (marker1 == 61)
      {
        b3 = base64Alphabet[marker0];
        
        decodedData[encodedIndex] = ((byte)((b1 << 2 | b2 >> 4) & 0xFF));
        decodedData[(encodedIndex + 1)] = ((byte)(((b2 & 0xF) << 4 | b3 >> 2 & 0xF) & 0xFF));
      }
      encodedIndex += 3;
    }
  }
  
  public Base64() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\Base64.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */