package org.apache.catalina.util;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistration;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import org.apache.catalina.LifecycleException;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.modeler.Registry;
import org.apache.tomcat.util.res.StringManager;

public abstract class LifecycleMBeanBase
  extends LifecycleBase
  implements MBeanRegistration
{
  private static Log log = LogFactory.getLog(LifecycleMBeanBase.class);
  private static StringManager sm = StringManager.getManager("org.apache.catalina.util");
  private String domain = null;
  private ObjectName oname = null;
  protected MBeanServer mserver = null;
  
  public LifecycleMBeanBase() {}
  
  protected void initInternal()
    throws LifecycleException
  {
    if (this.oname == null)
    {
      this.mserver = Registry.getRegistry(null, null).getMBeanServer();
      
      this.oname = register(this, getObjectNameKeyProperties());
    }
  }
  
  protected void destroyInternal()
    throws LifecycleException
  {
    unregister(this.oname);
  }
  
  public final void setDomain(String domain)
  {
    this.domain = domain;
  }
  
  public final String getDomain()
  {
    if (this.domain == null) {
      this.domain = getDomainInternal();
    }
    if (this.domain == null) {
      this.domain = "Catalina";
    }
    return this.domain;
  }
  
  protected abstract String getDomainInternal();
  
  public final ObjectName getObjectName()
  {
    return this.oname;
  }
  
  protected abstract String getObjectNameKeyProperties();
  
  protected final ObjectName register(Object obj, String objectNameKeyProperties)
  {
    StringBuilder name = new StringBuilder(getDomain());
    name.append(':');
    name.append(objectNameKeyProperties);
    
    ObjectName on = null;
    try
    {
      on = new ObjectName(name.toString());
      
      Registry.getRegistry(null, null).registerComponent(obj, on, null);
    }
    catch (MalformedObjectNameException e)
    {
      log.warn(sm.getString("lifecycleMBeanBase.registerFail", new Object[] { obj, name }), e);
    }
    catch (Exception e)
    {
      log.warn(sm.getString("lifecycleMBeanBase.registerFail", new Object[] { obj, name }), e);
    }
    return on;
  }
  
  protected final void unregister(ObjectName on)
  {
    if (on == null) {
      return;
    }
    if (this.mserver == null)
    {
      log.warn(sm.getString("lifecycleMBeanBase.unregisterNoServer", new Object[] { on }));
      return;
    }
    try
    {
      this.mserver.unregisterMBean(on);
    }
    catch (MBeanRegistrationException e)
    {
      log.warn(sm.getString("lifecycleMBeanBase.unregisterFail", new Object[] { on }), e);
    }
    catch (InstanceNotFoundException e)
    {
      log.warn(sm.getString("lifecycleMBeanBase.unregisterFail", new Object[] { on }), e);
    }
  }
  
  public final void postDeregister() {}
  
  public final void postRegister(Boolean registrationDone) {}
  
  public final void preDeregister()
    throws Exception
  {}
  
  public final ObjectName preRegister(MBeanServer server, ObjectName name)
    throws Exception
  {
    this.mserver = server;
    this.oname = name;
    this.domain = name.getDomain();
    
    return this.oname;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\LifecycleMBeanBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */