package org.apache.catalina.util;

import java.util.HashMap;
import org.apache.tomcat.util.digester.Digester;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

@Deprecated
public class SchemaResolver
  implements EntityResolver
{
  protected Digester digester;
  protected HashMap<String, String> entityValidator = new HashMap();
  protected String schemaExtension = "xsd";
  
  public SchemaResolver(Digester digester)
  {
    this.digester = digester;
  }
  
  public void register(String publicId, String entityURL)
  {
    String key = publicId;
    if (publicId.indexOf(this.schemaExtension) != -1) {
      key = publicId.substring(publicId.lastIndexOf('/') + 1);
    }
    this.entityValidator.put(key, entityURL);
  }
  
  public InputSource resolveEntity(String publicId, String systemId)
    throws SAXException
  {
    if (publicId != null) {
      this.digester.setPublicId(publicId);
    }
    String entityURL = null;
    if (publicId != null) {
      entityURL = (String)this.entityValidator.get(publicId);
    }
    String key = null;
    if ((entityURL == null) && (systemId != null))
    {
      key = systemId.substring(systemId.lastIndexOf('/') + 1);
      entityURL = (String)this.entityValidator.get(key);
    }
    if (entityURL == null) {
      return null;
    }
    try
    {
      return new InputSource(entityURL);
    }
    catch (Exception e)
    {
      throw new SAXException(e);
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\SchemaResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */