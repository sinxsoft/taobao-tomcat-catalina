package org.apache.catalina.util;

import java.util.Locale;

public final class ContextName
{
  private static final String ROOT_NAME = "ROOT";
  private static final String VERSION_MARKER = "##";
  private static final String FWD_SLASH_REPLACEMENT = "#";
  private final String baseName;
  private final String path;
  private final String version;
  private final String name;
  
  @Deprecated
  public ContextName(String name)
  {
    this(name, true);
  }
  
  public ContextName(String name, boolean stripFileExtension)
  {
    String tmp1 = name;
    if (tmp1.startsWith("/")) {
      tmp1 = tmp1.substring(1);
    }
    tmp1 = tmp1.replaceAll("/", "#");
    if ((tmp1.startsWith("##")) || ("".equals(tmp1))) {
      tmp1 = "ROOT" + tmp1;
    }
    if ((stripFileExtension) && ((tmp1.toLowerCase(Locale.ENGLISH).endsWith(".war")) || (tmp1.toLowerCase(Locale.ENGLISH).endsWith(".xml")))) {
      tmp1 = tmp1.substring(0, tmp1.length() - 4);
    }
    this.baseName = tmp1;
    
    int versionIndex = this.baseName.indexOf("##");
    String tmp2;
    String tmp2;
    if (versionIndex > -1)
    {
      this.version = this.baseName.substring(versionIndex + 2);
      tmp2 = this.baseName.substring(0, versionIndex);
    }
    else
    {
      this.version = "";
      tmp2 = this.baseName;
    }
    if ("ROOT".equals(tmp2)) {
      this.path = "";
    } else {
      this.path = ("/" + tmp2.replaceAll("#", "/"));
    }
    if (versionIndex > -1) {
      this.name = (this.path + "##" + this.version);
    } else {
      this.name = this.path;
    }
  }
  
  public ContextName(String path, String version)
  {
    if ((path == null) || ("/".equals(path)) || ("/ROOT".equals(path))) {
      this.path = "";
    } else {
      this.path = path;
    }
    if (version == null) {
      this.version = "";
    } else {
      this.version = version;
    }
    if ("".equals(this.version)) {
      this.name = this.path;
    } else {
      this.name = (this.path + "##" + this.version);
    }
    StringBuilder tmp = new StringBuilder();
    if ("".equals(this.path)) {
      tmp.append("ROOT");
    } else {
      tmp.append(this.path.substring(1).replaceAll("/", "#"));
    }
    if (this.version.length() > 0)
    {
      tmp.append("##");
      tmp.append(this.version);
    }
    this.baseName = tmp.toString();
  }
  
  public String getBaseName()
  {
    return this.baseName;
  }
  
  public String getPath()
  {
    return this.path;
  }
  
  public String getVersion()
  {
    return this.version;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public String getDisplayName()
  {
    StringBuilder tmp = new StringBuilder();
    if ("".equals(this.path)) {
      tmp.append('/');
    } else {
      tmp.append(this.path);
    }
    if (!"".equals(this.version))
    {
      tmp.append("##");
      tmp.append(this.version);
    }
    return tmp.toString();
  }
  
  public String toString()
  {
    return getDisplayName();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\util\ContextName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */