package org.apache.catalina.realm;

import java.security.Principal;
import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.catalina.LifecycleException;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSName;

public class LockOutRealm
  extends CombinedRealm
{
  private static final Log log = LogFactory.getLog(LockOutRealm.class);
  protected static final String name = "LockOutRealm";
  protected int failureCount;
  protected int lockOutTime;
  protected int cacheSize;
  protected int cacheRemovalWarningTime;
  protected Map<String, LockRecord> failedUsers;
  
  public LockOutRealm()
  {
    this.failureCount = 5;
    
    this.lockOutTime = 300;
    
    this.cacheSize = 1000;
    
    this.cacheRemovalWarningTime = 3600;
    
    this.failedUsers = null;
  }
  
  protected void startInternal()
    throws LifecycleException
  {
    this.failedUsers = new LinkedHashMap(this.cacheSize, 0.75F, true)
    {
      private static final long serialVersionUID = 1L;
      
      protected boolean removeEldestEntry(Map.Entry<String, LockOutRealm.LockRecord> eldest)
      {
        if (size() > LockOutRealm.this.cacheSize)
        {
          long timeInCache = (System.currentTimeMillis() - ((LockOutRealm.LockRecord)eldest.getValue()).getLastFailureTime()) / 1000L;
          if (timeInCache < LockOutRealm.this.cacheRemovalWarningTime) {
            LockOutRealm.log.warn(RealmBase.sm.getString("lockOutRealm.removeWarning", new Object[] { eldest.getKey(), Long.valueOf(timeInCache) }));
          }
          return true;
        }
        return false;
      }
    };
    super.startInternal();
  }
  
  public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
  {
    if (isLocked(username))
    {
      registerAuthFailure(username);
      
      log.warn(sm.getString("lockOutRealm.authLockedUser", new Object[] { username }));
      return null;
    }
    Principal authenticatedUser = super.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2);
    if (authenticatedUser == null) {
      registerAuthFailure(username);
    } else {
      registerAuthSuccess(username);
    }
    return authenticatedUser;
  }
  
  public Principal authenticate(String username, String credentials)
  {
    if (isLocked(username))
    {
      registerAuthFailure(username);
      
      log.warn(sm.getString("lockOutRealm.authLockedUser", new Object[] { username }));
      return null;
    }
    Principal authenticatedUser = super.authenticate(username, credentials);
    if (authenticatedUser == null) {
      registerAuthFailure(username);
    } else {
      registerAuthSuccess(username);
    }
    return authenticatedUser;
  }
  
  public Principal authenticate(X509Certificate[] certs)
  {
    String username = null;
    if ((certs != null) && (certs.length > 0)) {
      username = certs[0].getSubjectDN().getName();
    }
    if (isLocked(username))
    {
      registerAuthFailure(username);
      
      log.warn(sm.getString("lockOutRealm.authLockedUser", new Object[] { username }));
      return null;
    }
    Principal authenticatedUser = super.authenticate(certs);
    if (authenticatedUser == null) {
      registerAuthFailure(username);
    } else {
      registerAuthSuccess(username);
    }
    return authenticatedUser;
  }
  
  public Principal authenticate(GSSContext gssContext, boolean storeCreds)
  {
    if (gssContext.isEstablished())
    {
      String username = null;
      GSSName name = null;
      try
      {
        name = gssContext.getSrcName();
      }
      catch (GSSException e)
      {
        log.warn(sm.getString("realmBase.gssNameFail"), e);
        return null;
      }
      username = name.toString();
      if (isLocked(username))
      {
        registerAuthFailure(username);
        
        log.warn(sm.getString("lockOutRealm.authLockedUser", new Object[] { username }));
        return null;
      }
      Principal authenticatedUser = super.authenticate(gssContext, storeCreds);
      if (authenticatedUser == null) {
        registerAuthFailure(username);
      } else {
        registerAuthSuccess(username);
      }
      return authenticatedUser;
    }
    return null;
  }
  
  public void unlock(String username)
  {
    registerAuthSuccess(username);
  }
  
  private boolean isLocked(String username)
  {
    LockRecord lockRecord = null;
    synchronized (this)
    {
      lockRecord = (LockRecord)this.failedUsers.get(username);
    }
    if (lockRecord == null) {
      return false;
    }
    if ((lockRecord.getFailures() >= this.failureCount) && ((System.currentTimeMillis() - lockRecord.getLastFailureTime()) / 1000L < this.lockOutTime)) {
      return true;
    }
    return false;
  }
  
  private synchronized void registerAuthSuccess(String username)
  {
    this.failedUsers.remove(username);
  }
  
  private void registerAuthFailure(String username)
  {
    LockRecord lockRecord = null;
    synchronized (this)
    {
      if (!this.failedUsers.containsKey(username))
      {
        lockRecord = new LockRecord();
        this.failedUsers.put(username, lockRecord);
      }
      else
      {
        lockRecord = (LockRecord)this.failedUsers.get(username);
        if ((lockRecord.getFailures() >= this.failureCount) && ((System.currentTimeMillis() - lockRecord.getLastFailureTime()) / 1000L > this.lockOutTime)) {
          lockRecord.setFailures(0);
        }
      }
    }
    lockRecord.registerFailure();
  }
  
  public int getFailureCount()
  {
    return this.failureCount;
  }
  
  public void setFailureCount(int failureCount)
  {
    this.failureCount = failureCount;
  }
  
  public int getLockOutTime()
  {
    return this.lockOutTime;
  }
  
  protected String getName()
  {
    return "LockOutRealm";
  }
  
  public void setLockOutTime(int lockOutTime)
  {
    this.lockOutTime = lockOutTime;
  }
  
  public int getCacheSize()
  {
    return this.cacheSize;
  }
  
  public void setCacheSize(int cacheSize)
  {
    this.cacheSize = cacheSize;
  }
  
  public int getCacheRemovalWarningTime()
  {
    return this.cacheRemovalWarningTime;
  }
  
  public void setCacheRemovalWarningTime(int cacheRemovalWarningTime)
  {
    this.cacheRemovalWarningTime = cacheRemovalWarningTime;
  }
  
  protected static class LockRecord
  {
    private AtomicInteger failures = new AtomicInteger(0);
    private long lastFailureTime = 0L;
    
    protected LockRecord() {}
    
    public int getFailures()
    {
      return this.failures.get();
    }
    
    public void setFailures(int theFailures)
    {
      this.failures.set(theFailures);
    }
    
    public long getLastFailureTime()
    {
      return this.lastFailureTime;
    }
    
    public void registerFailure()
    {
      this.failures.incrementAndGet();
      this.lastFailureTime = System.currentTimeMillis();
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\realm\LockOutRealm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */