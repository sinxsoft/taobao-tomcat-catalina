package org.apache.catalina.realm;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.Principal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.CompositeName;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.PartialResultException;
import javax.naming.ServiceUnavailableException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import org.apache.catalina.LifecycleException;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.res.StringManager;
import org.ietf.jgss.GSSCredential;

public class JNDIRealm
  extends RealmBase
{
  protected String authentication;
  protected String connectionName;
  protected String connectionPassword;
  protected String connectionURL;
  protected DirContext context;
  protected String contextFactory;
  protected String derefAliases;
  public static final String DEREF_ALIASES = "java.naming.ldap.derefAliases";
  protected static final String info = "org.apache.catalina.realm.JNDIRealm/1.0";
  protected static final String name = "JNDIRealm";
  protected String protocol;
  protected boolean adCompat;
  protected String referrals;
  protected String userBase;
  protected String userSearch;
  private boolean userSearchAsUser;
  protected MessageFormat userSearchFormat;
  protected boolean userSubtree;
  protected String userPassword;
  protected String userRoleAttribute;
  protected String[] userPatternArray;
  protected String userPattern;
  protected MessageFormat[] userPatternFormatArray;
  protected String roleBase;
  protected MessageFormat roleBaseFormat;
  protected MessageFormat roleFormat;
  protected String userRoleName;
  protected String roleName;
  protected String roleSearch;
  protected boolean roleSubtree;
  protected boolean roleNested;
  protected boolean roleSearchAsUser;
  protected String alternateURL;
  protected int connectionAttempt;
  protected String commonRole;
  protected String connectionTimeout;
  protected long sizeLimit;
  protected int timeLimit;
  protected boolean useDelegatedCredential;
  protected String spnegoDelegationQop;
  
  public JNDIRealm()
  {
    this.authentication = null;
    
    this.connectionName = null;
    
    this.connectionPassword = null;
    
    this.connectionURL = null;
    
    this.context = null;
    
    this.contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
    
    this.derefAliases = null;
    
    this.protocol = null;
    
    this.adCompat = false;
    
    this.referrals = null;
    
    this.userBase = "";
    
    this.userSearch = null;
    
    this.userSearchAsUser = false;
    
    this.userSearchFormat = null;
    
    this.userSubtree = false;
    
    this.userPassword = null;
    
    this.userRoleAttribute = null;
    
    this.userPatternArray = null;
    
    this.userPattern = null;
    
    this.userPatternFormatArray = null;
    
    this.roleBase = "";
    
    this.roleBaseFormat = null;
    
    this.roleFormat = null;
    
    this.userRoleName = null;
    
    this.roleName = null;
    
    this.roleSearch = null;
    
    this.roleSubtree = false;
    
    this.roleNested = false;
    
    this.roleSearchAsUser = false;
    
    this.connectionAttempt = 0;
    
    this.commonRole = null;
    
    this.connectionTimeout = "5000";
    
    this.sizeLimit = 0L;
    
    this.timeLimit = 0;
    
    this.useDelegatedCredential = true;
    
    this.spnegoDelegationQop = "auth-conf";
  }
  
  public String getAuthentication()
  {
    return this.authentication;
  }
  
  public void setAuthentication(String authentication)
  {
    this.authentication = authentication;
  }
  
  public String getConnectionName()
  {
    return this.connectionName;
  }
  
  public void setConnectionName(String connectionName)
  {
    this.connectionName = connectionName;
  }
  
  public String getConnectionPassword()
  {
    return this.connectionPassword;
  }
  
  public void setConnectionPassword(String connectionPassword)
  {
    this.connectionPassword = connectionPassword;
  }
  
  public String getConnectionURL()
  {
    return this.connectionURL;
  }
  
  public void setConnectionURL(String connectionURL)
  {
    this.connectionURL = connectionURL;
  }
  
  public String getContextFactory()
  {
    return this.contextFactory;
  }
  
  public void setContextFactory(String contextFactory)
  {
    this.contextFactory = contextFactory;
  }
  
  public String getDerefAliases()
  {
    return this.derefAliases;
  }
  
  public void setDerefAliases(String derefAliases)
  {
    this.derefAliases = derefAliases;
  }
  
  public String getProtocol()
  {
    return this.protocol;
  }
  
  public void setProtocol(String protocol)
  {
    this.protocol = protocol;
  }
  
  public boolean getAdCompat()
  {
    return this.adCompat;
  }
  
  public void setAdCompat(boolean adCompat)
  {
    this.adCompat = adCompat;
  }
  
  public String getReferrals()
  {
    return this.referrals;
  }
  
  public void setReferrals(String referrals)
  {
    this.referrals = referrals;
  }
  
  public String getUserBase()
  {
    return this.userBase;
  }
  
  public void setUserBase(String userBase)
  {
    this.userBase = userBase;
  }
  
  public String getUserSearch()
  {
    return this.userSearch;
  }
  
  public void setUserSearch(String userSearch)
  {
    this.userSearch = userSearch;
    if (userSearch == null) {
      this.userSearchFormat = null;
    } else {
      this.userSearchFormat = new MessageFormat(userSearch);
    }
  }
  
  public boolean isUserSearchAsUser()
  {
    return this.userSearchAsUser;
  }
  
  public void setUserSearchAsUser(boolean userSearchAsUser)
  {
    this.userSearchAsUser = userSearchAsUser;
  }
  
  public boolean getUserSubtree()
  {
    return this.userSubtree;
  }
  
  public void setUserSubtree(boolean userSubtree)
  {
    this.userSubtree = userSubtree;
  }
  
  public String getUserRoleName()
  {
    return this.userRoleName;
  }
  
  public void setUserRoleName(String userRoleName)
  {
    this.userRoleName = userRoleName;
  }
  
  public String getRoleBase()
  {
    return this.roleBase;
  }
  
  public void setRoleBase(String roleBase)
  {
    this.roleBase = roleBase;
    if (roleBase == null) {
      this.roleBaseFormat = null;
    } else {
      this.roleBaseFormat = new MessageFormat(roleBase);
    }
  }
  
  public String getRoleName()
  {
    return this.roleName;
  }
  
  public void setRoleName(String roleName)
  {
    this.roleName = roleName;
  }
  
  public String getRoleSearch()
  {
    return this.roleSearch;
  }
  
  public void setRoleSearch(String roleSearch)
  {
    this.roleSearch = roleSearch;
    if (roleSearch == null) {
      this.roleFormat = null;
    } else {
      this.roleFormat = new MessageFormat(roleSearch);
    }
  }
  
  public boolean isRoleSearchAsUser()
  {
    return this.roleSearchAsUser;
  }
  
  public void setRoleSearchAsUser(boolean roleSearchAsUser)
  {
    this.roleSearchAsUser = roleSearchAsUser;
  }
  
  public boolean getRoleSubtree()
  {
    return this.roleSubtree;
  }
  
  public void setRoleSubtree(boolean roleSubtree)
  {
    this.roleSubtree = roleSubtree;
  }
  
  public boolean getRoleNested()
  {
    return this.roleNested;
  }
  
  public void setRoleNested(boolean roleNested)
  {
    this.roleNested = roleNested;
  }
  
  public String getUserPassword()
  {
    return this.userPassword;
  }
  
  public void setUserPassword(String userPassword)
  {
    this.userPassword = userPassword;
  }
  
  public String getUserRoleAttribute()
  {
    return this.userRoleAttribute;
  }
  
  public void setUserRoleAttribute(String userRoleAttribute)
  {
    this.userRoleAttribute = userRoleAttribute;
  }
  
  public String getUserPattern()
  {
    return this.userPattern;
  }
  
  public void setUserPattern(String userPattern)
  {
    this.userPattern = userPattern;
    if (userPattern == null)
    {
      this.userPatternArray = null;
    }
    else
    {
      this.userPatternArray = parseUserPatternString(userPattern);
      int len = this.userPatternArray.length;
      this.userPatternFormatArray = new MessageFormat[len];
      for (int i = 0; i < len; i++) {
        this.userPatternFormatArray[i] = new MessageFormat(this.userPatternArray[i]);
      }
    }
  }
  
  public String getAlternateURL()
  {
    return this.alternateURL;
  }
  
  public void setAlternateURL(String alternateURL)
  {
    this.alternateURL = alternateURL;
  }
  
  public String getCommonRole()
  {
    return this.commonRole;
  }
  
  public void setCommonRole(String commonRole)
  {
    this.commonRole = commonRole;
  }
  
  public String getConnectionTimeout()
  {
    return this.connectionTimeout;
  }
  
  public void setConnectionTimeout(String timeout)
  {
    this.connectionTimeout = timeout;
  }
  
  public long getSizeLimit()
  {
    return this.sizeLimit;
  }
  
  public void setSizeLimit(long sizeLimit)
  {
    this.sizeLimit = sizeLimit;
  }
  
  public int getTimeLimit()
  {
    return this.timeLimit;
  }
  
  public void setTimeLimit(int timeLimit)
  {
    this.timeLimit = timeLimit;
  }
  
  public boolean isUseDelegatedCredential()
  {
    return this.useDelegatedCredential;
  }
  
  public void setUseDelegatedCredential(boolean useDelegatedCredential)
  {
    this.useDelegatedCredential = useDelegatedCredential;
  }
  
  public String getSpnegoDelegationQop()
  {
    return this.spnegoDelegationQop;
  }
  
  public void setSpnegoDelegationQop(String spnegoDelegationQop)
  {
    this.spnegoDelegationQop = spnegoDelegationQop;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.realm.JNDIRealm/1.0";
  }
  
  public Principal authenticate(String username, String credentials)
  {
    DirContext context = null;
    Principal principal = null;
    try
    {
      context = open();
      try
      {
        principal = authenticate(context, username, credentials);
      }
      catch (NullPointerException e)
      {
        this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
        if (context != null) {
          close(context);
        }
        context = open();
        
        principal = authenticate(context, username, credentials);
      }
      catch (CommunicationException e)
      {
        this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
        if (context != null) {
          close(context);
        }
        context = open();
        
        principal = authenticate(context, username, credentials);
      }
      catch (ServiceUnavailableException e)
      {
        this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
        if (context != null) {
          close(context);
        }
        context = open();
        
        principal = authenticate(context, username, credentials);
      }
      release(context);
      
      return principal;
    }
    catch (NamingException e)
    {
      this.containerLog.error(sm.getString("jndiRealm.exception"), e);
      if (context != null) {
        close(context);
      }
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("Returning null principal.");
      }
    }
    return null;
  }
  
  public synchronized Principal authenticate(DirContext context, String username, String credentials)
    throws NamingException
  {
    if ((username == null) || (username.equals("")) || (credentials == null) || (credentials.equals("")))
    {
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("username null or empty: returning null principal.");
      }
      return null;
    }
    if (this.userPatternArray != null)
    {
      for (int curUserPattern = 0; curUserPattern < this.userPatternFormatArray.length; curUserPattern++)
      {
        User user = getUser(context, username, credentials, curUserPattern);
        if (user != null) {
          try
          {
            if (checkCredentials(context, user, credentials))
            {
              List<String> roles = getRoles(context, user);
              if (this.containerLog.isDebugEnabled())
              {
                Iterator<String> it = roles.iterator();
                while (it.hasNext()) {
                  this.containerLog.debug("Found role: " + (String)it.next());
                }
              }
              return new GenericPrincipal(username, credentials, roles);
            }
          }
          catch (InvalidNameException ine)
          {
            this.containerLog.warn(sm.getString("jndiRealm.exception"), ine);
          }
        }
      }
      return null;
    }
    User user = getUser(context, username, credentials);
    if (user == null) {
      return null;
    }
    if (!checkCredentials(context, user, credentials)) {
      return null;
    }
    List<String> roles = getRoles(context, user);
    if (this.containerLog.isDebugEnabled())
    {
      Iterator<String> it = roles.iterator();
      while (it.hasNext()) {
        this.containerLog.debug("Found role: " + (String)it.next());
      }
    }
    return new GenericPrincipal(username, credentials, roles);
  }
  
  protected User getUser(DirContext context, String username)
    throws NamingException
  {
    return getUser(context, username, null, -1);
  }
  
  protected User getUser(DirContext context, String username, String credentials)
    throws NamingException
  {
    return getUser(context, username, credentials, -1);
  }
  
  protected User getUser(DirContext context, String username, String credentials, int curUserPattern)
    throws NamingException
  {
    User user = null;
    
    ArrayList<String> list = new ArrayList();
    if (this.userPassword != null) {
      list.add(this.userPassword);
    }
    if (this.userRoleName != null) {
      list.add(this.userRoleName);
    }
    if (this.userRoleAttribute != null) {
      list.add(this.userRoleAttribute);
    }
    String[] attrIds = new String[list.size()];
    list.toArray(attrIds);
    if ((this.userPatternFormatArray != null) && (curUserPattern >= 0))
    {
      user = getUserByPattern(context, username, credentials, attrIds, curUserPattern);
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("Found user by pattern [" + user + "]");
      }
    }
    else
    {
      boolean thisUserSearchAsUser = isUserSearchAsUser();
      try
      {
        if (thisUserSearchAsUser) {
          userCredentialsAdd(context, username, credentials);
        }
        user = getUserBySearch(context, username, attrIds);
      }
      finally
      {
        if (thisUserSearchAsUser) {
          userCredentialsRemove(context);
        }
      }
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("Found user by search [" + user + "]");
      }
    }
    if ((this.userPassword == null) && (credentials != null) && (user != null)) {
      return new User(user.getUserName(), user.getDN(), credentials, user.getRoles(), user.getUserRoleId());
    }
    return user;
  }
  
  protected User getUserByPattern(DirContext context, String username, String[] attrIds, String dn)
    throws NamingException
  {
    if ((attrIds == null) || (attrIds.length == 0)) {
      return new User(username, dn, null, null, null);
    }
    Attributes attrs = null;
    try
    {
      attrs = context.getAttributes(dn, attrIds);
    }
    catch (NameNotFoundException e)
    {
      return null;
    }
    if (attrs == null) {
      return null;
    }
    String password = null;
    if (this.userPassword != null) {
      password = getAttributeValue(this.userPassword, attrs);
    }
    String userRoleAttrValue = null;
    if (this.userRoleAttribute != null) {
      userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
    }
    ArrayList<String> roles = null;
    if (this.userRoleName != null) {
      roles = addAttributeValues(this.userRoleName, attrs, roles);
    }
    return new User(username, dn, password, roles, userRoleAttrValue);
  }
  
  protected User getUserByPattern(DirContext context, String username, String credentials, String[] attrIds, int curUserPattern)
    throws NamingException
  {
    User user = null;
    if ((username == null) || (this.userPatternFormatArray[curUserPattern] == null)) {
      return null;
    }
    String dn = this.userPatternFormatArray[curUserPattern].format(new String[] { username });
    try
    {
      user = getUserByPattern(context, username, attrIds, dn);
    }
    catch (NameNotFoundException e)
    {
      return null;
    }
    catch (NamingException e)
    {
      try
      {
        userCredentialsAdd(context, dn, credentials);
        
        user = getUserByPattern(context, username, attrIds, dn);
      }
      finally
      {
        userCredentialsRemove(context);
      }
    }
    return user;
  }
  
  protected User getUserBySearch(DirContext context, String username, String[] attrIds)
    throws NamingException
  {
    if ((username == null) || (this.userSearchFormat == null)) {
      return null;
    }
    String filter = this.userSearchFormat.format(new String[] { username });
    
    SearchControls constraints = new SearchControls();
    if (this.userSubtree) {
      constraints.setSearchScope(2);
    } else {
      constraints.setSearchScope(1);
    }
    constraints.setCountLimit(this.sizeLimit);
    constraints.setTimeLimit(this.timeLimit);
    if (attrIds == null) {
      attrIds = new String[0];
    }
    constraints.setReturningAttributes(attrIds);
    
    NamingEnumeration<SearchResult> results = context.search(this.userBase, filter, constraints);
    try
    {
      if ((results == null) || (!results.hasMore())) {
        return null;
      }
    }
    catch (PartialResultException ex)
    {
      if (!this.adCompat) {
        throw ex;
      }
      return null;
    }
    SearchResult result = (SearchResult)results.next();
    try
    {
      if (results.hasMore())
      {
        if (this.containerLog.isInfoEnabled()) {
          this.containerLog.info("username " + username + " has multiple entries");
        }
        return null;
      }
    }
    catch (PartialResultException ex)
    {
      if (!this.adCompat) {
        throw ex;
      }
    }
    String dn = getDistinguishedName(context, this.userBase, result);
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  entry found for " + username + " with dn " + dn);
    }
    Attributes attrs = result.getAttributes();
    if (attrs == null) {
      return null;
    }
    String password = null;
    if (this.userPassword != null) {
      password = getAttributeValue(this.userPassword, attrs);
    }
    String userRoleAttrValue = null;
    if (this.userRoleAttribute != null) {
      userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
    }
    ArrayList<String> roles = null;
    if (this.userRoleName != null) {
      roles = addAttributeValues(this.userRoleName, attrs, roles);
    }
    return new User(username, dn, password, roles, userRoleAttrValue);
  }
  
  protected boolean checkCredentials(DirContext context, User user, String credentials)
    throws NamingException
  {
    boolean validated = false;
    if (this.userPassword == null) {
      validated = bindAsUser(context, user, credentials);
    } else {
      validated = compareCredentials(context, user, credentials);
    }
    if (this.containerLog.isTraceEnabled()) {
      if (validated) {
        this.containerLog.trace(sm.getString("jndiRealm.authenticateSuccess", new Object[] { user.getUserName() }));
      } else {
        this.containerLog.trace(sm.getString("jndiRealm.authenticateFailure", new Object[] { user.getUserName() }));
      }
    }
    return validated;
  }
  
  protected boolean compareCredentials(DirContext context, User info, String credentials)
    throws NamingException
  {
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  validating credentials");
    }
    if ((info == null) || (credentials == null)) {
      return false;
    }
    String password = info.getPassword();
    
    return compareCredentials(credentials, password);
  }
  
  protected boolean bindAsUser(DirContext context, User user, String credentials)
    throws NamingException
  {
    if ((credentials == null) || (user == null)) {
      return false;
    }
    String dn = user.getDN();
    if (dn == null) {
      return false;
    }
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  validating credentials by binding as the user");
    }
    userCredentialsAdd(context, dn, credentials);
    
    boolean validated = false;
    try
    {
      if (this.containerLog.isTraceEnabled()) {
        this.containerLog.trace("  binding as " + dn);
      }
      context.getAttributes("", null);
      validated = true;
    }
    catch (AuthenticationException e)
    {
      if (this.containerLog.isTraceEnabled()) {
        this.containerLog.trace("  bind attempt failed");
      }
    }
    userCredentialsRemove(context);
    
    return validated;
  }
  
  private void userCredentialsAdd(DirContext context, String dn, String credentials)
    throws NamingException
  {
    context.addToEnvironment("java.naming.security.principal", dn);
    context.addToEnvironment("java.naming.security.credentials", credentials);
  }
  
  private void userCredentialsRemove(DirContext context)
    throws NamingException
  {
    if (this.connectionName != null) {
      context.addToEnvironment("java.naming.security.principal", this.connectionName);
    } else {
      context.removeFromEnvironment("java.naming.security.principal");
    }
    if (this.connectionPassword != null) {
      context.addToEnvironment("java.naming.security.credentials", this.connectionPassword);
    } else {
      context.removeFromEnvironment("java.naming.security.credentials");
    }
  }
  
  protected List<String> getRoles(DirContext context, User user)
    throws NamingException
  {
    if (user == null) {
      return null;
    }
    String dn = user.getDN();
    String username = user.getUserName();
    String userRoleId = user.getUserRoleId();
    if ((dn == null) || (username == null)) {
      return null;
    }
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  getRoles(" + dn + ")");
    }
    List<String> list = new ArrayList();
    List<String> userRoles = user.getRoles();
    if (userRoles != null) {
      list.addAll(userRoles);
    }
    if (this.commonRole != null) {
      list.add(this.commonRole);
    }
    if (this.containerLog.isTraceEnabled())
    {
      this.containerLog.trace("  Found " + list.size() + " user internal roles");
      for (int i = 0; i < list.size(); i++) {
        this.containerLog.trace("  Found user internal role " + (String)list.get(i));
      }
    }
    if ((this.roleFormat == null) || (this.roleName == null)) {
      return list;
    }
    String filter = this.roleFormat.format(new String[] { doRFC2254Encoding(dn), username, userRoleId });
    SearchControls controls = new SearchControls();
    if (this.roleSubtree) {
      controls.setSearchScope(2);
    } else {
      controls.setSearchScope(1);
    }
    controls.setReturningAttributes(new String[] { this.roleName });
    
    String base = null;
    if (this.roleBaseFormat != null)
    {
      NameParser np = context.getNameParser("");
      Name name = np.parse(dn);
      String[] nameParts = new String[name.size()];
      for (int i = 0; i < name.size(); i++) {
        nameParts[i] = name.get(i);
      }
      base = this.roleBaseFormat.format(nameParts);
    }
    else
    {
      base = "";
    }
    NamingEnumeration<SearchResult> results = null;
    boolean thisRoleSearchAsUser = isRoleSearchAsUser();
    try
    {
      if (thisRoleSearchAsUser) {
        userCredentialsAdd(context, dn, user.getPassword());
      }
      results = context.search(base, filter, controls);
    }
    finally
    {
      if (thisRoleSearchAsUser) {
        userCredentialsRemove(context);
      }
    }
    if (results == null) {
      return list;
    }
    HashMap<String, String> groupMap = new HashMap();
    try
    {
      while (results.hasMore())
      {
        SearchResult result = (SearchResult)results.next();
        Attributes attrs = result.getAttributes();
        if (attrs != null)
        {
          String dname = getDistinguishedName(context, this.roleBase, result);
          String name = getAttributeValue(this.roleName, attrs);
          if ((name != null) && (dname != null)) {
            groupMap.put(dname, name);
          }
        }
      }
    }
    catch (PartialResultException ex)
    {
      if (!this.adCompat) {
        throw ex;
      }
    }
    Set<String> keys = groupMap.keySet();
    if (this.containerLog.isTraceEnabled())
    {
      this.containerLog.trace("  Found " + keys.size() + " direct roles");
      for (String key : keys) {
        this.containerLog.trace("  Found direct role " + key + " -> " + (String)groupMap.get(key));
      }
    }
    if (getRoleNested())
    {
      Object newGroups = new HashMap(groupMap);
      while (!((Map)newGroups).isEmpty())
      {
        Map<String, String> newThisRound = new HashMap();
        for (Map.Entry<String, String> group : ((Map)newGroups).entrySet())
        {
          filter = this.roleFormat.format(new String[] { (String)group.getKey(), (String)group.getValue(), (String)group.getValue() });
          if (this.containerLog.isTraceEnabled()) {
            this.containerLog.trace("Perform a nested group search with base " + this.roleBase + " and filter " + filter);
          }
          results = context.search(this.roleBase, filter, controls);
          try
          {
            while (results.hasMore())
            {
              SearchResult result = (SearchResult)results.next();
              Attributes attrs = result.getAttributes();
              if (attrs != null)
              {
                String dname = getDistinguishedName(context, this.roleBase, result);
                String name = getAttributeValue(this.roleName, attrs);
                if ((name != null) && (dname != null) && (!groupMap.keySet().contains(dname)))
                {
                  groupMap.put(dname, name);
                  newThisRound.put(dname, name);
                  if (this.containerLog.isTraceEnabled()) {
                    this.containerLog.trace("  Found nested role " + dname + " -> " + name);
                  }
                }
              }
            }
          }
          catch (PartialResultException ex)
          {
            if (!this.adCompat) {
              throw ex;
            }
          }
        }
        newGroups = newThisRound;
      }
    }
    list.addAll(groupMap.values());
    return list;
  }
  
  private String getAttributeValue(String attrId, Attributes attrs)
    throws NamingException
  {
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  retrieving attribute " + attrId);
    }
    if ((attrId == null) || (attrs == null)) {
      return null;
    }
    Attribute attr = attrs.get(attrId);
    if (attr == null) {
      return null;
    }
    Object value = attr.get();
    if (value == null) {
      return null;
    }
    String valueString = null;
    if ((value instanceof byte[])) {
      valueString = new String((byte[])value);
    } else {
      valueString = value.toString();
    }
    return valueString;
  }
  
  private ArrayList<String> addAttributeValues(String attrId, Attributes attrs, ArrayList<String> values)
    throws NamingException
  {
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  retrieving values for attribute " + attrId);
    }
    if ((attrId == null) || (attrs == null)) {
      return values;
    }
    if (values == null) {
      values = new ArrayList();
    }
    Attribute attr = attrs.get(attrId);
    if (attr == null) {
      return values;
    }
    NamingEnumeration<?> e = attr.getAll();
    try
    {
      while (e.hasMore())
      {
        String value = (String)e.next();
        values.add(value);
      }
    }
    catch (PartialResultException ex)
    {
      if (!this.adCompat) {
        throw ex;
      }
    }
    return values;
  }
  
  protected void close(DirContext context)
  {
    if (context == null) {
      return;
    }
    try
    {
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("Closing directory context");
      }
      context.close();
    }
    catch (NamingException e)
    {
      this.containerLog.error(sm.getString("jndiRealm.close"), e);
    }
    this.context = null;
  }
  
  protected String getName()
  {
    return "JNDIRealm";
  }
  
  protected String getPassword(String username)
  {
    return null;
  }
  
  protected Principal getPrincipal(String username)
  {
    return getPrincipal(username, null);
  }
  
  protected Principal getPrincipal(String username, GSSCredential gssCredential)
  {
    DirContext context = null;
    Principal principal = null;
    try
    {
      context = open();
      try
      {
        principal = getPrincipal(context, username, gssCredential);
      }
      catch (CommunicationException e)
      {
        this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
        if (context != null) {
          close(context);
        }
        context = open();
        
        principal = getPrincipal(context, username, gssCredential);
      }
      catch (ServiceUnavailableException e)
      {
        this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
        if (context != null) {
          close(context);
        }
        context = open();
        
        principal = getPrincipal(context, username, gssCredential);
      }
      release(context);
      
      return principal;
    }
    catch (NamingException e)
    {
      this.containerLog.error(sm.getString("jndiRealm.exception"), e);
      if (context != null) {
        close(context);
      }
    }
    return null;
  }
  
  protected synchronized Principal getPrincipal(DirContext context, String username, GSSCredential gssCredential)
    throws NamingException
  {
    User user = null;
    List<String> roles = null;
    Hashtable<?, ?> preservedEnvironment = null;
    try
    {
      if ((gssCredential != null) && (isUseDelegatedCredential()))
      {
        preservedEnvironment = context.getEnvironment();
        
        context.addToEnvironment("java.naming.security.authentication", "GSSAPI");
        
        context.addToEnvironment("javax.security.sasl.server.authentication", "true");
        
        context.addToEnvironment("javax.security.sasl.qop", this.spnegoDelegationQop);
      }
      user = getUser(context, username);
      if (user != null) {
        roles = getRoles(context, user);
      }
    }
    finally
    {
      restoreEnvironmentParameter(context, "java.naming.security.authentication", preservedEnvironment);
      
      restoreEnvironmentParameter(context, "javax.security.sasl.server.authentication", preservedEnvironment);
      
      restoreEnvironmentParameter(context, "javax.security.sasl.qop", preservedEnvironment);
    }
    if (user != null) {
      return new GenericPrincipal(user.getUserName(), user.getPassword(), roles, null, null, gssCredential);
    }
    return null;
  }
  
  private void restoreEnvironmentParameter(DirContext context, String parameterName, Hashtable<?, ?> preservedEnvironment)
  {
    try
    {
      context.removeFromEnvironment(parameterName);
      if ((preservedEnvironment != null) && (preservedEnvironment.containsKey(parameterName))) {
        context.addToEnvironment(parameterName, preservedEnvironment.get(parameterName));
      }
    }
    catch (NamingException e) {}
  }
  
  protected DirContext open()
    throws NamingException
  {
    if (this.context != null) {
      return this.context;
    }
    try
    {
      this.context = new InitialDirContext(getDirectoryContextEnvironment());
    }
    catch (Exception e)
    {
      this.connectionAttempt = 1;
      
      this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
      
      this.context = new InitialDirContext(getDirectoryContextEnvironment());
    }
    finally
    {
      this.connectionAttempt = 0;
    }
    return this.context;
  }
  
  protected Hashtable<String, String> getDirectoryContextEnvironment()
  {
    Hashtable<String, String> env = new Hashtable();
    if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt == 0)) {
      this.containerLog.debug("Connecting to URL " + this.connectionURL);
    } else if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt > 0)) {
      this.containerLog.debug("Connecting to URL " + this.alternateURL);
    }
    env.put("java.naming.factory.initial", this.contextFactory);
    if (this.connectionName != null) {
      env.put("java.naming.security.principal", this.connectionName);
    }
    if (this.connectionPassword != null) {
      env.put("java.naming.security.credentials", this.connectionPassword);
    }
    if ((this.connectionURL != null) && (this.connectionAttempt == 0)) {
      env.put("java.naming.provider.url", this.connectionURL);
    } else if ((this.alternateURL != null) && (this.connectionAttempt > 0)) {
      env.put("java.naming.provider.url", this.alternateURL);
    }
    if (this.authentication != null) {
      env.put("java.naming.security.authentication", this.authentication);
    }
    if (this.protocol != null) {
      env.put("java.naming.security.protocol", this.protocol);
    }
    if (this.referrals != null) {
      env.put("java.naming.referral", this.referrals);
    }
    if (this.derefAliases != null) {
      env.put("java.naming.ldap.derefAliases", this.derefAliases);
    }
    if (this.connectionTimeout != null) {
      env.put("com.sun.jndi.ldap.connect.timeout", this.connectionTimeout);
    }
    return env;
  }
  
  protected void release(DirContext context) {}
  
  protected void startInternal()
    throws LifecycleException
  {
    try
    {
      open();
    }
    catch (NamingException e)
    {
      this.containerLog.error(sm.getString("jndiRealm.open"), e);
    }
    super.startInternal();
  }
  
  protected void stopInternal()
    throws LifecycleException
  {
    super.stopInternal();
    
    close(this.context);
  }
  
  protected String[] parseUserPatternString(String userPatternString)
  {
    if (userPatternString != null)
    {
      ArrayList<String> pathList = new ArrayList();
      int startParenLoc = userPatternString.indexOf('(');
      if (startParenLoc == -1) {
        return new String[] { userPatternString };
      }
      int startingPoint = 0;
      while (startParenLoc > -1)
      {
        int endParenLoc = 0;
        while ((userPatternString.charAt(startParenLoc + 1) == '|') || ((startParenLoc != 0) && (userPatternString.charAt(startParenLoc - 1) == '\\'))) {
          startParenLoc = userPatternString.indexOf("(", startParenLoc + 1);
        }
        endParenLoc = userPatternString.indexOf(")", startParenLoc + 1);
        while (userPatternString.charAt(endParenLoc - 1) == '\\') {
          endParenLoc = userPatternString.indexOf(")", endParenLoc + 1);
        }
        String nextPathPart = userPatternString.substring(startParenLoc + 1, endParenLoc);
        
        pathList.add(nextPathPart);
        startingPoint = endParenLoc + 1;
        startParenLoc = userPatternString.indexOf('(', startingPoint);
      }
      return (String[])pathList.toArray(new String[0]);
    }
    return null;
  }
  
  protected String doRFC2254Encoding(String inString)
  {
    StringBuilder buf = new StringBuilder(inString.length());
    for (int i = 0; i < inString.length(); i++)
    {
      char c = inString.charAt(i);
      switch (c)
      {
      case '\\': 
        buf.append("\\5c");
        break;
      case '*': 
        buf.append("\\2a");
        break;
      case '(': 
        buf.append("\\28");
        break;
      case ')': 
        buf.append("\\29");
        break;
      case '\000': 
        buf.append("\\00");
        break;
      default: 
        buf.append(c);
      }
    }
    return buf.toString();
  }
  
  protected String getDistinguishedName(DirContext context, String base, SearchResult result)
    throws NamingException
  {
    if (result.isRelative())
    {
      if (this.containerLog.isTraceEnabled()) {
        this.containerLog.trace("  search returned relative name: " + result.getName());
      }
      NameParser parser = context.getNameParser("");
      Name contextName = parser.parse(context.getNameInNamespace());
      Name baseName = parser.parse(base);
      
      Name entryName = parser.parse(new CompositeName(result.getName()).get(0));
      
      Name name = contextName.addAll(baseName);
      name = name.addAll(entryName);
      return name.toString();
    }
    String absoluteName = result.getName();
    if (this.containerLog.isTraceEnabled()) {
      this.containerLog.trace("  search returned absolute name: " + result.getName());
    }
    try
    {
      NameParser parser = context.getNameParser("");
      URI userNameUri = new URI(absoluteName);
      String pathComponent = userNameUri.getPath();
      if (pathComponent.length() < 1) {
        throw new InvalidNameException("Search returned unparseable absolute name: " + absoluteName);
      }
      Name name = parser.parse(pathComponent.substring(1));
      return name.toString();
    }
    catch (URISyntaxException e)
    {
      throw new InvalidNameException("Search returned unparseable absolute name: " + absoluteName);
    }
  }
  
  protected static class User
  {
    private final String username;
    private final String dn;
    private final String password;
    private final List<String> roles;
    private final String userRoleId;
    
    public User(String username, String dn, String password, List<String> roles, String userRoleId)
    {
      this.username = username;
      this.dn = dn;
      this.password = password;
      if (roles == null) {
        this.roles = Collections.emptyList();
      } else {
        this.roles = Collections.unmodifiableList(roles);
      }
      this.userRoleId = userRoleId;
    }
    
    public String getUserName()
    {
      return this.username;
    }
    
    public String getDN()
    {
      return this.dn;
    }
    
    public String getPassword()
    {
      return this.password;
    }
    
    public List<String> getRoles()
    {
      return this.roles;
    }
    
    public String getUserRoleId()
    {
      return this.userRoleId;
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\realm\JNDIRealm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */