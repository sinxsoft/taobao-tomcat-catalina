package org.apache.catalina.realm;

import java.security.Principal;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.catalina.LifecycleException;
import org.apache.juli.logging.Log;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public class JDBCRealm
  extends RealmBase
{
  protected String connectionName = null;
  protected String connectionPassword = null;
  protected String connectionURL = null;
  protected Connection dbConnection = null;
  protected Driver driver = null;
  protected String driverName = null;
  protected static final String info = "org.apache.catalina.realm.JDBCRealm/1.0";
  protected static final String name = "JDBCRealm";
  protected PreparedStatement preparedCredentials = null;
  protected PreparedStatement preparedRoles = null;
  protected String roleNameCol = null;
  protected String userCredCol = null;
  protected String userNameCol = null;
  protected String userRoleTable = null;
  protected String userTable = null;
  
  public JDBCRealm() {}
  
  public String getConnectionName()
  {
    return this.connectionName;
  }
  
  public void setConnectionName(String connectionName)
  {
    this.connectionName = connectionName;
  }
  
  public String getConnectionPassword()
  {
    return this.connectionPassword;
  }
  
  public void setConnectionPassword(String connectionPassword)
  {
    this.connectionPassword = connectionPassword;
  }
  
  public String getConnectionURL()
  {
    return this.connectionURL;
  }
  
  public void setConnectionURL(String connectionURL)
  {
    this.connectionURL = connectionURL;
  }
  
  public String getDriverName()
  {
    return this.driverName;
  }
  
  public void setDriverName(String driverName)
  {
    this.driverName = driverName;
  }
  
  public String getRoleNameCol()
  {
    return this.roleNameCol;
  }
  
  public void setRoleNameCol(String roleNameCol)
  {
    this.roleNameCol = roleNameCol;
  }
  
  public String getUserCredCol()
  {
    return this.userCredCol;
  }
  
  public void setUserCredCol(String userCredCol)
  {
    this.userCredCol = userCredCol;
  }
  
  public String getUserNameCol()
  {
    return this.userNameCol;
  }
  
  public void setUserNameCol(String userNameCol)
  {
    this.userNameCol = userNameCol;
  }
  
  public String getUserRoleTable()
  {
    return this.userRoleTable;
  }
  
  public void setUserRoleTable(String userRoleTable)
  {
    this.userRoleTable = userRoleTable;
  }
  
  public String getUserTable()
  {
    return this.userTable;
  }
  
  public void setUserTable(String userTable)
  {
    this.userTable = userTable;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.realm.JDBCRealm/1.0";
  }
  
  public synchronized Principal authenticate(String username, String credentials)
  {
    int numberOfTries = 2;
    while (numberOfTries > 0)
    {
      try
      {
        open();
        
        return authenticate(this.dbConnection, username, credentials);
      }
      catch (SQLException e)
      {
        this.containerLog.error(sm.getString("jdbcRealm.exception"), e);
        if (this.dbConnection != null) {
          close(this.dbConnection);
        }
      }
      numberOfTries--;
    }
    return null;
  }
  
  public synchronized Principal authenticate(Connection dbConnection, String username, String credentials)
  {
    if ((username == null) || (credentials == null)) {
      return null;
    }
    String dbCredentials = getPassword(username);
    
    boolean validated = compareCredentials(credentials, dbCredentials);
    if (validated)
    {
      if (this.containerLog.isTraceEnabled()) {
        this.containerLog.trace(sm.getString("jdbcRealm.authenticateSuccess", new Object[] { username }));
      }
    }
    else
    {
      if (this.containerLog.isTraceEnabled()) {
        this.containerLog.trace(sm.getString("jdbcRealm.authenticateFailure", new Object[] { username }));
      }
      return null;
    }
    ArrayList<String> roles = getRoles(username);
    
    return new GenericPrincipal(username, credentials, roles);
  }
  
  protected void close(Connection dbConnection)
  {
    if (dbConnection == null) {
      return;
    }
    try
    {
      this.preparedCredentials.close();
    }
    catch (Throwable f)
    {
      ExceptionUtils.handleThrowable(f);
    }
    this.preparedCredentials = null;
    try
    {
      this.preparedRoles.close();
    }
    catch (Throwable f)
    {
      ExceptionUtils.handleThrowable(f);
    }
    this.preparedRoles = null;
    try
    {
      dbConnection.close();
    }
    catch (SQLException e)
    {
      this.containerLog.warn(sm.getString("jdbcRealm.close"), e);
    }
    finally
    {
      this.dbConnection = null;
    }
  }
  
  protected PreparedStatement credentials(Connection dbConnection, String username)
    throws SQLException
  {
    if (this.preparedCredentials == null)
    {
      StringBuilder sb = new StringBuilder("SELECT ");
      sb.append(this.userCredCol);
      sb.append(" FROM ");
      sb.append(this.userTable);
      sb.append(" WHERE ");
      sb.append(this.userNameCol);
      sb.append(" = ?");
      if (this.containerLog.isDebugEnabled()) {
        this.containerLog.debug("credentials query: " + sb.toString());
      }
      this.preparedCredentials = dbConnection.prepareStatement(sb.toString());
    }
    if (username == null) {
      this.preparedCredentials.setNull(1, 12);
    } else {
      this.preparedCredentials.setString(1, username);
    }
    return this.preparedCredentials;
  }
  
  protected String getName()
  {
    return "JDBCRealm";
  }
  
  protected synchronized String getPassword(String username)
  {
    String dbCredentials = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    
    int numberOfTries = 2;
    while (numberOfTries > 0)
    {
      try
      {
        open();
        
        stmt = credentials(this.dbConnection, username);
        rs = stmt.executeQuery();
        if (rs.next()) {
          dbCredentials = rs.getString(1);
        }
        this.dbConnection.commit();
        if (dbCredentials != null) {
          dbCredentials = dbCredentials.trim();
        }
        return dbCredentials;
      }
      catch (SQLException e)
      {
        this.containerLog.error(sm.getString("jdbcRealm.exception"), e);
      }
      finally
      {
        if (rs != null) {
          try
          {
            rs.close();
          }
          catch (SQLException e)
          {
            this.containerLog.warn(sm.getString("jdbcRealm.abnormalCloseResultSet"));
          }
        }
      }
      if (this.dbConnection != null) {
        close(this.dbConnection);
      }
      numberOfTries--;
    }
    return null;
  }
  
  protected synchronized Principal getPrincipal(String username)
  {
    return new GenericPrincipal(username, getPassword(username), getRoles(username));
  }
  
  protected ArrayList<String> getRoles(String username)
  {
    if ((this.allRolesMode != RealmBase.AllRolesMode.STRICT_MODE) && (!isRoleStoreDefined())) {
      return null;
    }
    PreparedStatement stmt = null;
    ResultSet rs = null;
    
    int numberOfTries = 2;
    while (numberOfTries > 0) {
      try
      {
        open();
        try
        {
          ArrayList<String> roleList = new ArrayList();
          stmt = roles(this.dbConnection, username);
          rs = stmt.executeQuery();
          String role;
          while (rs.next())
          {
            role = rs.getString(1);
            if (null != role) {
              roleList.add(role.trim());
            }
          }
          rs.close();
          rs = null;
          
          return roleList;
        }
        finally
        {
          if (rs != null) {
            try
            {
              rs.close();
            }
            catch (SQLException e)
            {
              this.containerLog.warn(sm.getString("jdbcRealm.abnormalCloseResultSet"));
            }
          }
          this.dbConnection.commit();
        }
        numberOfTries--;
      }
      catch (SQLException e)
      {
        this.containerLog.error(sm.getString("jdbcRealm.exception"), e);
        if (this.dbConnection != null) {
          close(this.dbConnection);
        }
      }
    }
    return null;
  }
  
  protected Connection open()
    throws SQLException
  {
    if (this.dbConnection != null) {
      return this.dbConnection;
    }
    if (this.driver == null) {
      try
      {
        Class<?> clazz = Class.forName(this.driverName);
        this.driver = ((Driver)clazz.newInstance());
      }
      catch (Throwable e)
      {
        ExceptionUtils.handleThrowable(e);
        throw new SQLException(e.getMessage(), e);
      }
    }
    Properties props = new Properties();
    if (this.connectionName != null) {
      props.put("user", this.connectionName);
    }
    if (this.connectionPassword != null) {
      props.put("password", this.connectionPassword);
    }
    this.dbConnection = this.driver.connect(this.connectionURL, props);
    if (this.dbConnection == null) {
      throw new SQLException(sm.getString("jdbcRealm.open.invalidurl", new Object[] { this.driverName, this.connectionURL }));
    }
    this.dbConnection.setAutoCommit(false);
    return this.dbConnection;
  }
  
  @Deprecated
  protected void release(Connection dbConnection) {}
  
  protected synchronized PreparedStatement roles(Connection dbConnection, String username)
    throws SQLException
  {
    if (this.preparedRoles == null)
    {
      StringBuilder sb = new StringBuilder("SELECT ");
      sb.append(this.roleNameCol);
      sb.append(" FROM ");
      sb.append(this.userRoleTable);
      sb.append(" WHERE ");
      sb.append(this.userNameCol);
      sb.append(" = ?");
      this.preparedRoles = dbConnection.prepareStatement(sb.toString());
    }
    this.preparedRoles.setString(1, username);
    return this.preparedRoles;
  }
  
  private boolean isRoleStoreDefined()
  {
    return (this.userRoleTable != null) || (this.roleNameCol != null);
  }
  
  protected void startInternal()
    throws LifecycleException
  {
    try
    {
      open();
    }
    catch (SQLException e)
    {
      this.containerLog.error(sm.getString("jdbcRealm.open"), e);
    }
    super.startInternal();
  }
  
  protected void stopInternal()
    throws LifecycleException
  {
    super.stopInternal();
    
    close(this.dbConnection);
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\realm\JDBCRealm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */