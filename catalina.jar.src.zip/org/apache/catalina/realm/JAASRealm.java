package org.apache.catalina.realm;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.AccountExpiredException;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import org.apache.catalina.Container;
import org.apache.catalina.LifecycleException;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public class JAASRealm
  extends RealmBase
{
  private static final Log log = LogFactory.getLog(JAASRealm.class);
  protected String appName = null;
  protected static final String info = "org.apache.catalina.realm.JAASRealm/1.0";
  protected static final String name = "JAASRealm";
  protected List<String> roleClasses = new ArrayList();
  protected List<String> userClasses = new ArrayList();
  protected boolean useContextClassLoader = true;
  protected String configFile;
  protected Configuration jaasConfiguration;
  protected volatile boolean jaasConfigurationLoaded = false;
  
  public JAASRealm() {}
  
  public String getConfigFile()
  {
    return this.configFile;
  }
  
  public void setConfigFile(String configFile)
  {
    this.configFile = configFile;
  }
  
  public void setAppName(String name)
  {
    this.appName = name;
  }
  
  public String getAppName()
  {
    return this.appName;
  }
  
  public void setUseContextClassLoader(boolean useContext)
  {
    this.useContextClassLoader = useContext;
    log.info("Setting useContextClassLoader = " + useContext);
  }
  
  public boolean isUseContextClassLoader()
  {
    return this.useContextClassLoader;
  }
  
  public void setContainer(Container container)
  {
    super.setContainer(container);
    if (this.appName == null)
    {
      String name = container.getName();
      if (!name.startsWith("/")) {
        name = "/" + name;
      }
      name = makeLegalForJAAS(name);
      
      this.appName = name;
      
      log.info("Set JAAS app name " + this.appName);
    }
  }
  
  protected String roleClassNames = null;
  
  public String getRoleClassNames()
  {
    return this.roleClassNames;
  }
  
  public void setRoleClassNames(String roleClassNames)
  {
    this.roleClassNames = roleClassNames;
  }
  
  protected void parseClassNames(String classNamesString, List<String> classNamesList)
  {
    classNamesList.clear();
    if (classNamesString == null) {
      return;
    }
    ClassLoader loader = getClass().getClassLoader();
    if (isUseContextClassLoader()) {
      loader = Thread.currentThread().getContextClassLoader();
    }
    String[] classNames = classNamesString.split("[ ]*,[ ]*");
    for (int i = 0; i < classNames.length; i++) {
      if (classNames[i].length() != 0) {
        try
        {
          Class<?> principalClass = Class.forName(classNames[i], false, loader);
          if (Principal.class.isAssignableFrom(principalClass)) {
            classNamesList.add(classNames[i]);
          } else {
            log.error("Class " + classNames[i] + " is not implementing " + "java.security.Principal! Class not added.");
          }
        }
        catch (ClassNotFoundException e)
        {
          log.error("Class " + classNames[i] + " not found! Class not added.");
        }
      }
    }
  }
  
  protected String userClassNames = null;
  
  public String getUserClassNames()
  {
    return this.userClassNames;
  }
  
  public void setUserClassNames(String userClassNames)
  {
    this.userClassNames = userClassNames;
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.realm.JAASRealm/1.0";
  }
  
  public Principal authenticate(String username, String credentials)
  {
    return authenticate(username, new JAASCallbackHandler(this, username, credentials));
  }
  
  public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
  {
    return authenticate(username, new JAASCallbackHandler(this, username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2, "DIGEST"));
  }
  
  protected Principal authenticate(String username, CallbackHandler callbackHandler)
  {
    try
    {
      LoginContext loginContext = null;
      if (this.appName == null) {
        this.appName = "Tomcat";
      }
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("jaasRealm.beginLogin", new Object[] { username, this.appName }));
      }
      ClassLoader ocl = null;
      if (!isUseContextClassLoader())
      {
        ocl = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
      }
      try
      {
        Configuration config = getConfig();
        loginContext = new LoginContext(this.appName, null, callbackHandler, config);
      }
      catch (Throwable e)
      {
        ExceptionUtils.handleThrowable(e);
        log.error(sm.getString("jaasRealm.unexpectedError"), e);
        return null;
      }
      finally
      {
        if (!isUseContextClassLoader()) {
          Thread.currentThread().setContextClassLoader(ocl);
        }
      }
      if (log.isDebugEnabled()) {
        log.debug("Login context created " + username);
      }
      Subject subject = null;
      try
      {
        loginContext.login();
        subject = loginContext.getSubject();
        if (subject == null)
        {
          if (log.isDebugEnabled()) {
            log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }));
          }
          return null;
        }
      }
      catch (AccountExpiredException e)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("jaasRealm.accountExpired", new Object[] { username }));
        }
        return null;
      }
      catch (CredentialExpiredException e)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("jaasRealm.credentialExpired", new Object[] { username }));
        }
        return null;
      }
      catch (FailedLoginException e)
      {
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }));
        }
        return null;
      }
      catch (LoginException e)
      {
        log.warn(sm.getString("jaasRealm.loginException", new Object[] { username }), e);
        return null;
      }
      catch (Throwable e)
      {
        ExceptionUtils.handleThrowable(e);
        log.error(sm.getString("jaasRealm.unexpectedError"), e);
        return null;
      }
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("jaasRealm.loginContextCreated", new Object[] { username }));
      }
      Principal principal = createPrincipal(username, subject, loginContext);
      if (principal == null)
      {
        log.debug(sm.getString("jaasRealm.authenticateFailure", new Object[] { username }));
        return null;
      }
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("jaasRealm.authenticateSuccess", new Object[] { username }));
      }
      return principal;
    }
    catch (Throwable t)
    {
      log.error("error ", t);
    }
    return null;
  }
  
  protected String getName()
  {
    return "JAASRealm";
  }
  
  protected String getPassword(String username)
  {
    return null;
  }
  
  protected Principal getPrincipal(String username)
  {
    return authenticate(username, new JAASCallbackHandler(this, username, null, null, null, null, null, null, null, "CLIENT_CERT"));
  }
  
  protected Principal createPrincipal(String username, Subject subject, LoginContext loginContext)
  {
    List<String> roles = new ArrayList();
    Principal userPrincipal = null;
    
    Iterator<Principal> principals = subject.getPrincipals().iterator();
    while (principals.hasNext())
    {
      Principal principal = (Principal)principals.next();
      
      String principalClass = principal.getClass().getName();
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("jaasRealm.checkPrincipal", new Object[] { principal, principalClass }));
      }
      if ((userPrincipal == null) && (this.userClasses.contains(principalClass)))
      {
        userPrincipal = principal;
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("jaasRealm.userPrincipalSuccess", new Object[] { principal.getName() }));
        }
      }
      if (this.roleClasses.contains(principalClass))
      {
        roles.add(principal.getName());
        if (log.isDebugEnabled()) {
          log.debug(sm.getString("jaasRealm.rolePrincipalAdd", new Object[] { principal.getName() }));
        }
      }
    }
    if (userPrincipal == null)
    {
      if (log.isDebugEnabled())
      {
        log.debug(sm.getString("jaasRealm.userPrincipalFailure"));
        log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
      }
    }
    else if ((roles.size() == 0) && 
      (log.isDebugEnabled())) {
      log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
    }
    return new GenericPrincipal(username, null, roles, userPrincipal, loginContext);
  }
  
  protected String makeLegalForJAAS(String src)
  {
    String result = src;
    if (result == null) {
      result = "other";
    }
    if (result.startsWith("/")) {
      result = result.substring(1);
    }
    return result;
  }
  
  protected void startInternal()
    throws LifecycleException
  {
    parseClassNames(this.userClassNames, this.userClasses);
    parseClassNames(this.roleClassNames, this.roleClasses);
    
    super.startInternal();
  }
  
  /* Error */
  protected Configuration getConfig()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
    //   4: ifeq +8 -> 12
    //   7: aload_0
    //   8: getfield 105	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
    //   11: areturn
    //   12: aload_0
    //   13: dup
    //   14: astore_1
    //   15: monitorenter
    //   16: aload_0
    //   17: getfield 11	org/apache/catalina/realm/JAASRealm:configFile	Ljava/lang/String;
    //   20: ifnonnull +12 -> 32
    //   23: aload_0
    //   24: iconst_1
    //   25: putfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
    //   28: aconst_null
    //   29: aload_1
    //   30: monitorexit
    //   31: areturn
    //   32: invokestatic 30	java/lang/Thread:currentThread	()Ljava/lang/Thread;
    //   35: invokevirtual 31	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
    //   38: aload_0
    //   39: getfield 11	org/apache/catalina/realm/JAASRealm:configFile	Ljava/lang/String;
    //   42: invokevirtual 106	java/lang/ClassLoader:getResource	(Ljava/lang/String;)Ljava/net/URL;
    //   45: astore_2
    //   46: aload_2
    //   47: invokevirtual 107	java/net/URL:toURI	()Ljava/net/URI;
    //   50: astore_3
    //   51: ldc 108
    //   53: invokestatic 109	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   56: astore 4
    //   58: aload 4
    //   60: iconst_1
    //   61: anewarray 110	java/lang/Class
    //   64: dup
    //   65: iconst_0
    //   66: ldc_w 111
    //   69: aastore
    //   70: invokevirtual 112	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   73: astore 5
    //   75: aload 5
    //   77: iconst_1
    //   78: anewarray 55	java/lang/Object
    //   81: dup
    //   82: iconst_0
    //   83: aload_3
    //   84: aastore
    //   85: invokevirtual 113	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   88: checkcast 114	javax/security/auth/login/Configuration
    //   91: astore 6
    //   93: aload_0
    //   94: aload 6
    //   96: putfield 105	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
    //   99: aload_0
    //   100: iconst_1
    //   101: putfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
    //   104: aload_0
    //   105: getfield 105	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
    //   108: aload_1
    //   109: monitorexit
    //   110: areturn
    //   111: astore 7
    //   113: aload_1
    //   114: monitorexit
    //   115: aload 7
    //   117: athrow
    //   118: astore_1
    //   119: new 116	java/lang/RuntimeException
    //   122: dup
    //   123: aload_1
    //   124: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   127: athrow
    //   128: astore_1
    //   129: new 116	java/lang/RuntimeException
    //   132: dup
    //   133: aload_1
    //   134: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   137: athrow
    //   138: astore_1
    //   139: new 116	java/lang/RuntimeException
    //   142: dup
    //   143: aload_1
    //   144: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   147: athrow
    //   148: astore_1
    //   149: new 116	java/lang/RuntimeException
    //   152: dup
    //   153: aload_1
    //   154: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   157: athrow
    //   158: astore_1
    //   159: new 116	java/lang/RuntimeException
    //   162: dup
    //   163: aload_1
    //   164: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   167: athrow
    //   168: astore_1
    //   169: new 116	java/lang/RuntimeException
    //   172: dup
    //   173: aload_1
    //   174: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   177: athrow
    //   178: astore_1
    //   179: new 116	java/lang/RuntimeException
    //   182: dup
    //   183: aload_1
    //   184: invokevirtual 124	java/lang/reflect/InvocationTargetException:getCause	()Ljava/lang/Throwable;
    //   187: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   190: athrow
    //   191: astore_1
    //   192: new 116	java/lang/RuntimeException
    //   195: dup
    //   196: aload_1
    //   197: invokespecial 117	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   200: athrow
    // Line number table:
    //   Java source line #639	-> byte code offset #0
    //   Java source line #640	-> byte code offset #7
    //   Java source line #642	-> byte code offset #12
    //   Java source line #643	-> byte code offset #16
    //   Java source line #644	-> byte code offset #23
    //   Java source line #645	-> byte code offset #28
    //   Java source line #647	-> byte code offset #32
    //   Java source line #649	-> byte code offset #46
    //   Java source line #651	-> byte code offset #51
    //   Java source line #653	-> byte code offset #58
    //   Java source line #655	-> byte code offset #75
    //   Java source line #656	-> byte code offset #93
    //   Java source line #657	-> byte code offset #99
    //   Java source line #658	-> byte code offset #104
    //   Java source line #659	-> byte code offset #111
    //   Java source line #660	-> byte code offset #118
    //   Java source line #661	-> byte code offset #119
    //   Java source line #662	-> byte code offset #128
    //   Java source line #663	-> byte code offset #129
    //   Java source line #664	-> byte code offset #138
    //   Java source line #665	-> byte code offset #139
    //   Java source line #666	-> byte code offset #148
    //   Java source line #667	-> byte code offset #149
    //   Java source line #668	-> byte code offset #158
    //   Java source line #669	-> byte code offset #159
    //   Java source line #670	-> byte code offset #168
    //   Java source line #671	-> byte code offset #169
    //   Java source line #672	-> byte code offset #178
    //   Java source line #673	-> byte code offset #179
    //   Java source line #674	-> byte code offset #191
    //   Java source line #675	-> byte code offset #192
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	201	0	this	JAASRealm
    //   118	6	1	ex	java.net.URISyntaxException
    //   128	6	1	ex	NoSuchMethodException
    //   138	6	1	ex	SecurityException
    //   148	6	1	ex	InstantiationException
    //   158	6	1	ex	IllegalAccessException
    //   168	6	1	ex	IllegalArgumentException
    //   178	6	1	ex	java.lang.reflect.InvocationTargetException
    //   191	6	1	ex	ClassNotFoundException
    //   45	2	2	resource	java.net.URL
    //   50	34	3	uri	java.net.URI
    //   56	3	4	sunConfigFile	Class<Configuration>
    //   73	3	5	constructor	java.lang.reflect.Constructor<Configuration>
    //   91	4	6	config	Configuration
    //   111	5	7	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   16	31	111	finally
    //   32	110	111	finally
    //   111	115	111	finally
    //   0	11	118	java/net/URISyntaxException
    //   12	31	118	java/net/URISyntaxException
    //   32	110	118	java/net/URISyntaxException
    //   111	118	118	java/net/URISyntaxException
    //   0	11	128	java/lang/NoSuchMethodException
    //   12	31	128	java/lang/NoSuchMethodException
    //   32	110	128	java/lang/NoSuchMethodException
    //   111	118	128	java/lang/NoSuchMethodException
    //   0	11	138	java/lang/SecurityException
    //   12	31	138	java/lang/SecurityException
    //   32	110	138	java/lang/SecurityException
    //   111	118	138	java/lang/SecurityException
    //   0	11	148	java/lang/InstantiationException
    //   12	31	148	java/lang/InstantiationException
    //   32	110	148	java/lang/InstantiationException
    //   111	118	148	java/lang/InstantiationException
    //   0	11	158	java/lang/IllegalAccessException
    //   12	31	158	java/lang/IllegalAccessException
    //   32	110	158	java/lang/IllegalAccessException
    //   111	118	158	java/lang/IllegalAccessException
    //   0	11	168	java/lang/IllegalArgumentException
    //   12	31	168	java/lang/IllegalArgumentException
    //   32	110	168	java/lang/IllegalArgumentException
    //   111	118	168	java/lang/IllegalArgumentException
    //   0	11	178	java/lang/reflect/InvocationTargetException
    //   12	31	178	java/lang/reflect/InvocationTargetException
    //   32	110	178	java/lang/reflect/InvocationTargetException
    //   111	118	178	java/lang/reflect/InvocationTargetException
    //   0	11	191	java/lang/ClassNotFoundException
    //   12	31	191	java/lang/ClassNotFoundException
    //   32	110	191	java/lang/ClassNotFoundException
    //   111	118	191	java/lang/ClassNotFoundException
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\realm\JAASRealm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */