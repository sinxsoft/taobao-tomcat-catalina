package org.apache.catalina.users;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;

public class MemoryUserDatabaseFactory
  implements ObjectFactory
{
  public MemoryUserDatabaseFactory() {}
  
  public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment)
    throws Exception
  {
    if ((obj == null) || (!(obj instanceof Reference))) {
      return null;
    }
    Reference ref = (Reference)obj;
    if (!"org.apache.catalina.UserDatabase".equals(ref.getClassName())) {
      return null;
    }
    MemoryUserDatabase database = new MemoryUserDatabase(name.toString());
    RefAddr ra = null;
    
    ra = ref.get("pathname");
    if (ra != null) {
      database.setPathname(ra.getContent().toString());
    }
    ra = ref.get("readonly");
    if (ra != null) {
      database.setReadonly(Boolean.valueOf(ra.getContent().toString()).booleanValue());
    }
    database.open();
    if (!database.getReadonly()) {
      database.save();
    }
    return database;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\MemoryUserDatabaseFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */