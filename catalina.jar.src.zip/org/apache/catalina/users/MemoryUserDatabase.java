package org.apache.catalina.users;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.User;
import org.apache.catalina.UserDatabase;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.digester.Digester;
import org.apache.tomcat.util.res.StringManager;

public class MemoryUserDatabase
  implements UserDatabase
{
  private static final Log log = LogFactory.getLog(MemoryUserDatabase.class);
  
  public MemoryUserDatabase()
  {
    this(null);
  }
  
  public MemoryUserDatabase(String id)
  {
    this.id = id;
  }
  
  protected final HashMap<String, Group> groups = new HashMap();
  protected final String id;
  protected String pathname = "conf/tomcat-users.xml";
  protected String pathnameOld = this.pathname + ".old";
  protected String pathnameNew = this.pathname + ".new";
  protected boolean readonly = true;
  protected final HashMap<String, Role> roles = new HashMap();
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.users");
  protected final HashMap<String, User> users = new HashMap();
  
  /* Error */
  public Iterator<Group> getGroups()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryUserDatabase:groups	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryUserDatabase:groups	Ljava/util/HashMap;
    //   11: invokevirtual 20	java/util/HashMap:values	()Ljava/util/Collection;
    //   14: invokeinterface 21 1 0
    //   19: aload_1
    //   20: monitorexit
    //   21: areturn
    //   22: astore_2
    //   23: aload_1
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    // Line number table:
    //   Java source line #146	-> byte code offset #0
    //   Java source line #147	-> byte code offset #7
    //   Java source line #148	-> byte code offset #22
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	MemoryUserDatabase
    //   5	19	1	Ljava/lang/Object;	Object
    //   22	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	21	22	finally
    //   22	25	22	finally
  }
  
  public String getId()
  {
    return this.id;
  }
  
  public String getPathname()
  {
    return this.pathname;
  }
  
  public void setPathname(String pathname)
  {
    this.pathname = pathname;
    this.pathnameOld = (pathname + ".old");
    this.pathnameNew = (pathname + ".new");
  }
  
  public boolean getReadonly()
  {
    return this.readonly;
  }
  
  public void setReadonly(boolean readonly)
  {
    this.readonly = readonly;
  }
  
  /* Error */
  public Iterator<Role> getRoles()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 17	org/apache/catalina/users/MemoryUserDatabase:roles	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 17	org/apache/catalina/users/MemoryUserDatabase:roles	Ljava/util/HashMap;
    //   11: invokevirtual 20	java/util/HashMap:values	()Ljava/util/Collection;
    //   14: invokeinterface 21 1 0
    //   19: aload_1
    //   20: monitorexit
    //   21: areturn
    //   22: astore_2
    //   23: aload_1
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    // Line number table:
    //   Java source line #216	-> byte code offset #0
    //   Java source line #217	-> byte code offset #7
    //   Java source line #218	-> byte code offset #22
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	MemoryUserDatabase
    //   5	19	1	Ljava/lang/Object;	Object
    //   22	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	21	22	finally
    //   22	25	22	finally
  }
  
  /* Error */
  public Iterator<User> getUsers()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/HashMap;
    //   11: invokevirtual 20	java/util/HashMap:values	()Ljava/util/Collection;
    //   14: invokeinterface 21 1 0
    //   19: aload_1
    //   20: monitorexit
    //   21: areturn
    //   22: astore_2
    //   23: aload_1
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    // Line number table:
    //   Java source line #229	-> byte code offset #0
    //   Java source line #230	-> byte code offset #7
    //   Java source line #231	-> byte code offset #22
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	MemoryUserDatabase
    //   5	19	1	Ljava/lang/Object;	Object
    //   22	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	21	22	finally
    //   22	25	22	finally
  }
  
  public void close()
    throws Exception
  {
    save();
    synchronized (this.groups)
    {
      synchronized (this.users)
      {
        this.users.clear();
        this.groups.clear();
      }
    }
  }
  
  public Group createGroup(String groupname, String description)
  {
    if ((groupname == null) || (groupname.length() == 0))
    {
      String msg = sm.getString("memoryUserDatabase.nullGroup");
      log.warn(msg);
      throw new IllegalArgumentException(msg);
    }
    MemoryGroup group = new MemoryGroup(this, groupname, description);
    synchronized (this.groups)
    {
      this.groups.put(group.getGroupname(), group);
    }
    return group;
  }
  
  public Role createRole(String rolename, String description)
  {
    if ((rolename == null) || (rolename.length() == 0))
    {
      String msg = sm.getString("memoryUserDatabase.nullRole");
      log.warn(msg);
      throw new IllegalArgumentException(msg);
    }
    MemoryRole role = new MemoryRole(this, rolename, description);
    synchronized (this.roles)
    {
      this.roles.put(role.getRolename(), role);
    }
    return role;
  }
  
  public User createUser(String username, String password, String fullName)
  {
    if ((username == null) || (username.length() == 0))
    {
      String msg = sm.getString("memoryUserDatabase.nullUser");
      log.warn(msg);
      throw new IllegalArgumentException(msg);
    }
    MemoryUser user = new MemoryUser(this, username, password, fullName);
    synchronized (this.users)
    {
      this.users.put(user.getUsername(), user);
    }
    return user;
  }
  
  /* Error */
  public Group findGroup(String groupname)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryUserDatabase:groups	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryUserDatabase:groups	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 44	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 45	org/apache/catalina/Group
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #342	-> byte code offset #0
    //   Java source line #343	-> byte code offset #7
    //   Java source line #344	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	MemoryUserDatabase
    //   0	26	1	groupname	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  /* Error */
  public Role findRole(String rolename)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 17	org/apache/catalina/users/MemoryUserDatabase:roles	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 17	org/apache/catalina/users/MemoryUserDatabase:roles	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 44	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 46	org/apache/catalina/Role
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #358	-> byte code offset #0
    //   Java source line #359	-> byte code offset #7
    //   Java source line #360	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	MemoryUserDatabase
    //   0	26	1	rolename	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  /* Error */
  public User findUser(String username)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 44	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 47	org/apache/catalina/User
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #374	-> byte code offset #0
    //   Java source line #375	-> byte code offset #7
    //   Java source line #376	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	MemoryUserDatabase
    //   0	26	1	username	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public void open()
    throws Exception
  {
    synchronized (this.groups)
    {
      synchronized (this.users)
      {
        this.users.clear();
        this.groups.clear();
        this.roles.clear();
        
        File file = new File(this.pathname);
        if (!file.isAbsolute()) {
          file = new File(System.getProperty("catalina.base"), this.pathname);
        }
        if (!file.exists())
        {
          log.error(sm.getString("memoryUserDatabase.fileNotFound", new Object[] { file.getAbsolutePath() }));
          
          return;
        }
        Digester digester = new Digester();
        try
        {
          digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
        }
        catch (Exception e)
        {
          log.warn(sm.getString("memoryUserDatabase.xmlFeatureEncoding"), e);
        }
        digester.addFactoryCreate("tomcat-users/group", new MemoryGroupCreationFactory(this), true);
        
        digester.addFactoryCreate("tomcat-users/role", new MemoryRoleCreationFactory(this), true);
        
        digester.addFactoryCreate("tomcat-users/user", new MemoryUserCreationFactory(this), true);
        
        FileInputStream fis = null;
        try
        {
          fis = new FileInputStream(file);
          digester.parse(fis);
          if (fis != null) {
            try
            {
              fis.close();
            }
            catch (IOException ioe) {}
          }
        }
        finally
        {
          if (fis != null) {
            try
            {
              fis.close();
            }
            catch (IOException ioe) {}
          }
        }
      }
    }
  }
  
  public void removeGroup(Group group)
  {
    synchronized (this.groups)
    {
      Iterator<User> users = getUsers();
      while (users.hasNext())
      {
        User user = (User)users.next();
        user.removeGroup(group);
      }
      this.groups.remove(group.getGroupname());
    }
  }
  
  public void removeRole(Role role)
  {
    synchronized (this.roles)
    {
      Iterator<Group> groups = getGroups();
      while (groups.hasNext())
      {
        Group group = (Group)groups.next();
        group.removeRole(role);
      }
      Iterator<User> users = getUsers();
      while (users.hasNext())
      {
        User user = (User)users.next();
        user.removeRole(role);
      }
      this.roles.remove(role.getRolename());
    }
  }
  
  public void removeUser(User user)
  {
    synchronized (this.users)
    {
      this.users.remove(user.getUsername());
    }
  }
  
  public boolean isWriteable()
  {
    File file = new File(this.pathname);
    if (!file.isAbsolute()) {
      file = new File(System.getProperty("catalina.base"), this.pathname);
    }
    File dir = file.getParentFile();
    return (dir.exists()) && (dir.isDirectory()) && (dir.canWrite());
  }
  
  public void save()
    throws Exception
  {
    if (getReadonly())
    {
      log.error(sm.getString("memoryUserDatabase.readOnly"));
      return;
    }
    if (!isWriteable())
    {
      log.warn(sm.getString("memoryUserDatabase.notPersistable"));
      return;
    }
    File fileNew = new File(this.pathnameNew);
    if (!fileNew.isAbsolute()) {
      fileNew = new File(System.getProperty("catalina.base"), this.pathnameNew);
    }
    PrintWriter writer = null;
    try
    {
      FileOutputStream fos = new FileOutputStream(fileNew);
      OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF8");
      writer = new PrintWriter(osw);
      
      writer.println("<?xml version='1.0' encoding='utf-8'?>");
      writer.println("<tomcat-users>");
      
      Iterator<?> values = null;
      values = getRoles();
      while (values.hasNext())
      {
        writer.print("  ");
        writer.println(values.next());
      }
      values = getGroups();
      while (values.hasNext())
      {
        writer.print("  ");
        writer.println(values.next());
      }
      values = getUsers();
      while (values.hasNext())
      {
        writer.print("  ");
        writer.println(((MemoryUser)values.next()).toXml());
      }
      writer.println("</tomcat-users>");
      if (writer.checkError())
      {
        writer.close();
        fileNew.delete();
        throw new IOException(sm.getString("memoryUserDatabase.writeException", new Object[] { fileNew.getAbsolutePath() }));
      }
      writer.close();
    }
    catch (IOException e)
    {
      if (writer != null) {
        writer.close();
      }
      fileNew.delete();
      throw e;
    }
    File fileOld = new File(this.pathnameOld);
    if (!fileOld.isAbsolute()) {
      fileOld = new File(System.getProperty("catalina.base"), this.pathnameOld);
    }
    fileOld.delete();
    File fileOrig = new File(this.pathname);
    if (!fileOrig.isAbsolute()) {
      fileOrig = new File(System.getProperty("catalina.base"), this.pathname);
    }
    if (fileOrig.exists())
    {
      fileOld.delete();
      if (!fileOrig.renameTo(fileOld)) {
        throw new IOException(sm.getString("memoryUserDatabase.renameOld", new Object[] { fileOld.getAbsolutePath() }));
      }
    }
    if (!fileNew.renameTo(fileOrig))
    {
      if (fileOld.exists()) {
        fileOld.renameTo(fileOrig);
      }
      throw new IOException(sm.getString("memoryUserDatabase.renameNew", new Object[] { fileOrig.getAbsolutePath() }));
    }
    fileOld.delete();
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder("MemoryUserDatabase[id=");
    sb.append(this.id);
    sb.append(",pathname=");
    sb.append(this.pathname);
    sb.append(",groupCount=");
    sb.append(this.groups.size());
    sb.append(",roleCount=");
    sb.append(this.roles.size());
    sb.append(",userCount=");
    sb.append(this.users.size());
    sb.append("]");
    return sb.toString();
  }
  
  StringManager getStringManager()
  {
    return sm;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\MemoryUserDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */