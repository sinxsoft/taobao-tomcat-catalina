package org.apache.catalina.users;

import org.apache.catalina.Role;
import org.apache.catalina.UserDatabase;

public abstract class AbstractRole
  implements Role
{
  protected String description = null;
  protected String rolename = null;
  
  public AbstractRole() {}
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String description)
  {
    this.description = description;
  }
  
  public String getRolename()
  {
    return this.rolename;
  }
  
  public void setRolename(String rolename)
  {
    this.rolename = rolename;
  }
  
  public abstract UserDatabase getUserDatabase();
  
  public String getName()
  {
    return getRolename();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\AbstractRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */