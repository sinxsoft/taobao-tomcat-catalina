package org.apache.catalina.users;

import java.util.ArrayList;
import java.util.Iterator;
import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.UserDatabase;
import org.apache.catalina.util.RequestUtil;

public class MemoryUser
  extends AbstractUser
{
  MemoryUser(MemoryUserDatabase database, String username, String password, String fullName)
  {
    this.database = database;
    setUsername(username);
    setPassword(password);
    setFullName(fullName);
  }
  
  protected MemoryUserDatabase database = null;
  protected ArrayList<Group> groups = new ArrayList();
  protected ArrayList<Role> roles = new ArrayList();
  
  /* Error */
  public Iterator<Group> getGroups()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
    //   11: invokevirtual 10	java/util/ArrayList:iterator	()Ljava/util/Iterator;
    //   14: aload_1
    //   15: monitorexit
    //   16: areturn
    //   17: astore_2
    //   18: aload_1
    //   19: monitorexit
    //   20: aload_2
    //   21: athrow
    // Line number table:
    //   Java source line #94	-> byte code offset #0
    //   Java source line #95	-> byte code offset #7
    //   Java source line #96	-> byte code offset #17
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	22	0	this	MemoryUser
    //   5	14	1	Ljava/lang/Object;	Object
    //   17	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	16	17	finally
    //   17	20	17	finally
  }
  
  /* Error */
  public Iterator<Role> getRoles()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 6	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
    //   11: invokevirtual 10	java/util/ArrayList:iterator	()Ljava/util/Iterator;
    //   14: aload_1
    //   15: monitorexit
    //   16: areturn
    //   17: astore_2
    //   18: aload_1
    //   19: monitorexit
    //   20: aload_2
    //   21: athrow
    // Line number table:
    //   Java source line #107	-> byte code offset #0
    //   Java source line #108	-> byte code offset #7
    //   Java source line #109	-> byte code offset #17
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	22	0	this	MemoryUser
    //   5	14	1	Ljava/lang/Object;	Object
    //   17	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	16	17	finally
    //   17	20	17	finally
  }
  
  public UserDatabase getUserDatabase()
  {
    return this.database;
  }
  
  public void addGroup(Group group)
  {
    synchronized (this.groups)
    {
      if (!this.groups.contains(group)) {
        this.groups.add(group);
      }
    }
  }
  
  public void addRole(Role role)
  {
    synchronized (this.roles)
    {
      if (!this.roles.contains(role)) {
        this.roles.add(role);
      }
    }
  }
  
  /* Error */
  public boolean isInGroup(Group group)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryUser:groups	Ljava/util/ArrayList;
    //   11: aload_1
    //   12: invokevirtual 11	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   15: aload_2
    //   16: monitorexit
    //   17: ireturn
    //   18: astore_3
    //   19: aload_2
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Line number table:
    //   Java source line #170	-> byte code offset #0
    //   Java source line #171	-> byte code offset #7
    //   Java source line #172	-> byte code offset #18
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	23	0	this	MemoryUser
    //   0	23	1	group	Group
    //   5	15	2	Ljava/lang/Object;	Object
    //   18	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	17	18	finally
    //   18	21	18	finally
  }
  
  /* Error */
  public boolean isInRole(Role role)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 6	org/apache/catalina/users/MemoryUser:roles	Ljava/util/ArrayList;
    //   11: aload_1
    //   12: invokevirtual 11	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   15: aload_2
    //   16: monitorexit
    //   17: ireturn
    //   18: astore_3
    //   19: aload_2
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Line number table:
    //   Java source line #187	-> byte code offset #0
    //   Java source line #188	-> byte code offset #7
    //   Java source line #189	-> byte code offset #18
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	23	0	this	MemoryUser
    //   0	23	1	role	Role
    //   5	15	2	Ljava/lang/Object;	Object
    //   18	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	17	18	finally
    //   18	21	18	finally
  }
  
  public void removeGroup(Group group)
  {
    synchronized (this.groups)
    {
      this.groups.remove(group);
    }
  }
  
  public void removeGroups()
  {
    synchronized (this.groups)
    {
      this.groups.clear();
    }
  }
  
  public void removeRole(Role role)
  {
    synchronized (this.roles)
    {
      this.roles.remove(role);
    }
  }
  
  public void removeRoles()
  {
    synchronized (this.roles)
    {
      this.roles.clear();
    }
  }
  
  public String toXml()
  {
    StringBuilder sb = new StringBuilder("<user username=\"");
    sb.append(RequestUtil.filter(this.username));
    sb.append("\" password=\"");
    sb.append(RequestUtil.filter(this.password));
    sb.append("\"");
    if (this.fullName != null)
    {
      sb.append(" fullName=\"");
      sb.append(RequestUtil.filter(this.fullName));
      sb.append("\"");
    }
    synchronized (this.groups)
    {
      if (this.groups.size() > 0)
      {
        sb.append(" groups=\"");
        int n = 0;
        Iterator<Group> values = this.groups.iterator();
        while (values.hasNext())
        {
          if (n > 0) {
            sb.append(',');
          }
          n++;
          sb.append(RequestUtil.filter(((Group)values.next()).getGroupname()));
        }
        sb.append("\"");
      }
    }
    synchronized (this.roles)
    {
      if (this.roles.size() > 0)
      {
        sb.append(" roles=\"");
        int n = 0;
        Iterator<Role> values = this.roles.iterator();
        while (values.hasNext())
        {
          if (n > 0) {
            sb.append(',');
          }
          n++;
          sb.append(RequestUtil.filter(((Role)values.next()).getRolename()));
        }
        sb.append("\"");
      }
    }
    sb.append("/>");
    return sb.toString();
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder("User username=\"");
    sb.append(RequestUtil.filter(this.username));
    sb.append("\"");
    if (this.fullName != null)
    {
      sb.append(", fullName=\"");
      sb.append(RequestUtil.filter(this.fullName));
      sb.append("\"");
    }
    synchronized (this.groups)
    {
      if (this.groups.size() > 0)
      {
        sb.append(", groups=\"");
        int n = 0;
        Iterator<Group> values = this.groups.iterator();
        while (values.hasNext())
        {
          if (n > 0) {
            sb.append(',');
          }
          n++;
          sb.append(RequestUtil.filter(((Group)values.next()).getGroupname()));
        }
        sb.append("\"");
      }
    }
    synchronized (this.roles)
    {
      if (this.roles.size() > 0)
      {
        sb.append(", roles=\"");
        int n = 0;
        Iterator<Role> values = this.roles.iterator();
        while (values.hasNext())
        {
          if (n > 0) {
            sb.append(',');
          }
          n++;
          sb.append(RequestUtil.filter(((Role)values.next()).getRolename()));
        }
        sb.append("\"");
      }
    }
    return sb.toString();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\MemoryUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */