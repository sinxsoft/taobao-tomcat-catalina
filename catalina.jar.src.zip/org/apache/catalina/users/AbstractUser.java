package org.apache.catalina.users;

import java.util.Iterator;
import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.User;

public abstract class AbstractUser
  implements User
{
  protected String fullName = null;
  protected String password = null;
  protected String username = null;
  
  public AbstractUser() {}
  
  public String getFullName()
  {
    return this.fullName;
  }
  
  public void setFullName(String fullName)
  {
    this.fullName = fullName;
  }
  
  public abstract Iterator<Group> getGroups();
  
  public String getPassword()
  {
    return this.password;
  }
  
  public void setPassword(String password)
  {
    this.password = password;
  }
  
  public abstract Iterator<Role> getRoles();
  
  public String getUsername()
  {
    return this.username;
  }
  
  public void setUsername(String username)
  {
    this.username = username;
  }
  
  public abstract void addGroup(Group paramGroup);
  
  public abstract void addRole(Role paramRole);
  
  public abstract boolean isInGroup(Group paramGroup);
  
  public abstract boolean isInRole(Role paramRole);
  
  public abstract void removeGroup(Group paramGroup);
  
  public abstract void removeGroups();
  
  public abstract void removeRole(Role paramRole);
  
  public abstract void removeRoles();
  
  public String getName()
  {
    return getUsername();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\AbstractUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */