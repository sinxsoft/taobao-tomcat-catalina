package org.apache.catalina.users;

import java.util.ArrayList;
import java.util.Iterator;
import org.apache.catalina.Role;
import org.apache.catalina.User;
import org.apache.catalina.UserDatabase;

public class MemoryGroup
  extends AbstractGroup
{
  MemoryGroup(MemoryUserDatabase database, String groupname, String description)
  {
    this.database = database;
    setGroupname(groupname);
    setDescription(description);
  }
  
  protected MemoryUserDatabase database = null;
  protected ArrayList<Role> roles = new ArrayList();
  
  /* Error */
  public Iterator<Role> getRoles()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
    //   11: invokevirtual 8	java/util/ArrayList:iterator	()Ljava/util/Iterator;
    //   14: aload_1
    //   15: monitorexit
    //   16: areturn
    //   17: astore_2
    //   18: aload_1
    //   19: monitorexit
    //   20: aload_2
    //   21: athrow
    // Line number table:
    //   Java source line #86	-> byte code offset #0
    //   Java source line #87	-> byte code offset #7
    //   Java source line #88	-> byte code offset #17
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	22	0	this	MemoryGroup
    //   5	14	1	Ljava/lang/Object;	Object
    //   17	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	16	17	finally
    //   17	20	17	finally
  }
  
  public UserDatabase getUserDatabase()
  {
    return this.database;
  }
  
  public Iterator<User> getUsers()
  {
    ArrayList<User> results = new ArrayList();
    Iterator<User> users = this.database.getUsers();
    while (users.hasNext())
    {
      User user = (User)users.next();
      if (user.isInGroup(this)) {
        results.add(user);
      }
    }
    return results.iterator();
  }
  
  public void addRole(Role role)
  {
    synchronized (this.roles)
    {
      if (!this.roles.contains(role)) {
        this.roles.add(role);
      }
    }
  }
  
  /* Error */
  public boolean isInRole(Role role)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 5	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 5	org/apache/catalina/users/MemoryGroup:roles	Ljava/util/ArrayList;
    //   11: aload_1
    //   12: invokevirtual 15	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   15: aload_2
    //   16: monitorexit
    //   17: ireturn
    //   18: astore_3
    //   19: aload_2
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Line number table:
    //   Java source line #151	-> byte code offset #0
    //   Java source line #152	-> byte code offset #7
    //   Java source line #153	-> byte code offset #18
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	23	0	this	MemoryGroup
    //   0	23	1	role	Role
    //   5	15	2	Ljava/lang/Object;	Object
    //   18	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	17	18	finally
    //   18	21	18	finally
  }
  
  public void removeRole(Role role)
  {
    synchronized (this.roles)
    {
      this.roles.remove(role);
    }
  }
  
  public void removeRoles()
  {
    synchronized (this.roles)
    {
      this.roles.clear();
    }
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder("<group groupname=\"");
    sb.append(this.groupname);
    sb.append("\"");
    if (this.description != null)
    {
      sb.append(" description=\"");
      sb.append(this.description);
      sb.append("\"");
    }
    synchronized (this.roles)
    {
      if (this.roles.size() > 0)
      {
        sb.append(" roles=\"");
        int n = 0;
        Iterator<Role> values = this.roles.iterator();
        while (values.hasNext())
        {
          if (n > 0) {
            sb.append(',');
          }
          n++;
          sb.append(((Role)values.next()).getRolename());
        }
        sb.append("\"");
      }
    }
    sb.append("/>");
    return sb.toString();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\MemoryGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */