package org.apache.catalina.users;

import org.apache.catalina.UserDatabase;

public class MemoryRole
  extends AbstractRole
{
  MemoryRole(MemoryUserDatabase database, String rolename, String description)
  {
    this.database = database;
    setRolename(rolename);
    setDescription(description);
  }
  
  protected MemoryUserDatabase database = null;
  
  public UserDatabase getUserDatabase()
  {
    return this.database;
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder("<role rolename=\"");
    sb.append(this.rolename);
    sb.append("\"");
    if (this.description != null)
    {
      sb.append(" description=\"");
      sb.append(this.description);
      sb.append("\"");
    }
    sb.append("/>");
    return sb.toString();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\MemoryRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */