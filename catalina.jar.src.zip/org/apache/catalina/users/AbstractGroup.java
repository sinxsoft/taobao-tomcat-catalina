package org.apache.catalina.users;

import java.util.Iterator;
import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.User;
import org.apache.catalina.UserDatabase;

public abstract class AbstractGroup
  implements Group
{
  protected String description = null;
  protected String groupname = null;
  
  public AbstractGroup() {}
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String description)
  {
    this.description = description;
  }
  
  public String getGroupname()
  {
    return this.groupname;
  }
  
  public void setGroupname(String groupname)
  {
    this.groupname = groupname;
  }
  
  public abstract Iterator<Role> getRoles();
  
  public abstract UserDatabase getUserDatabase();
  
  public abstract Iterator<User> getUsers();
  
  public abstract void addRole(Role paramRole);
  
  public abstract boolean isInRole(Role paramRole);
  
  public abstract void removeRole(Role paramRole);
  
  public abstract void removeRoles();
  
  public String getName()
  {
    return getGroupname();
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\users\AbstractGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */