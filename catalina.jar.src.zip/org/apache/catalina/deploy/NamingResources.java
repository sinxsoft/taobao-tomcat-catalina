package org.apache.catalina.deploy;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.naming.NamingException;
import org.apache.catalina.Container;
import org.apache.catalina.Engine;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Server;
import org.apache.catalina.Service;
import org.apache.catalina.mbeans.MBeanUtils;
import org.apache.catalina.util.Introspection;
import org.apache.catalina.util.LifecycleMBeanBase;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.naming.ContextBindings;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

public class NamingResources
  extends LifecycleMBeanBase
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private static final Log log = LogFactory.getLog(NamingResources.class);
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.deploy");
  private volatile boolean resourceRequireExplicitRegistration = false;
  private Object container = null;
  private Set<String> entries = new HashSet();
  private HashMap<String, ContextEjb> ejbs = new HashMap();
  private HashMap<String, ContextEnvironment> envs = new HashMap();
  private HashMap<String, ContextLocalEjb> localEjbs = new HashMap();
  private HashMap<String, MessageDestinationRef> mdrs = new HashMap();
  private HashMap<String, ContextResourceEnvRef> resourceEnvRefs = new HashMap();
  private HashMap<String, ContextResource> resources = new HashMap();
  private HashMap<String, ContextResourceLink> resourceLinks = new HashMap();
  private HashMap<String, ContextService> services = new HashMap();
  private ContextTransaction transaction = null;
  protected PropertyChangeSupport support = new PropertyChangeSupport(this);
  
  public NamingResources() {}
  
  public Object getContainer()
  {
    return this.container;
  }
  
  public void setContainer(Object container)
  {
    this.container = container;
  }
  
  public void setTransaction(ContextTransaction transaction)
  {
    this.transaction = transaction;
  }
  
  public ContextTransaction getTransaction()
  {
    return this.transaction;
  }
  
  public void addEjb(ContextEjb ejb)
  {
    if (this.entries.contains(ejb.getName())) {
      return;
    }
    this.entries.add(ejb.getName());
    synchronized (this.ejbs)
    {
      ejb.setNamingResources(this);
      this.ejbs.put(ejb.getName(), ejb);
    }
    this.support.firePropertyChange("ejb", null, ejb);
  }
  
  public void addEnvironment(ContextEnvironment environment)
  {
    if (this.entries.contains(environment.getName()))
    {
      ContextEnvironment ce = findEnvironment(environment.getName());
      ContextResourceLink rl = findResourceLink(environment.getName());
      if (ce != null)
      {
        if (ce.getOverride()) {
          removeEnvironment(environment.getName());
        }
      }
      else if (rl != null)
      {
        NamingResources global = getServer().getGlobalNamingResources();
        if (global.findEnvironment(rl.getGlobal()) != null) {
          if (global.findEnvironment(rl.getGlobal()).getOverride()) {
            removeResourceLink(environment.getName());
          } else {
            return;
          }
        }
      }
      else
      {
        return;
      }
    }
    if (!checkResourceType(environment)) {
      throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] { environment.getName(), environment.getType() }));
    }
    this.entries.add(environment.getName());
    synchronized (this.envs)
    {
      environment.setNamingResources(this);
      this.envs.put(environment.getName(), environment);
    }
    this.support.firePropertyChange("environment", null, environment);
    if (this.resourceRequireExplicitRegistration) {
      try
      {
        MBeanUtils.createMBean(environment);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { environment.getName() }), e);
      }
    }
  }
  
  private Server getServer()
  {
    if ((this.container instanceof Server)) {
      return (Server)this.container;
    }
    if ((this.container instanceof org.apache.catalina.Context))
    {
      Engine engine = (Engine)((org.apache.catalina.Context)this.container).getParent().getParent();
      
      return engine.getService().getServer();
    }
    return null;
  }
  
  public void addLocalEjb(ContextLocalEjb ejb)
  {
    if (this.entries.contains(ejb.getName())) {
      return;
    }
    this.entries.add(ejb.getName());
    synchronized (this.localEjbs)
    {
      ejb.setNamingResources(this);
      this.localEjbs.put(ejb.getName(), ejb);
    }
    this.support.firePropertyChange("localEjb", null, ejb);
  }
  
  public void addMessageDestinationRef(MessageDestinationRef mdr)
  {
    if (this.entries.contains(mdr.getName())) {
      return;
    }
    if (!checkResourceType(mdr)) {
      throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] { mdr.getName(), mdr.getType() }));
    }
    this.entries.add(mdr.getName());
    synchronized (this.mdrs)
    {
      mdr.setNamingResources(this);
      this.mdrs.put(mdr.getName(), mdr);
    }
    this.support.firePropertyChange("messageDestinationRef", null, mdr);
  }
  
  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    this.support.addPropertyChangeListener(listener);
  }
  
  public void addResource(ContextResource resource)
  {
    if (this.entries.contains(resource.getName())) {
      return;
    }
    if (!checkResourceType(resource)) {
      throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] { resource.getName(), resource.getType() }));
    }
    this.entries.add(resource.getName());
    synchronized (this.resources)
    {
      resource.setNamingResources(this);
      this.resources.put(resource.getName(), resource);
    }
    this.support.firePropertyChange("resource", null, resource);
    if (this.resourceRequireExplicitRegistration) {
      try
      {
        MBeanUtils.createMBean(resource);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { resource.getName() }), e);
      }
    }
  }
  
  public void addResourceEnvRef(ContextResourceEnvRef resource)
  {
    if (this.entries.contains(resource.getName())) {
      return;
    }
    if (!checkResourceType(resource)) {
      throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] { resource.getName(), resource.getType() }));
    }
    this.entries.add(resource.getName());
    synchronized (this.resourceEnvRefs)
    {
      resource.setNamingResources(this);
      this.resourceEnvRefs.put(resource.getName(), resource);
    }
    this.support.firePropertyChange("resourceEnvRef", null, resource);
  }
  
  public void addResourceLink(ContextResourceLink resourceLink)
  {
    if (this.entries.contains(resourceLink.getName())) {
      return;
    }
    this.entries.add(resourceLink.getName());
    synchronized (this.resourceLinks)
    {
      resourceLink.setNamingResources(this);
      this.resourceLinks.put(resourceLink.getName(), resourceLink);
    }
    this.support.firePropertyChange("resourceLink", null, resourceLink);
    if (this.resourceRequireExplicitRegistration) {
      try
      {
        MBeanUtils.createMBean(resourceLink);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { resourceLink.getName() }), e);
      }
    }
  }
  
  public void addService(ContextService service)
  {
    if (this.entries.contains(service.getName())) {
      return;
    }
    this.entries.add(service.getName());
    synchronized (this.services)
    {
      service.setNamingResources(this);
      this.services.put(service.getName(), service);
    }
    this.support.firePropertyChange("service", null, service);
  }
  
  /* Error */
  public ContextEjb findEjb(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 9	org/apache/catalina/deploy/NamingResources:ejbs	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 9	org/apache/catalina/deploy/NamingResources:ejbs	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 84	org/apache/catalina/deploy/ContextEjb
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #475	-> byte code offset #0
    //   Java source line #476	-> byte code offset #7
    //   Java source line #477	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextEjb[] findEjbs()
  {
    synchronized (this.ejbs)
    {
      ContextEjb[] results = new ContextEjb[this.ejbs.size()];
      return (ContextEjb[])this.ejbs.values().toArray(results);
    }
  }
  
  /* Error */
  public ContextEnvironment findEnvironment(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 10	org/apache/catalina/deploy/NamingResources:envs	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 10	org/apache/catalina/deploy/NamingResources:envs	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 89	org/apache/catalina/deploy/ContextEnvironment
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #504	-> byte code offset #0
    //   Java source line #505	-> byte code offset #7
    //   Java source line #506	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextEnvironment[] findEnvironments()
  {
    synchronized (this.envs)
    {
      ContextEnvironment[] results = new ContextEnvironment[this.envs.size()];
      return (ContextEnvironment[])this.envs.values().toArray(results);
    }
  }
  
  /* Error */
  public ContextLocalEjb findLocalEjb(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 11	org/apache/catalina/deploy/NamingResources:localEjbs	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 11	org/apache/catalina/deploy/NamingResources:localEjbs	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 91	org/apache/catalina/deploy/ContextLocalEjb
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #534	-> byte code offset #0
    //   Java source line #535	-> byte code offset #7
    //   Java source line #536	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextLocalEjb[] findLocalEjbs()
  {
    synchronized (this.localEjbs)
    {
      ContextLocalEjb[] results = new ContextLocalEjb[this.localEjbs.size()];
      return (ContextLocalEjb[])this.localEjbs.values().toArray(results);
    }
  }
  
  /* Error */
  public MessageDestinationRef findMessageDestinationRef(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 12	org/apache/catalina/deploy/NamingResources:mdrs	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 12	org/apache/catalina/deploy/NamingResources:mdrs	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 93	org/apache/catalina/deploy/MessageDestinationRef
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #563	-> byte code offset #0
    //   Java source line #564	-> byte code offset #7
    //   Java source line #565	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public MessageDestinationRef[] findMessageDestinationRefs()
  {
    synchronized (this.mdrs)
    {
      MessageDestinationRef[] results = new MessageDestinationRef[this.mdrs.size()];
      
      return (MessageDestinationRef[])this.mdrs.values().toArray(results);
    }
  }
  
  /* Error */
  public ContextResource findResource(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 14	org/apache/catalina/deploy/NamingResources:resources	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 14	org/apache/catalina/deploy/NamingResources:resources	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 95	org/apache/catalina/deploy/ContextResource
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #593	-> byte code offset #0
    //   Java source line #594	-> byte code offset #7
    //   Java source line #595	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  /* Error */
  public ContextResourceLink findResourceLink(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 15	org/apache/catalina/deploy/NamingResources:resourceLinks	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 15	org/apache/catalina/deploy/NamingResources:resourceLinks	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 96	org/apache/catalina/deploy/ContextResourceLink
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #608	-> byte code offset #0
    //   Java source line #609	-> byte code offset #7
    //   Java source line #610	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextResourceLink[] findResourceLinks()
  {
    synchronized (this.resourceLinks)
    {
      ContextResourceLink[] results = new ContextResourceLink[this.resourceLinks.size()];
      
      return (ContextResourceLink[])this.resourceLinks.values().toArray(results);
    }
  }
  
  public ContextResource[] findResources()
  {
    synchronized (this.resources)
    {
      ContextResource[] results = new ContextResource[this.resources.size()];
      return (ContextResource[])this.resources.values().toArray(results);
    }
  }
  
  /* Error */
  public ContextResourceEnvRef findResourceEnvRef(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 13	org/apache/catalina/deploy/NamingResources:resourceEnvRefs	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 13	org/apache/catalina/deploy/NamingResources:resourceEnvRefs	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 99	org/apache/catalina/deploy/ContextResourceEnvRef
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #652	-> byte code offset #0
    //   Java source line #653	-> byte code offset #7
    //   Java source line #654	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextResourceEnvRef[] findResourceEnvRefs()
  {
    synchronized (this.resourceEnvRefs)
    {
      ContextResourceEnvRef[] results = new ContextResourceEnvRef[this.resourceEnvRefs.size()];
      return (ContextResourceEnvRef[])this.resourceEnvRefs.values().toArray(results);
    }
  }
  
  /* Error */
  public ContextService findService(String name)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	org/apache/catalina/deploy/NamingResources:services	Ljava/util/HashMap;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 16	org/apache/catalina/deploy/NamingResources:services	Ljava/util/HashMap;
    //   11: aload_1
    //   12: invokevirtual 83	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast 101	org/apache/catalina/deploy/ContextService
    //   18: aload_2
    //   19: monitorexit
    //   20: areturn
    //   21: astore_3
    //   22: aload_2
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Line number table:
    //   Java source line #682	-> byte code offset #0
    //   Java source line #683	-> byte code offset #7
    //   Java source line #684	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	NamingResources
    //   0	26	1	name	String
    //   5	18	2	Ljava/lang/Object;	Object
    //   21	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  public ContextService[] findServices()
  {
    synchronized (this.services)
    {
      ContextService[] results = new ContextService[this.services.size()];
      return (ContextService[])this.services.values().toArray(results);
    }
  }
  
  @Deprecated
  public boolean exists(String name)
  {
    return this.entries.contains(name);
  }
  
  public void removeEjb(String name)
  {
    this.entries.remove(name);
    
    ContextEjb ejb = null;
    synchronized (this.ejbs)
    {
      ejb = (ContextEjb)this.ejbs.remove(name);
    }
    if (ejb != null)
    {
      this.support.firePropertyChange("ejb", ejb, null);
      ejb.setNamingResources(null);
    }
  }
  
  public void removeEnvironment(String name)
  {
    this.entries.remove(name);
    
    ContextEnvironment environment = null;
    synchronized (this.envs)
    {
      environment = (ContextEnvironment)this.envs.remove(name);
    }
    if (environment != null)
    {
      this.support.firePropertyChange("environment", environment, null);
      if (this.resourceRequireExplicitRegistration) {
        try
        {
          MBeanUtils.destroyMBean(environment);
        }
        catch (Exception e)
        {
          log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { environment.getName() }), e);
        }
      }
      environment.setNamingResources(null);
    }
  }
  
  public void removeLocalEjb(String name)
  {
    this.entries.remove(name);
    
    ContextLocalEjb localEjb = null;
    synchronized (this.localEjbs)
    {
      localEjb = (ContextLocalEjb)this.localEjbs.remove(name);
    }
    if (localEjb != null)
    {
      this.support.firePropertyChange("localEjb", localEjb, null);
      localEjb.setNamingResources(null);
    }
  }
  
  public void removeMessageDestinationRef(String name)
  {
    this.entries.remove(name);
    
    MessageDestinationRef mdr = null;
    synchronized (this.mdrs)
    {
      mdr = (MessageDestinationRef)this.mdrs.remove(name);
    }
    if (mdr != null)
    {
      this.support.firePropertyChange("messageDestinationRef", mdr, null);
      
      mdr.setNamingResources(null);
    }
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    this.support.removePropertyChangeListener(listener);
  }
  
  public void removeResource(String name)
  {
    this.entries.remove(name);
    
    ContextResource resource = null;
    synchronized (this.resources)
    {
      resource = (ContextResource)this.resources.remove(name);
    }
    if (resource != null)
    {
      this.support.firePropertyChange("resource", resource, null);
      if (this.resourceRequireExplicitRegistration) {
        try
        {
          MBeanUtils.destroyMBean(resource);
        }
        catch (Exception e)
        {
          log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { resource.getName() }), e);
        }
      }
      resource.setNamingResources(null);
    }
  }
  
  public void removeResourceEnvRef(String name)
  {
    this.entries.remove(name);
    
    ContextResourceEnvRef resourceEnvRef = null;
    synchronized (this.resourceEnvRefs)
    {
      resourceEnvRef = (ContextResourceEnvRef)this.resourceEnvRefs.remove(name);
    }
    if (resourceEnvRef != null)
    {
      this.support.firePropertyChange("resourceEnvRef", resourceEnvRef, null);
      resourceEnvRef.setNamingResources(null);
    }
  }
  
  public void removeResourceLink(String name)
  {
    this.entries.remove(name);
    
    ContextResourceLink resourceLink = null;
    synchronized (this.resourceLinks)
    {
      resourceLink = (ContextResourceLink)this.resourceLinks.remove(name);
    }
    if (resourceLink != null)
    {
      this.support.firePropertyChange("resourceLink", resourceLink, null);
      if (this.resourceRequireExplicitRegistration) {
        try
        {
          MBeanUtils.destroyMBean(resourceLink);
        }
        catch (Exception e)
        {
          log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { resourceLink.getName() }), e);
        }
      }
      resourceLink.setNamingResources(null);
    }
  }
  
  public void removeService(String name)
  {
    this.entries.remove(name);
    
    ContextService service = null;
    synchronized (this.services)
    {
      service = (ContextService)this.services.remove(name);
    }
    if (service != null)
    {
      this.support.firePropertyChange("service", service, null);
      service.setNamingResources(null);
    }
  }
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    
    this.resourceRequireExplicitRegistration = true;
    for (ContextResource cr : this.resources.values()) {
      try
      {
        MBeanUtils.createMBean(cr);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { cr.getName() }), e);
      }
    }
    for (ContextEnvironment ce : this.envs.values()) {
      try
      {
        MBeanUtils.createMBean(ce);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { ce.getName() }), e);
      }
    }
    for (ContextResourceLink crl : this.resourceLinks.values()) {
      try
      {
        MBeanUtils.createMBean(crl);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] { crl.getName() }), e);
      }
    }
  }
  
  protected void startInternal()
    throws LifecycleException
  {
    fireLifecycleEvent("configure_start", null);
    setState(LifecycleState.STARTING);
  }
  
  protected void stopInternal()
    throws LifecycleException
  {
    cleanUp();
    setState(LifecycleState.STOPPING);
    fireLifecycleEvent("configure_stop", null);
  }
  
  private void cleanUp()
  {
    if (this.resources.size() == 0) {
      return;
    }
    javax.naming.Context ctxt;
    try
    {
      javax.naming.Context ctxt;
      if ((this.container instanceof Server))
      {
        ctxt = ((Server)this.container).getGlobalNamingContext();
      }
      else
      {
        ctxt = ContextBindings.getClassLoader();
        ctxt = (javax.naming.Context)ctxt.lookup("comp/env");
      }
    }
    catch (NamingException e)
    {
      log.warn(sm.getString("namingResources.cleanupNoContext", new Object[] { this.container }), e);
      
      return;
    }
    for (ContextResource cr : this.resources.values()) {
      if (cr.getSingleton())
      {
        String closeMethod = cr.getCloseMethod();
        if ((closeMethod != null) && (closeMethod.length() > 0))
        {
          String name = cr.getName();
          Object resource;
          try
          {
            resource = ctxt.lookup(name);
          }
          catch (NamingException e)
          {
            log.warn(sm.getString("namingResources.cleanupNoResource", new Object[] { cr.getName(), this.container }), e);
          }
          continue;
          
          cleanUp(resource, name, closeMethod);
        }
      }
    }
  }
  
  private void cleanUp(Object resource, String name, String closeMethod)
  {
    Method m = null;
    try
    {
      m = resource.getClass().getMethod(closeMethod, (Class[])null);
    }
    catch (SecurityException e)
    {
      log.debug(sm.getString("namingResources.cleanupCloseSecurity", new Object[] { closeMethod, name, this.container }));
      
      return;
    }
    catch (NoSuchMethodException e)
    {
      log.debug(sm.getString("namingResources.cleanupNoClose", new Object[] { name, this.container, closeMethod }));
      
      return;
    }
    if (m != null) {
      try
      {
        m.invoke(resource, (Object[])null);
      }
      catch (IllegalArgumentException e)
      {
        log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), e);
      }
      catch (IllegalAccessException e)
      {
        log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), e);
      }
      catch (InvocationTargetException e)
      {
        Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
        ExceptionUtils.handleThrowable(t);
        log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), t);
      }
    }
  }
  
  protected void destroyInternal()
    throws LifecycleException
  {
    this.resourceRequireExplicitRegistration = false;
    for (ContextResourceLink crl : this.resourceLinks.values()) {
      try
      {
        MBeanUtils.destroyMBean(crl);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { crl.getName() }), e);
      }
    }
    for (ContextEnvironment ce : this.envs.values()) {
      try
      {
        MBeanUtils.destroyMBean(ce);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { ce.getName() }), e);
      }
    }
    for (ContextResource cr : this.resources.values()) {
      try
      {
        MBeanUtils.destroyMBean(cr);
      }
      catch (Exception e)
      {
        log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] { cr.getName() }), e);
      }
    }
    super.destroyInternal();
  }
  
  protected String getDomainInternal()
  {
    Object c = getContainer();
    if ((c instanceof LifecycleMBeanBase)) {
      return ((LifecycleMBeanBase)c).getDomain();
    }
    return null;
  }
  
  protected String getObjectNameKeyProperties()
  {
    Object c = getContainer();
    if ((c instanceof Container)) {
      return "type=NamingResources" + MBeanUtils.getContainerKeyProperties((Container)c);
    }
    return "type=NamingResources";
  }
  
  private boolean checkResourceType(ResourceBase resource)
  {
    if (!(this.container instanceof org.apache.catalina.Context)) {
      return true;
    }
    if ((resource.getInjectionTargets() == null) || (resource.getInjectionTargets().size() == 0)) {
      return true;
    }
    org.apache.catalina.Context context = (org.apache.catalina.Context)this.container;
    
    String typeName = resource.getType();
    Class<?> typeClass = null;
    if (typeName != null)
    {
      typeClass = Introspection.loadClass(context, typeName);
      if (typeClass == null) {
        return true;
      }
    }
    Class<?> compatibleClass = getCompatibleType(context, resource, typeClass);
    if (compatibleClass == null) {
      return false;
    }
    resource.setType(compatibleClass.getCanonicalName());
    return true;
  }
  
  private Class<?> getCompatibleType(org.apache.catalina.Context context, ResourceBase resource, Class<?> typeClass)
  {
    Class<?> result = null;
    for (InjectionTarget injectionTarget : resource.getInjectionTargets())
    {
      Class<?> clazz = Introspection.loadClass(context, injectionTarget.getTargetClass());
      if (clazz != null)
      {
        String targetName = injectionTarget.getTargetName();
        
        Class<?> targetType = getSetterType(clazz, targetName);
        if (targetType == null) {
          targetType = getFieldType(clazz, targetName);
        }
        if (targetType != null)
        {
          targetType = Introspection.convertPrimitiveType(targetType);
          if (typeClass == null)
          {
            if (result == null) {
              result = targetType;
            } else if (!targetType.isAssignableFrom(result)) {
              if (result.isAssignableFrom(targetType)) {
                result = targetType;
              } else {
                return null;
              }
            }
          }
          else if (targetType.isAssignableFrom(typeClass)) {
            result = typeClass;
          } else {
            return null;
          }
        }
      }
    }
    return result;
  }
  
  private Class<?> getSetterType(Class<?> clazz, String name)
  {
    Method[] methods = Introspection.getDeclaredMethods(clazz);
    if ((methods != null) && (methods.length > 0)) {
      for (Method method : methods) {
        if ((Introspection.isValidSetter(method)) && (Introspection.getPropertyName(method).equals(name))) {
          return method.getParameterTypes()[0];
        }
      }
    }
    return null;
  }
  
  private Class<?> getFieldType(Class<?> clazz, String name)
  {
    Field[] fields = Introspection.getDeclaredFields(clazz);
    if ((fields != null) && (fields.length > 0)) {
      for (Field field : fields) {
        if (field.getName().equals(name)) {
          return field.getType();
        }
      }
    }
    return null;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\deploy\NamingResources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */