package org.apache.catalina.deploy;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.DispatcherType;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.SessionCookieConfig;
import javax.servlet.SessionTrackingMode;
import javax.servlet.descriptor.JspConfigDescriptor;
import javax.servlet.descriptor.JspPropertyGroupDescriptor;
import javax.servlet.descriptor.TaglibDescriptor;
import org.apache.catalina.Context;
import org.apache.catalina.Wrapper;
import org.apache.catalina.core.ApplicationJspPropertyGroupDescriptor;
import org.apache.catalina.core.ApplicationTaglibDescriptor;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

public class WebXml
{
  protected static final String ORDER_OTHERS = "org.apache.catalina.order.others";
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.deploy");
  private static final Log log = LogFactory.getLog(WebXml.class);
  private boolean overridable = false;
  
  public WebXml() {}
  
  public boolean isOverridable()
  {
    return this.overridable;
  }
  
  public void setOverridable(boolean overridable)
  {
    this.overridable = overridable;
  }
  
  private Set<String> absoluteOrdering = null;
  
  public void createAbsoluteOrdering()
  {
    if (this.absoluteOrdering == null) {
      this.absoluteOrdering = new LinkedHashSet();
    }
  }
  
  public void addAbsoluteOrdering(String fragmentName)
  {
    createAbsoluteOrdering();
    this.absoluteOrdering.add(fragmentName);
  }
  
  public void addAbsoluteOrderingOthers()
  {
    createAbsoluteOrdering();
    this.absoluteOrdering.add("org.apache.catalina.order.others");
  }
  
  public Set<String> getAbsoluteOrdering()
  {
    return this.absoluteOrdering;
  }
  
  private Set<String> after = new LinkedHashSet();
  
  public void addAfterOrdering(String fragmentName)
  {
    this.after.add(fragmentName);
  }
  
  public void addAfterOrderingOthers()
  {
    if (this.before.contains("org.apache.catalina.order.others")) {
      throw new IllegalArgumentException(sm.getString("webXml.multipleOther"));
    }
    this.after.add("org.apache.catalina.order.others");
  }
  
  public Set<String> getAfterOrdering()
  {
    return this.after;
  }
  
  private Set<String> before = new LinkedHashSet();
  
  public void addBeforeOrdering(String fragmentName)
  {
    this.before.add(fragmentName);
  }
  
  public void addBeforeOrderingOthers()
  {
    if (this.after.contains("org.apache.catalina.order.others")) {
      throw new IllegalArgumentException(sm.getString("webXml.multipleOther"));
    }
    this.before.add("org.apache.catalina.order.others");
  }
  
  public Set<String> getBeforeOrdering()
  {
    return this.before;
  }
  
  public String getVersion()
  {
    StringBuilder sb = new StringBuilder(3);
    sb.append(this.majorVersion);
    sb.append('.');
    sb.append(this.minorVersion);
    return sb.toString();
  }
  
  public void setVersion(String version)
  {
    if (version == null) {
      return;
    }
    if ("2.4".equals(version))
    {
      this.majorVersion = 2;
      this.minorVersion = 4;
    }
    else if ("2.5".equals(version))
    {
      this.majorVersion = 2;
      this.minorVersion = 5;
    }
    else if ("3.0".equals(version))
    {
      this.majorVersion = 3;
      this.minorVersion = 0;
    }
    else
    {
      log.warn(sm.getString("webXml.version.unknown", new Object[] { version }));
    }
  }
  
  private String publicId = null;
  
  public String getPublicId()
  {
    return this.publicId;
  }
  
  public void setPublicId(String publicId)
  {
    if (publicId == null) {
      return;
    }
    if ("-//Sun Microsystems, Inc.//DTD Web Application 2.2//EN".equals(publicId))
    {
      this.majorVersion = 2;
      this.minorVersion = 2;
      this.publicId = publicId;
    }
    else if ("-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN".equals(publicId))
    {
      this.majorVersion = 2;
      this.minorVersion = 3;
      this.publicId = publicId;
    }
    else
    {
      log.warn(sm.getString("webXml.unrecognisedPublicId", new Object[] { publicId }));
    }
  }
  
  private boolean metadataComplete = false;
  
  public boolean isMetadataComplete()
  {
    return this.metadataComplete;
  }
  
  public void setMetadataComplete(boolean metadataComplete)
  {
    this.metadataComplete = metadataComplete;
  }
  
  private String name = null;
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    if ("org.apache.catalina.order.others".equalsIgnoreCase(name)) {
      log.warn(sm.getString("webXml.reservedName", new Object[] { name }));
    } else {
      this.name = name;
    }
  }
  
  private int majorVersion = 3;
  private int minorVersion = 0;
  
  public int getMajorVersion()
  {
    return this.majorVersion;
  }
  
  public int getMinorVersion()
  {
    return this.minorVersion;
  }
  
  private String displayName = null;
  
  public String getDisplayName()
  {
    return this.displayName;
  }
  
  public void setDisplayName(String displayName)
  {
    this.displayName = displayName;
  }
  
  private boolean distributable = false;
  
  public boolean isDistributable()
  {
    return this.distributable;
  }
  
  public void setDistributable(boolean distributable)
  {
    this.distributable = distributable;
  }
  
  private Map<String, String> contextParams = new HashMap();
  
  public void addContextParam(String param, String value)
  {
    this.contextParams.put(param, value);
  }
  
  public Map<String, String> getContextParams()
  {
    return this.contextParams;
  }
  
  private Map<String, FilterDef> filters = new LinkedHashMap();
  
  public void addFilter(FilterDef filter)
  {
    if (this.filters.containsKey(filter.getFilterName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateFilter", new Object[] { filter.getFilterName() }));
    }
    this.filters.put(filter.getFilterName(), filter);
  }
  
  public Map<String, FilterDef> getFilters()
  {
    return this.filters;
  }
  
  private Set<FilterMap> filterMaps = new LinkedHashSet();
  private Set<String> filterMappingNames = new HashSet();
  
  public void addFilterMapping(FilterMap filterMap)
  {
    this.filterMaps.add(filterMap);
    this.filterMappingNames.add(filterMap.getFilterName());
  }
  
  public Set<FilterMap> getFilterMappings()
  {
    return this.filterMaps;
  }
  
  private Set<String> listeners = new LinkedHashSet();
  
  public void addListener(String className)
  {
    this.listeners.add(className);
  }
  
  public Set<String> getListeners()
  {
    return this.listeners;
  }
  
  private Map<String, ServletDef> servlets = new HashMap();
  
  public void addServlet(ServletDef servletDef)
  {
    this.servlets.put(servletDef.getServletName(), servletDef);
    if (this.overridable) {
      servletDef.setOverridable(this.overridable);
    }
  }
  
  public Map<String, ServletDef> getServlets()
  {
    return this.servlets;
  }
  
  private Map<String, String> servletMappings = new HashMap();
  private Set<String> servletMappingNames = new HashSet();
  
  public void addServletMapping(String urlPattern, String servletName)
  {
    String oldServletName = (String)this.servletMappings.put(urlPattern, servletName);
    if (oldServletName != null) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateServletMapping", new Object[] { oldServletName, servletName, urlPattern }));
    }
    this.servletMappingNames.add(servletName);
  }
  
  public Map<String, String> getServletMappings()
  {
    return this.servletMappings;
  }
  
  private SessionConfig sessionConfig = new SessionConfig();
  
  public void setSessionConfig(SessionConfig sessionConfig)
  {
    this.sessionConfig = sessionConfig;
  }
  
  public SessionConfig getSessionConfig()
  {
    return this.sessionConfig;
  }
  
  private Map<String, String> mimeMappings = new HashMap();
  
  public void addMimeMapping(String extension, String mimeType)
  {
    this.mimeMappings.put(extension, mimeType);
  }
  
  public Map<String, String> getMimeMappings()
  {
    return this.mimeMappings;
  }
  
  private boolean replaceWelcomeFiles = false;
  private boolean alwaysAddWelcomeFiles = true;
  
  public void setReplaceWelcomeFiles(boolean replaceWelcomeFiles)
  {
    this.replaceWelcomeFiles = replaceWelcomeFiles;
  }
  
  public void setAlwaysAddWelcomeFiles(boolean alwaysAddWelcomeFiles)
  {
    this.alwaysAddWelcomeFiles = alwaysAddWelcomeFiles;
  }
  
  private Set<String> welcomeFiles = new LinkedHashSet();
  
  public void addWelcomeFile(String welcomeFile)
  {
    if (this.replaceWelcomeFiles)
    {
      this.welcomeFiles.clear();
      this.replaceWelcomeFiles = false;
    }
    this.welcomeFiles.add(welcomeFile);
  }
  
  public Set<String> getWelcomeFiles()
  {
    return this.welcomeFiles;
  }
  
  private Map<String, ErrorPage> errorPages = new HashMap();
  
  public void addErrorPage(ErrorPage errorPage)
  {
    this.errorPages.put(errorPage.getName(), errorPage);
  }
  
  public Map<String, ErrorPage> getErrorPages()
  {
    return this.errorPages;
  }
  
  private Map<String, String> taglibs = new HashMap();
  
  public void addTaglib(String uri, String location)
  {
    if (this.taglibs.containsKey(uri)) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateTaglibUri", new Object[] { uri }));
    }
    this.taglibs.put(uri, location);
  }
  
  public Map<String, String> getTaglibs()
  {
    return this.taglibs;
  }
  
  private Set<JspPropertyGroup> jspPropertyGroups = new LinkedHashSet();
  
  public void addJspPropertyGroup(JspPropertyGroup propertyGroup)
  {
    this.jspPropertyGroups.add(propertyGroup);
  }
  
  public Set<JspPropertyGroup> getJspPropertyGroups()
  {
    return this.jspPropertyGroups;
  }
  
  private Set<SecurityConstraint> securityConstraints = new HashSet();
  
  public void addSecurityConstraint(SecurityConstraint securityConstraint)
  {
    this.securityConstraints.add(securityConstraint);
  }
  
  public Set<SecurityConstraint> getSecurityConstraints()
  {
    return this.securityConstraints;
  }
  
  private LoginConfig loginConfig = null;
  
  public void setLoginConfig(LoginConfig loginConfig)
  {
    this.loginConfig = loginConfig;
  }
  
  public LoginConfig getLoginConfig()
  {
    return this.loginConfig;
  }
  
  private Set<String> securityRoles = new HashSet();
  
  public void addSecurityRole(String securityRole)
  {
    this.securityRoles.add(securityRole);
  }
  
  public Set<String> getSecurityRoles()
  {
    return this.securityRoles;
  }
  
  private Map<String, ContextEnvironment> envEntries = new HashMap();
  
  public void addEnvEntry(ContextEnvironment envEntry)
  {
    if (this.envEntries.containsKey(envEntry.getName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateEnvEntry", new Object[] { envEntry.getName() }));
    }
    this.envEntries.put(envEntry.getName(), envEntry);
  }
  
  public Map<String, ContextEnvironment> getEnvEntries()
  {
    return this.envEntries;
  }
  
  private Map<String, ContextEjb> ejbRefs = new HashMap();
  
  public void addEjbRef(ContextEjb ejbRef)
  {
    this.ejbRefs.put(ejbRef.getName(), ejbRef);
  }
  
  public Map<String, ContextEjb> getEjbRefs()
  {
    return this.ejbRefs;
  }
  
  private Map<String, ContextLocalEjb> ejbLocalRefs = new HashMap();
  
  public void addEjbLocalRef(ContextLocalEjb ejbLocalRef)
  {
    this.ejbLocalRefs.put(ejbLocalRef.getName(), ejbLocalRef);
  }
  
  public Map<String, ContextLocalEjb> getEjbLocalRefs()
  {
    return this.ejbLocalRefs;
  }
  
  private Map<String, ContextService> serviceRefs = new HashMap();
  
  public void addServiceRef(ContextService serviceRef)
  {
    this.serviceRefs.put(serviceRef.getName(), serviceRef);
  }
  
  public Map<String, ContextService> getServiceRefs()
  {
    return this.serviceRefs;
  }
  
  private Map<String, ContextResource> resourceRefs = new HashMap();
  
  public void addResourceRef(ContextResource resourceRef)
  {
    if (this.resourceRefs.containsKey(resourceRef.getName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateResourceRef", new Object[] { resourceRef.getName() }));
    }
    this.resourceRefs.put(resourceRef.getName(), resourceRef);
  }
  
  public Map<String, ContextResource> getResourceRefs()
  {
    return this.resourceRefs;
  }
  
  private Map<String, ContextResourceEnvRef> resourceEnvRefs = new HashMap();
  
  public void addResourceEnvRef(ContextResourceEnvRef resourceEnvRef)
  {
    if (this.resourceEnvRefs.containsKey(resourceEnvRef.getName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateResourceEnvRef", new Object[] { resourceEnvRef.getName() }));
    }
    this.resourceEnvRefs.put(resourceEnvRef.getName(), resourceEnvRef);
  }
  
  public Map<String, ContextResourceEnvRef> getResourceEnvRefs()
  {
    return this.resourceEnvRefs;
  }
  
  private Map<String, MessageDestinationRef> messageDestinationRefs = new HashMap();
  
  public void addMessageDestinationRef(MessageDestinationRef messageDestinationRef)
  {
    if (this.messageDestinationRefs.containsKey(messageDestinationRef.getName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateMessageDestinationRef", new Object[] { messageDestinationRef.getName() }));
    }
    this.messageDestinationRefs.put(messageDestinationRef.getName(), messageDestinationRef);
  }
  
  public Map<String, MessageDestinationRef> getMessageDestinationRefs()
  {
    return this.messageDestinationRefs;
  }
  
  private Map<String, MessageDestination> messageDestinations = new HashMap();
  
  public void addMessageDestination(MessageDestination messageDestination)
  {
    if (this.messageDestinations.containsKey(messageDestination.getName())) {
      throw new IllegalArgumentException(sm.getString("webXml.duplicateMessageDestination", new Object[] { messageDestination.getName() }));
    }
    this.messageDestinations.put(messageDestination.getName(), messageDestination);
  }
  
  public Map<String, MessageDestination> getMessageDestinations()
  {
    return this.messageDestinations;
  }
  
  private Map<String, String> localeEncodingMappings = new HashMap();
  
  public void addLocaleEncodingMapping(String locale, String encoding)
  {
    this.localeEncodingMappings.put(locale, encoding);
  }
  
  public Map<String, String> getLocalEncodingMappings()
  {
    return this.localeEncodingMappings;
  }
  
  private Map<String, String> postConstructMethods = new HashMap();
  
  public void addPostConstructMethods(String clazz, String method)
  {
    if (!this.postConstructMethods.containsKey(clazz)) {
      this.postConstructMethods.put(clazz, method);
    }
  }
  
  public Map<String, String> getPostConstructMethods()
  {
    return this.postConstructMethods;
  }
  
  private Map<String, String> preDestroyMethods = new HashMap();
  
  public void addPreDestroyMethods(String clazz, String method)
  {
    if (!this.preDestroyMethods.containsKey(clazz)) {
      this.preDestroyMethods.put(clazz, method);
    }
  }
  
  public Map<String, String> getPreDestroyMethods()
  {
    return this.preDestroyMethods;
  }
  
  private URL uRL = null;
  
  public void setURL(URL url)
  {
    this.uRL = url;
  }
  
  public URL getURL()
  {
    return this.uRL;
  }
  
  private String jarName = null;
  private static final String INDENT2 = "  ";
  private static final String INDENT4 = "    ";
  private static final String INDENT6 = "      ";
  
  public void setJarName(String jarName)
  {
    this.jarName = jarName;
  }
  
  public String getJarName()
  {
    return this.jarName;
  }
  
  public String toString()
  {
    StringBuilder buf = new StringBuilder(32);
    buf.append("Name: ");
    buf.append(getName());
    buf.append(", URL: ");
    buf.append(getURL());
    return buf.toString();
  }
  
  public String toXml()
  {
    StringBuilder sb = new StringBuilder(2048);
    
    sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    if (this.publicId != null)
    {
      sb.append("<!DOCTYPE web-app PUBLIC\n");
      sb.append("  \"");
      sb.append(this.publicId);
      sb.append("\"\n");
      sb.append("  \"");
      if ("-//Sun Microsystems, Inc.//DTD Web Application 2.2//EN".equals(this.publicId)) {
        sb.append("http://java.sun.com/dtd/web-app_2_2.dtd");
      } else {
        sb.append("http://java.sun.com/dtd/web-app_2_3.dtd");
      }
      sb.append("\">\n");
      sb.append("<web-app>");
    }
    else
    {
      String javaeeNamespace = null;
      String webXmlSchemaLocation = null;
      String version = getVersion();
      if ("2.4".equals(version))
      {
        javaeeNamespace = "http://java.sun.com/xml/ns/j2ee";
        webXmlSchemaLocation = "http://java.sun.com/xml/ns/j2ee/web-app_2_4.xsd";
      }
      else if ("2.5".equals(version))
      {
        javaeeNamespace = "http://java.sun.com/xml/ns/javaee";
        webXmlSchemaLocation = "http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd";
      }
      else if ("3.0".equals(version))
      {
        javaeeNamespace = "http://java.sun.com/xml/ns/javaee";
        webXmlSchemaLocation = "http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd";
      }
      sb.append("<web-app xmlns=\"");
      sb.append(javaeeNamespace);
      sb.append("\"\n");
      sb.append("         xmlns:xsi=");
      sb.append("\"http://www.w3.org/2001/XMLSchema-instance\"\n");
      sb.append("         xsi:schemaLocation=\"");
      sb.append(javaeeNamespace);
      sb.append(" ");
      sb.append(webXmlSchemaLocation);
      sb.append("\"\n");
      sb.append("         version=\"");
      sb.append(getVersion());
      sb.append("\"");
      if ("2.4".equals(version)) {
        sb.append(">\n\n");
      } else {
        sb.append("\n         metadata-complete=\"true\">\n\n");
      }
    }
    appendElement(sb, "  ", "display-name", this.displayName);
    if (isDistributable()) {
      sb.append("  <distributable/>\n\n");
    }
    for (Map.Entry<String, String> entry : this.contextParams.entrySet())
    {
      sb.append("  <context-param>\n");
      appendElement(sb, "    ", "param-name", (String)entry.getKey());
      appendElement(sb, "    ", "param-value", (String)entry.getValue());
      sb.append("  </context-param>\n");
    }
    sb.append('\n');
    if ((getMajorVersion() > 2) || (getMinorVersion() > 2))
    {
      for (Map.Entry<String, FilterDef> entry : this.filters.entrySet())
      {
        FilterDef filterDef = (FilterDef)entry.getValue();
        sb.append("  <filter>\n");
        appendElement(sb, "    ", "description", filterDef.getDescription());
        
        appendElement(sb, "    ", "display-name", filterDef.getDisplayName());
        
        appendElement(sb, "    ", "filter-name", filterDef.getFilterName());
        
        appendElement(sb, "    ", "filter-class", filterDef.getFilterClass());
        if (getMajorVersion() != 2) {
          appendElement(sb, "    ", "async-supported", filterDef.getAsyncSupported());
        }
        for (Map.Entry<String, String> param : filterDef.getParameterMap().entrySet())
        {
          sb.append("    <init-param>\n");
          appendElement(sb, "      ", "param-name", (String)param.getKey());
          appendElement(sb, "      ", "param-value", (String)param.getValue());
          sb.append("    </init-param>\n");
        }
        sb.append("  </filter>\n");
      }
      sb.append('\n');
      for (FilterMap filterMap : this.filterMaps)
      {
        sb.append("  <filter-mapping>\n");
        appendElement(sb, "    ", "filter-name", filterMap.getFilterName());
        if (filterMap.getMatchAllServletNames()) {
          sb.append("    <servlet-name>*</servlet-name>\n");
        } else {
          for (String servletName : filterMap.getServletNames()) {
            appendElement(sb, "    ", "servlet-name", servletName);
          }
        }
        if (filterMap.getMatchAllUrlPatterns()) {
          sb.append("    <url-pattern>*</url-pattern>\n");
        } else {
          for (String urlPattern : filterMap.getURLPatterns()) {
            appendElement(sb, "    ", "url-pattern", urlPattern);
          }
        }
        if ((getMajorVersion() > 2) || (getMinorVersion() > 3)) {
          for (String dispatcher : filterMap.getDispatcherNames()) {
            if ((getMajorVersion() != 2) || (!DispatcherType.ASYNC.name().equals(dispatcher))) {
              appendElement(sb, "    ", "dispatcher", dispatcher);
            }
          }
        }
        sb.append("  </filter-mapping>\n");
      }
      sb.append('\n');
    }
    if ((getMajorVersion() > 2) || (getMinorVersion() > 2))
    {
      for (String listener : this.listeners)
      {
        sb.append("  <listener>\n");
        appendElement(sb, "    ", "listener-class", listener);
        sb.append("  </listener>\n");
      }
      sb.append('\n');
    }
    for (Map.Entry<String, ServletDef> entry : this.servlets.entrySet())
    {
      ServletDef servletDef = (ServletDef)entry.getValue();
      sb.append("  <servlet>\n");
      appendElement(sb, "    ", "description", servletDef.getDescription());
      
      appendElement(sb, "    ", "display-name", servletDef.getDisplayName());
      
      appendElement(sb, "    ", "servlet-name", (String)entry.getKey());
      appendElement(sb, "    ", "servlet-class", servletDef.getServletClass());
      
      appendElement(sb, "    ", "jsp-file", servletDef.getJspFile());
      for (Map.Entry<String, String> param : servletDef.getParameterMap().entrySet())
      {
        sb.append("    <init-param>\n");
        appendElement(sb, "      ", "param-name", (String)param.getKey());
        appendElement(sb, "      ", "param-value", (String)param.getValue());
        sb.append("    </init-param>\n");
      }
      appendElement(sb, "    ", "load-on-startup", servletDef.getLoadOnStartup());
      
      appendElement(sb, "    ", "enabled", servletDef.getEnabled());
      if (getMajorVersion() != 2) {
        appendElement(sb, "    ", "async-supported", servletDef.getAsyncSupported());
      }
      if (((getMajorVersion() > 2) || (getMinorVersion() > 2)) && 
        (servletDef.getRunAs() != null))
      {
        sb.append("    <run-as>\n");
        appendElement(sb, "      ", "role-name", servletDef.getRunAs());
        sb.append("    </run-as>\n");
      }
      for (SecurityRoleRef roleRef : servletDef.getSecurityRoleRefs())
      {
        sb.append("    <security-role-ref>\n");
        appendElement(sb, "      ", "role-name", roleRef.getName());
        appendElement(sb, "      ", "role-link", roleRef.getLink());
        sb.append("    </security-role-ref>\n");
      }
      if (getMajorVersion() != 2)
      {
        MultipartDef multipartDef = servletDef.getMultipartDef();
        if (multipartDef != null)
        {
          sb.append("    <multipart-config>\n");
          appendElement(sb, "      ", "location", multipartDef.getLocation());
          
          appendElement(sb, "      ", "max-file-size", multipartDef.getMaxFileSize());
          
          appendElement(sb, "      ", "max-request-size", multipartDef.getMaxRequestSize());
          
          appendElement(sb, "      ", "file-size-threshold", multipartDef.getFileSizeThreshold());
          
          sb.append("    </multipart-config>\n");
        }
      }
      sb.append("  </servlet>\n");
    }
    sb.append('\n');
    for (Map.Entry<String, String> entry : this.servletMappings.entrySet())
    {
      sb.append("  <servlet-mapping>\n");
      appendElement(sb, "    ", "servlet-name", (String)entry.getValue());
      appendElement(sb, "    ", "url-pattern", (String)entry.getKey());
      sb.append("  </servlet-mapping>\n");
    }
    sb.append('\n');
    if (this.sessionConfig != null)
    {
      sb.append("  <session-config>\n");
      appendElement(sb, "    ", "session-timeout", this.sessionConfig.getSessionTimeout());
      if (this.majorVersion >= 3)
      {
        sb.append("    <cookie-config>\n");
        appendElement(sb, "      ", "name", this.sessionConfig.getCookieName());
        appendElement(sb, "      ", "domain", this.sessionConfig.getCookieDomain());
        
        appendElement(sb, "      ", "path", this.sessionConfig.getCookiePath());
        appendElement(sb, "      ", "comment", this.sessionConfig.getCookieComment());
        
        appendElement(sb, "      ", "http-only", this.sessionConfig.getCookieHttpOnly());
        
        appendElement(sb, "      ", "secure", this.sessionConfig.getCookieSecure());
        
        appendElement(sb, "      ", "max-age", this.sessionConfig.getCookieMaxAge());
        
        sb.append("    </cookie-config>\n");
        for (SessionTrackingMode stm : this.sessionConfig.getSessionTrackingModes()) {
          appendElement(sb, "    ", "tracking-mode", stm.name());
        }
      }
      sb.append("  </session-config>\n\n");
    }
    for (Map.Entry<String, String> entry : this.mimeMappings.entrySet())
    {
      sb.append("  <mime-mapping>\n");
      appendElement(sb, "    ", "extension", (String)entry.getKey());
      appendElement(sb, "    ", "mime-type", (String)entry.getValue());
      sb.append("  </mime-mapping>\n");
    }
    sb.append('\n');
    if (this.welcomeFiles.size() > 0)
    {
      sb.append("  <welcome-file-list>\n");
      for (String welcomeFile : this.welcomeFiles) {
        appendElement(sb, "    ", "welcome-file", welcomeFile);
      }
      sb.append("  </welcome-file-list>\n\n");
    }
    for (ErrorPage errorPage : this.errorPages.values())
    {
      String exeptionType = errorPage.getExceptionType();
      int errorCode = errorPage.getErrorCode();
      if ((exeptionType != null) || (errorCode != 0) || (getMajorVersion() != 2))
      {
        sb.append("  <error-page>\n");
        if (errorPage.getExceptionType() != null) {
          appendElement(sb, "    ", "exception-type", exeptionType);
        } else if (errorPage.getErrorCode() > 0) {
          appendElement(sb, "    ", "error-code", Integer.toString(errorCode));
        }
        appendElement(sb, "    ", "location", errorPage.getLocation());
        sb.append("  </error-page>\n");
      }
    }
    sb.append('\n');
    if ((this.taglibs.size() > 0) || (this.jspPropertyGroups.size() > 0))
    {
      if ((getMajorVersion() > 2) || (getMinorVersion() > 3)) {
        sb.append("  <jsp-config>\n");
      }
      for (Map.Entry<String, String> entry : this.taglibs.entrySet())
      {
        sb.append("    <taglib>\n");
        appendElement(sb, "      ", "taglib-uri", (String)entry.getKey());
        appendElement(sb, "      ", "taglib-location", (String)entry.getValue());
        sb.append("    </taglib>\n");
      }
      if ((getMajorVersion() > 2) || (getMinorVersion() > 3))
      {
        for (JspPropertyGroup jpg : this.jspPropertyGroups)
        {
          sb.append("    <jsp-property-group>\n");
          for (String urlPattern : jpg.getUrlPatterns()) {
            appendElement(sb, "      ", "url-pattern", urlPattern);
          }
          appendElement(sb, "      ", "el-ignored", jpg.getElIgnored());
          appendElement(sb, "      ", "page-encoding", jpg.getPageEncoding());
          
          appendElement(sb, "      ", "scripting-invalid", jpg.getScriptingInvalid());
          
          appendElement(sb, "      ", "is-xml", jpg.getIsXml());
          for (String prelude : jpg.getIncludePreludes()) {
            appendElement(sb, "      ", "include-prelude", prelude);
          }
          for (String coda : jpg.getIncludeCodas()) {
            appendElement(sb, "      ", "include-coda", coda);
          }
          appendElement(sb, "      ", "deferred-syntax-allowed-as-literal", jpg.getDeferredSyntax());
          
          appendElement(sb, "      ", "trim-directive-whitespaces", jpg.getTrimWhitespace());
          
          appendElement(sb, "      ", "default-content-type", jpg.getDefaultContentType());
          
          appendElement(sb, "      ", "buffer", jpg.getBuffer());
          appendElement(sb, "      ", "error-on-undeclared-namespace", jpg.getErrorOnUndeclaredNamespace());
          
          sb.append("    </jsp-property-group>\n");
        }
        sb.append("  </jsp-config>\n\n");
      }
    }
    if ((getMajorVersion() > 2) || (getMinorVersion() > 2))
    {
      for (ContextResourceEnvRef resourceEnvRef : this.resourceEnvRefs.values())
      {
        sb.append("  <resource-env-ref>\n");
        appendElement(sb, "    ", "description", resourceEnvRef.getDescription());
        
        appendElement(sb, "    ", "resource-env-ref-name", resourceEnvRef.getName());
        
        appendElement(sb, "    ", "resource-env-ref-type", resourceEnvRef.getType());
        for (InjectionTarget target : resourceEnvRef.getInjectionTargets())
        {
          sb.append("    <injection-target>\n");
          appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
          
          appendElement(sb, "      ", "injection-target-name", target.getTargetName());
          
          sb.append("    </injection-target>\n");
        }
        sb.append("  </resource-env-ref>\n");
      }
      sb.append('\n');
    }
    for (ContextResource resourceRef : this.resourceRefs.values())
    {
      sb.append("  <resource-ref>\n");
      appendElement(sb, "    ", "description", resourceRef.getDescription());
      
      appendElement(sb, "    ", "res-ref-name", resourceRef.getName());
      appendElement(sb, "    ", "res-type", resourceRef.getType());
      appendElement(sb, "    ", "res-auth", resourceRef.getAuth());
      if ((getMajorVersion() > 2) || (getMinorVersion() > 2)) {
        appendElement(sb, "    ", "res-sharing-scope", resourceRef.getScope());
      }
      for (InjectionTarget target : resourceRef.getInjectionTargets())
      {
        sb.append("    <injection-target>\n");
        appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
        
        appendElement(sb, "      ", "injection-target-name", target.getTargetName());
        
        sb.append("    </injection-target>\n");
      }
      sb.append("  </resource-ref>\n");
    }
    sb.append('\n');
    for (SecurityConstraint constraint : this.securityConstraints)
    {
      sb.append("  <security-constraint>\n");
      if ((getMajorVersion() > 2) || (getMinorVersion() > 2)) {
        appendElement(sb, "    ", "display-name", constraint.getDisplayName());
      }
      for (SecurityCollection collection : constraint.findCollections())
      {
        sb.append("    <web-resource-collection>\n");
        appendElement(sb, "      ", "web-resource-name", collection.getName());
        
        appendElement(sb, "      ", "description", collection.getDescription());
        for (String urlPattern : collection.findPatterns()) {
          appendElement(sb, "      ", "url-pattern", urlPattern);
        }
        for (String method : collection.findMethods()) {
          appendElement(sb, "      ", "http-method", method);
        }
        for (String method : collection.findOmittedMethods()) {
          appendElement(sb, "      ", "http-method-omission", method);
        }
        sb.append("    </web-resource-collection>\n");
      }
      if (constraint.findAuthRoles().length > 0)
      {
        sb.append("    <auth-constraint>\n");
        for (String role : constraint.findAuthRoles()) {
          appendElement(sb, "      ", "role-name", role);
        }
        sb.append("    </auth-constraint>\n");
      }
      if (constraint.getUserConstraint() != null)
      {
        sb.append("    <user-data-constraint>\n");
        appendElement(sb, "      ", "transport-guarantee", constraint.getUserConstraint());
        
        sb.append("    </user-data-constraint>\n");
      }
      sb.append("  </security-constraint>\n");
    }
    sb.append('\n');
    if (this.loginConfig != null)
    {
      sb.append("  <login-config>\n");
      appendElement(sb, "    ", "auth-method", this.loginConfig.getAuthMethod());
      
      appendElement(sb, "    ", "realm-name", this.loginConfig.getRealmName());
      if ((this.loginConfig.getErrorPage() != null) || (this.loginConfig.getLoginPage() != null))
      {
        sb.append("    <form-login-config>\n");
        appendElement(sb, "      ", "form-login-page", this.loginConfig.getLoginPage());
        
        appendElement(sb, "      ", "form-error-page", this.loginConfig.getErrorPage());
        
        sb.append("    </form-login-config>\n");
      }
      sb.append("  </login-config>\n\n");
    }
    for (String roleName : this.securityRoles)
    {
      sb.append("  <security-role>\n");
      appendElement(sb, "    ", "role-name", roleName);
      sb.append("  </security-role>\n");
    }
    for (ContextEnvironment envEntry : this.envEntries.values())
    {
      sb.append("  <env-entry>\n");
      appendElement(sb, "    ", "description", envEntry.getDescription());
      
      appendElement(sb, "    ", "env-entry-name", envEntry.getName());
      appendElement(sb, "    ", "env-entry-type", envEntry.getType());
      appendElement(sb, "    ", "env-entry-value", envEntry.getValue());
      for (InjectionTarget target : envEntry.getInjectionTargets())
      {
        sb.append("    <injection-target>\n");
        appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
        
        appendElement(sb, "      ", "injection-target-name", target.getTargetName());
        
        sb.append("    </injection-target>\n");
      }
      sb.append("  </env-entry>\n");
    }
    sb.append('\n');
    for (ContextEjb ejbRef : this.ejbRefs.values())
    {
      sb.append("  <ejb-ref>\n");
      appendElement(sb, "    ", "description", ejbRef.getDescription());
      appendElement(sb, "    ", "ejb-ref-name", ejbRef.getName());
      appendElement(sb, "    ", "ejb-ref-type", ejbRef.getType());
      appendElement(sb, "    ", "home", ejbRef.getHome());
      appendElement(sb, "    ", "remote", ejbRef.getRemote());
      appendElement(sb, "    ", "ejb-link", ejbRef.getLink());
      for (InjectionTarget target : ejbRef.getInjectionTargets())
      {
        sb.append("    <injection-target>\n");
        appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
        
        appendElement(sb, "      ", "injection-target-name", target.getTargetName());
        
        sb.append("    </injection-target>\n");
      }
      sb.append("  </ejb-ref>\n");
    }
    sb.append('\n');
    if ((getMajorVersion() > 2) || (getMinorVersion() > 2))
    {
      for (ContextLocalEjb ejbLocalRef : this.ejbLocalRefs.values())
      {
        sb.append("  <ejb-local-ref>\n");
        appendElement(sb, "    ", "description", ejbLocalRef.getDescription());
        
        appendElement(sb, "    ", "ejb-ref-name", ejbLocalRef.getName());
        appendElement(sb, "    ", "ejb-ref-type", ejbLocalRef.getType());
        appendElement(sb, "    ", "local-home", ejbLocalRef.getHome());
        appendElement(sb, "    ", "local", ejbLocalRef.getLocal());
        appendElement(sb, "    ", "ejb-link", ejbLocalRef.getLink());
        for (InjectionTarget target : ejbLocalRef.getInjectionTargets())
        {
          sb.append("    <injection-target>\n");
          appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
          
          appendElement(sb, "      ", "injection-target-name", target.getTargetName());
          
          sb.append("    </injection-target>\n");
        }
        sb.append("  </ejb-local-ref>\n");
      }
      sb.append('\n');
    }
    if ((getMajorVersion() > 2) || (getMinorVersion() > 3))
    {
      for (ContextService serviceRef : this.serviceRefs.values())
      {
        sb.append("  <service-ref>\n");
        appendElement(sb, "    ", "description", serviceRef.getDescription());
        
        appendElement(sb, "    ", "display-name", serviceRef.getDisplayname());
        
        appendElement(sb, "    ", "service-ref-name", serviceRef.getName());
        
        appendElement(sb, "    ", "service-interface", serviceRef.getInterface());
        
        appendElement(sb, "    ", "service-ref-type", serviceRef.getType());
        
        appendElement(sb, "    ", "wsdl-file", serviceRef.getWsdlfile());
        appendElement(sb, "    ", "jaxrpc-mapping-file", serviceRef.getJaxrpcmappingfile());
        
        String qname = serviceRef.getServiceqnameNamespaceURI();
        if (qname != null) {
          qname = qname + ":";
        }
        qname = qname + serviceRef.getServiceqnameLocalpart();
        appendElement(sb, "    ", "service-qname", qname);
        Iterator<String> endpointIter = serviceRef.getServiceendpoints();
        while (endpointIter.hasNext())
        {
          String endpoint = (String)endpointIter.next();
          sb.append("    <port-component-ref>\n");
          appendElement(sb, "      ", "service-endpoint-interface", endpoint);
          
          appendElement(sb, "      ", "port-component-link", serviceRef.getProperty(endpoint));
          
          sb.append("    </port-component-ref>\n");
        }
        Iterator<String> handlerIter = serviceRef.getHandlers();
        while (handlerIter.hasNext())
        {
          String handler = (String)handlerIter.next();
          sb.append("    <handler>\n");
          ContextHandler ch = serviceRef.getHandler(handler);
          appendElement(sb, "      ", "handler-name", ch.getName());
          appendElement(sb, "      ", "handler-class", ch.getHandlerclass());
          
          sb.append("    </handler>\n");
        }
        for (InjectionTarget target : serviceRef.getInjectionTargets())
        {
          sb.append("    <injection-target>\n");
          appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
          
          appendElement(sb, "      ", "injection-target-name", target.getTargetName());
          
          sb.append("    </injection-target>\n");
        }
        sb.append("  </service-ref>\n");
      }
      sb.append('\n');
    }
    if (!this.postConstructMethods.isEmpty())
    {
      for (Map.Entry<String, String> entry : this.postConstructMethods.entrySet())
      {
        sb.append("  <post-construct>\n");
        appendElement(sb, "    ", "lifecycle-callback-class", (String)entry.getKey());
        
        appendElement(sb, "    ", "lifecycle-callback-method", (String)entry.getValue());
        
        sb.append("  </post-construct>\n");
      }
      sb.append('\n');
    }
    if (!this.preDestroyMethods.isEmpty())
    {
      for (Map.Entry<String, String> entry : this.preDestroyMethods.entrySet())
      {
        sb.append("  <pre-destroy>\n");
        appendElement(sb, "    ", "lifecycle-callback-class", (String)entry.getKey());
        
        appendElement(sb, "    ", "lifecycle-callback-method", (String)entry.getValue());
        
        sb.append("  </pre-destroy>\n");
      }
      sb.append('\n');
    }
    if ((getMajorVersion() > 2) || (getMinorVersion() > 3))
    {
      for (MessageDestinationRef mdr : this.messageDestinationRefs.values())
      {
        sb.append("  <message-destination-ref>\n");
        appendElement(sb, "    ", "description", mdr.getDescription());
        appendElement(sb, "    ", "message-destination-ref-name", mdr.getName());
        
        appendElement(sb, "    ", "message-destination-type", mdr.getType());
        
        appendElement(sb, "    ", "message-destination-usage", mdr.getUsage());
        
        appendElement(sb, "    ", "message-destination-link", mdr.getLink());
        for (InjectionTarget target : mdr.getInjectionTargets())
        {
          sb.append("    <injection-target>\n");
          appendElement(sb, "      ", "injection-target-class", target.getTargetClass());
          
          appendElement(sb, "      ", "injection-target-name", target.getTargetName());
          
          sb.append("    </injection-target>\n");
        }
        sb.append("  </message-destination-ref>\n");
      }
      sb.append('\n');
      for (MessageDestination md : this.messageDestinations.values())
      {
        sb.append("  <message-destination>\n");
        appendElement(sb, "    ", "description", md.getDescription());
        appendElement(sb, "    ", "display-name", md.getDisplayName());
        appendElement(sb, "    ", "message-destination-name", md.getName());
        
        sb.append("  </message-destination>\n");
      }
      sb.append('\n');
    }
    if (((getMajorVersion() > 2) || (getMinorVersion() > 3)) && 
      (this.localeEncodingMappings.size() > 0))
    {
      sb.append("  <locale-encoding-mapping-list>\n");
      for (Map.Entry<String, String> entry : this.localeEncodingMappings.entrySet())
      {
        sb.append("    <locale-encoding-mapping>\n");
        appendElement(sb, "      ", "locale", (String)entry.getKey());
        appendElement(sb, "      ", "encoding", (String)entry.getValue());
        sb.append("    </locale-encoding-mapping>\n");
      }
      sb.append("  </locale-encoding-mapping-list>\n");
    }
    sb.append("</web-app>");
    return sb.toString();
  }
  
  private static void appendElement(StringBuilder sb, String indent, String elementName, String value)
  {
    if (value == null) {
      return;
    }
    if (value.length() == 0)
    {
      sb.append(indent);
      sb.append('<');
      sb.append(elementName);
      sb.append("/>\n");
    }
    else
    {
      sb.append(indent);
      sb.append('<');
      sb.append(elementName);
      sb.append('>');
      sb.append(escapeXml(value));
      sb.append("</");
      sb.append(elementName);
      sb.append(">\n");
    }
  }
  
  private static void appendElement(StringBuilder sb, String indent, String elementName, Object value)
  {
    if (value == null) {
      return;
    }
    appendElement(sb, indent, elementName, value.toString());
  }
  
  private static String escapeXml(String s)
  {
    if (s == null) {
      return null;
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < s.length(); i++)
    {
      char c = s.charAt(i);
      if (c == '<') {
        sb.append("&lt;");
      } else if (c == '>') {
        sb.append("&gt;");
      } else if (c == '\'') {
        sb.append("&apos;");
      } else if (c == '&') {
        sb.append("&amp;");
      } else if (c == '"') {
        sb.append("&quot;");
      } else {
        sb.append(c);
      }
    }
    return sb.toString();
  }
  
  public void configureContext(Context context)
  {
    context.setPublicId(this.publicId);
    
    context.setEffectiveMajorVersion(getMajorVersion());
    context.setEffectiveMinorVersion(getMinorVersion());
    for (Map.Entry<String, String> entry : this.contextParams.entrySet()) {
      context.addParameter((String)entry.getKey(), (String)entry.getValue());
    }
    context.setDisplayName(this.displayName);
    context.setDistributable(this.distributable);
    for (ContextLocalEjb ejbLocalRef : this.ejbLocalRefs.values()) {
      context.getNamingResources().addLocalEjb(ejbLocalRef);
    }
    for (ContextEjb ejbRef : this.ejbRefs.values()) {
      context.getNamingResources().addEjb(ejbRef);
    }
    for (ContextEnvironment environment : this.envEntries.values()) {
      context.getNamingResources().addEnvironment(environment);
    }
    for (ErrorPage errorPage : this.errorPages.values()) {
      context.addErrorPage(errorPage);
    }
    for (FilterDef filter : this.filters.values())
    {
      if (filter.getAsyncSupported() == null) {
        filter.setAsyncSupported("false");
      }
      context.addFilterDef(filter);
    }
    for (FilterMap filterMap : this.filterMaps) {
      context.addFilterMap(filterMap);
    }
    for (JspPropertyGroup jspPropertyGroup : this.jspPropertyGroups)
    {
      JspPropertyGroupDescriptor descriptor = new ApplicationJspPropertyGroupDescriptor(jspPropertyGroup);
      
      context.getJspConfigDescriptor().getJspPropertyGroups().add(descriptor);
    }
    for (String listener : this.listeners) {
      context.addApplicationListener(listener);
    }
    for (Map.Entry<String, String> entry : this.localeEncodingMappings.entrySet()) {
      context.addLocaleEncodingMappingParameter((String)entry.getKey(), (String)entry.getValue());
    }
    if (this.loginConfig != null) {
      context.setLoginConfig(this.loginConfig);
    }
    for (MessageDestinationRef mdr : this.messageDestinationRefs.values()) {
      context.getNamingResources().addMessageDestinationRef(mdr);
    }
    context.setIgnoreAnnotations(this.metadataComplete);
    for (Map.Entry<String, String> entry : this.mimeMappings.entrySet()) {
      context.addMimeMapping((String)entry.getKey(), (String)entry.getValue());
    }
    for (ContextResourceEnvRef resource : this.resourceEnvRefs.values()) {
      context.getNamingResources().addResourceEnvRef(resource);
    }
    for (ContextResource resource : this.resourceRefs.values()) {
      context.getNamingResources().addResource(resource);
    }
    for (SecurityConstraint constraint : this.securityConstraints) {
      context.addConstraint(constraint);
    }
    for (String role : this.securityRoles) {
      context.addSecurityRole(role);
    }
    for (ContextService service : this.serviceRefs.values()) {
      context.getNamingResources().addService(service);
    }
    for (ServletDef servlet : this.servlets.values())
    {
      Wrapper wrapper = context.createWrapper();
      if (servlet.getLoadOnStartup() != null) {
        wrapper.setLoadOnStartup(servlet.getLoadOnStartup().intValue());
      }
      if (servlet.getEnabled() != null) {
        wrapper.setEnabled(servlet.getEnabled().booleanValue());
      }
      wrapper.setName(servlet.getServletName());
      Map<String, String> params = servlet.getParameterMap();
      for (Map.Entry<String, String> entry : params.entrySet()) {
        wrapper.addInitParameter((String)entry.getKey(), (String)entry.getValue());
      }
      wrapper.setRunAs(servlet.getRunAs());
      Set<SecurityRoleRef> roleRefs = servlet.getSecurityRoleRefs();
      for (SecurityRoleRef roleRef : roleRefs) {
        wrapper.addSecurityReference(roleRef.getName(), roleRef.getLink());
      }
      wrapper.setServletClass(servlet.getServletClass());
      MultipartDef multipartdef = servlet.getMultipartDef();
      if (multipartdef != null) {
        if ((multipartdef.getMaxFileSize() != null) && (multipartdef.getMaxRequestSize() != null) && (multipartdef.getFileSizeThreshold() != null)) {
          wrapper.setMultipartConfigElement(new MultipartConfigElement(multipartdef.getLocation(), Long.parseLong(multipartdef.getMaxFileSize()), Long.parseLong(multipartdef.getMaxRequestSize()), Integer.parseInt(multipartdef.getFileSizeThreshold())));
        } else {
          wrapper.setMultipartConfigElement(new MultipartConfigElement(multipartdef.getLocation()));
        }
      }
      if (servlet.getAsyncSupported() != null) {
        wrapper.setAsyncSupported(servlet.getAsyncSupported().booleanValue());
      }
      wrapper.setOverridable(servlet.isOverridable());
      context.addChild(wrapper);
    }
    for (Map.Entry<String, String> entry : this.servletMappings.entrySet()) {
      context.addServletMapping((String)entry.getKey(), (String)entry.getValue());
    }
    if (this.sessionConfig != null)
    {
      if (this.sessionConfig.getSessionTimeout() != null) {
        context.setSessionTimeout(this.sessionConfig.getSessionTimeout().intValue());
      }
      SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
      
      scc.setName(this.sessionConfig.getCookieName());
      scc.setDomain(this.sessionConfig.getCookieDomain());
      scc.setPath(this.sessionConfig.getCookiePath());
      scc.setComment(this.sessionConfig.getCookieComment());
      if (this.sessionConfig.getCookieHttpOnly() != null) {
        scc.setHttpOnly(this.sessionConfig.getCookieHttpOnly().booleanValue());
      }
      if (this.sessionConfig.getCookieSecure() != null) {
        scc.setSecure(this.sessionConfig.getCookieSecure().booleanValue());
      }
      if (this.sessionConfig.getCookieMaxAge() != null) {
        scc.setMaxAge(this.sessionConfig.getCookieMaxAge().intValue());
      }
      if (this.sessionConfig.getSessionTrackingModes().size() > 0) {
        context.getServletContext().setSessionTrackingModes(this.sessionConfig.getSessionTrackingModes());
      }
    }
    for (Map.Entry<String, String> entry : this.taglibs.entrySet())
    {
      TaglibDescriptor descriptor = new ApplicationTaglibDescriptor((String)entry.getValue(), (String)entry.getKey());
      
      context.getJspConfigDescriptor().getTaglibs().add(descriptor);
    }
    for (String welcomeFile : this.welcomeFiles) {
      if ((welcomeFile != null) && (welcomeFile.length() > 0)) {
        context.addWelcomeFile(welcomeFile);
      }
    }
    for (JspPropertyGroup jspPropertyGroup : this.jspPropertyGroups)
    {
      jspServletName = context.findServletMapping("*.jsp");
      if (jspServletName == null) {
        jspServletName = "jsp";
      }
      if (context.findChild(jspServletName) != null) {
        for (String urlPattern : jspPropertyGroup.getUrlPatterns()) {
          context.addServletMapping(urlPattern, jspServletName, true);
        }
      } else if (log.isDebugEnabled()) {
        for (String urlPattern : jspPropertyGroup.getUrlPatterns()) {
          log.debug("Skiping " + urlPattern + " , no servlet " + jspServletName);
        }
      }
    }
    String jspServletName;
    for (Map.Entry<String, String> entry : this.postConstructMethods.entrySet()) {
      context.addPostConstructMethod((String)entry.getKey(), (String)entry.getValue());
    }
    for (Map.Entry<String, String> entry : this.preDestroyMethods.entrySet()) {
      context.addPreDestroyMethod((String)entry.getKey(), (String)entry.getValue());
    }
  }
  
  public boolean merge(Set<WebXml> fragments)
  {
    WebXml temp = new WebXml();
    for (WebXml fragment : fragments) {
      if (!mergeMap(fragment.getContextParams(), this.contextParams, temp.getContextParams(), fragment, "Context Parameter")) {
        return false;
      }
    }
    this.contextParams.putAll(temp.getContextParams());
    if (this.displayName == null)
    {
      for (WebXml fragment : fragments)
      {
        String value = fragment.getDisplayName();
        if (value != null) {
          if (temp.getDisplayName() == null)
          {
            temp.setDisplayName(value);
          }
          else
          {
            log.error(sm.getString("webXml.mergeConflictDisplayName", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.displayName = temp.getDisplayName();
    }
    if (this.distributable) {
      for (WebXml fragment : fragments) {
        if (!fragment.isDistributable())
        {
          this.distributable = false;
          break;
        }
      }
    }
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getEjbLocalRefs(), this.ejbLocalRefs, temp.getEjbLocalRefs(), fragment)) {
        return false;
      }
    }
    this.ejbLocalRefs.putAll(temp.getEjbLocalRefs());
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getEjbRefs(), this.ejbRefs, temp.getEjbRefs(), fragment)) {
        return false;
      }
    }
    this.ejbRefs.putAll(temp.getEjbRefs());
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getEnvEntries(), this.envEntries, temp.getEnvEntries(), fragment)) {
        return false;
      }
    }
    this.envEntries.putAll(temp.getEnvEntries());
    for (WebXml fragment : fragments) {
      if (!mergeMap(fragment.getErrorPages(), this.errorPages, temp.getErrorPages(), fragment, "Error Page")) {
        return false;
      }
    }
    this.errorPages.putAll(temp.getErrorPages());
    
    List<FilterMap> filterMapsToAdd = new ArrayList();
    for (WebXml fragment : fragments) {
      for (FilterMap filterMap : fragment.getFilterMappings()) {
        if (!this.filterMappingNames.contains(filterMap.getFilterName())) {
          filterMapsToAdd.add(filterMap);
        }
      }
    }
    for (FilterMap filterMap : filterMapsToAdd) {
      addFilterMapping(filterMap);
    }
    for (Iterator i$ = fragments.iterator(); i$.hasNext();)
    {
      fragment = (WebXml)i$.next();
      for (Map.Entry<String, FilterDef> entry : fragment.getFilters().entrySet()) {
        if (this.filters.containsKey(entry.getKey())) {
          mergeFilter((FilterDef)entry.getValue(), (FilterDef)this.filters.get(entry.getKey()), false);
        } else if (temp.getFilters().containsKey(entry.getKey()))
        {
          if (!mergeFilter((FilterDef)entry.getValue(), (FilterDef)temp.getFilters().get(entry.getKey()), true))
          {
            log.error(sm.getString("webXml.mergeConflictFilter", new Object[] { entry.getKey(), fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
        else {
          temp.getFilters().put(entry.getKey(), entry.getValue());
        }
      }
    }
    WebXml fragment;
    this.filters.putAll(temp.getFilters());
    for (WebXml fragment : fragments) {
      for (JspPropertyGroup jspPropertyGroup : fragment.getJspPropertyGroups()) {
        addJspPropertyGroup(jspPropertyGroup);
      }
    }
    for (WebXml fragment : fragments) {
      for (String listener : fragment.getListeners()) {
        addListener(listener);
      }
    }
    for (WebXml fragment : fragments) {
      if (!mergeMap(fragment.getLocalEncodingMappings(), this.localeEncodingMappings, temp.getLocalEncodingMappings(), fragment, "Locale Encoding Mapping")) {
        return false;
      }
    }
    this.localeEncodingMappings.putAll(temp.getLocalEncodingMappings());
    if (getLoginConfig() == null)
    {
      LoginConfig tempLoginConfig = null;
      for (WebXml fragment : fragments)
      {
        LoginConfig fragmentLoginConfig = fragment.loginConfig;
        if (fragmentLoginConfig != null) {
          if ((tempLoginConfig == null) || (fragmentLoginConfig.equals(tempLoginConfig))) {
            tempLoginConfig = fragmentLoginConfig;
          } else {
            log.error(sm.getString("webXml.mergeConflictLoginConfig", new Object[] { fragment.getName(), fragment.getURL() }));
          }
        }
      }
      this.loginConfig = tempLoginConfig;
    }
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getMessageDestinationRefs(), this.messageDestinationRefs, temp.getMessageDestinationRefs(), fragment)) {
        return false;
      }
    }
    this.messageDestinationRefs.putAll(temp.getMessageDestinationRefs());
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getMessageDestinations(), this.messageDestinations, temp.getMessageDestinations(), fragment)) {
        return false;
      }
    }
    this.messageDestinations.putAll(temp.getMessageDestinations());
    for (WebXml fragment : fragments) {
      if (!mergeMap(fragment.getMimeMappings(), this.mimeMappings, temp.getMimeMappings(), fragment, "Mime Mapping")) {
        return false;
      }
    }
    this.mimeMappings.putAll(temp.getMimeMappings());
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getResourceEnvRefs(), this.resourceEnvRefs, temp.getResourceEnvRefs(), fragment)) {
        return false;
      }
    }
    this.resourceEnvRefs.putAll(temp.getResourceEnvRefs());
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getResourceRefs(), this.resourceRefs, temp.getResourceRefs(), fragment)) {
        return false;
      }
    }
    this.resourceRefs.putAll(temp.getResourceRefs());
    for (WebXml fragment : fragments) {
      for (SecurityConstraint constraint : fragment.getSecurityConstraints()) {
        addSecurityConstraint(constraint);
      }
    }
    for (WebXml fragment : fragments) {
      for (String role : fragment.getSecurityRoles()) {
        addSecurityRole(role);
      }
    }
    for (WebXml fragment : fragments) {
      if (!mergeResourceMap(fragment.getServiceRefs(), this.serviceRefs, temp.getServiceRefs(), fragment)) {
        return false;
      }
    }
    this.serviceRefs.putAll(temp.getServiceRefs());
    
    List<Map.Entry<String, String>> servletMappingsToAdd = new ArrayList();
    for (WebXml fragment : fragments) {
      for (Map.Entry<String, String> servletMap : fragment.getServletMappings().entrySet()) {
        if ((!this.servletMappingNames.contains(servletMap.getValue())) && (!this.servletMappings.containsKey(servletMap.getKey()))) {
          servletMappingsToAdd.add(servletMap);
        }
      }
    }
    for (Map.Entry<String, String> mapping : servletMappingsToAdd) {
      addServletMapping((String)mapping.getKey(), (String)mapping.getValue());
    }
    for (Iterator i$ = fragments.iterator(); i$.hasNext();)
    {
      fragment = (WebXml)i$.next();
      for (Map.Entry<String, ServletDef> entry : fragment.getServlets().entrySet()) {
        if (this.servlets.containsKey(entry.getKey())) {
          mergeServlet((ServletDef)entry.getValue(), (ServletDef)this.servlets.get(entry.getKey()), false);
        } else if (temp.getServlets().containsKey(entry.getKey()))
        {
          if (!mergeServlet((ServletDef)entry.getValue(), (ServletDef)temp.getServlets().get(entry.getKey()), true))
          {
            log.error(sm.getString("webXml.mergeConflictServlet", new Object[] { entry.getKey(), fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
        else {
          temp.getServlets().put(entry.getKey(), entry.getValue());
        }
      }
    }
    WebXml fragment;
    this.servlets.putAll(temp.getServlets());
    if (this.sessionConfig.getSessionTimeout() == null)
    {
      for (WebXml fragment : fragments)
      {
        Integer value = fragment.getSessionConfig().getSessionTimeout();
        if (value != null) {
          if (temp.getSessionConfig().getSessionTimeout() == null)
          {
            temp.getSessionConfig().setSessionTimeout(value.toString());
          }
          else if (!value.equals(temp.getSessionConfig().getSessionTimeout()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionTimeout", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      if (temp.getSessionConfig().getSessionTimeout() != null) {
        this.sessionConfig.setSessionTimeout(temp.getSessionConfig().getSessionTimeout().toString());
      }
    }
    if (this.sessionConfig.getCookieName() == null)
    {
      for (WebXml fragment : fragments)
      {
        String value = fragment.getSessionConfig().getCookieName();
        if (value != null) {
          if (temp.getSessionConfig().getCookieName() == null)
          {
            temp.getSessionConfig().setCookieName(value);
          }
          else if (!value.equals(temp.getSessionConfig().getCookieName()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieName", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.sessionConfig.setCookieName(temp.getSessionConfig().getCookieName());
    }
    if (this.sessionConfig.getCookieDomain() == null)
    {
      for (WebXml fragment : fragments)
      {
        String value = fragment.getSessionConfig().getCookieDomain();
        if (value != null) {
          if (temp.getSessionConfig().getCookieDomain() == null)
          {
            temp.getSessionConfig().setCookieDomain(value);
          }
          else if (!value.equals(temp.getSessionConfig().getCookieDomain()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieDomain", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.sessionConfig.setCookieDomain(temp.getSessionConfig().getCookieDomain());
    }
    if (this.sessionConfig.getCookiePath() == null)
    {
      for (WebXml fragment : fragments)
      {
        String value = fragment.getSessionConfig().getCookiePath();
        if (value != null) {
          if (temp.getSessionConfig().getCookiePath() == null)
          {
            temp.getSessionConfig().setCookiePath(value);
          }
          else if (!value.equals(temp.getSessionConfig().getCookiePath()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookiePath", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.sessionConfig.setCookiePath(temp.getSessionConfig().getCookiePath());
    }
    if (this.sessionConfig.getCookieComment() == null)
    {
      for (WebXml fragment : fragments)
      {
        String value = fragment.getSessionConfig().getCookieComment();
        if (value != null) {
          if (temp.getSessionConfig().getCookieComment() == null)
          {
            temp.getSessionConfig().setCookieComment(value);
          }
          else if (!value.equals(temp.getSessionConfig().getCookieComment()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieComment", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.sessionConfig.setCookieComment(temp.getSessionConfig().getCookieComment());
    }
    if (this.sessionConfig.getCookieHttpOnly() == null)
    {
      for (WebXml fragment : fragments)
      {
        Boolean value = fragment.getSessionConfig().getCookieHttpOnly();
        if (value != null) {
          if (temp.getSessionConfig().getCookieHttpOnly() == null)
          {
            temp.getSessionConfig().setCookieHttpOnly(value.toString());
          }
          else if (!value.equals(temp.getSessionConfig().getCookieHttpOnly()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieHttpOnly", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      if (temp.getSessionConfig().getCookieHttpOnly() != null) {
        this.sessionConfig.setCookieHttpOnly(temp.getSessionConfig().getCookieHttpOnly().toString());
      }
    }
    if (this.sessionConfig.getCookieSecure() == null)
    {
      for (WebXml fragment : fragments)
      {
        Boolean value = fragment.getSessionConfig().getCookieSecure();
        if (value != null) {
          if (temp.getSessionConfig().getCookieSecure() == null)
          {
            temp.getSessionConfig().setCookieSecure(value.toString());
          }
          else if (!value.equals(temp.getSessionConfig().getCookieSecure()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieSecure", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      if (temp.getSessionConfig().getCookieSecure() != null) {
        this.sessionConfig.setCookieSecure(temp.getSessionConfig().getCookieSecure().toString());
      }
    }
    if (this.sessionConfig.getCookieMaxAge() == null)
    {
      for (WebXml fragment : fragments)
      {
        Integer value = fragment.getSessionConfig().getCookieMaxAge();
        if (value != null) {
          if (temp.getSessionConfig().getCookieMaxAge() == null)
          {
            temp.getSessionConfig().setCookieMaxAge(value.toString());
          }
          else if (!value.equals(temp.getSessionConfig().getCookieMaxAge()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionCookieMaxAge", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      if (temp.getSessionConfig().getCookieMaxAge() != null) {
        this.sessionConfig.setCookieMaxAge(temp.getSessionConfig().getCookieMaxAge().toString());
      }
    }
    if (this.sessionConfig.getSessionTrackingModes().size() == 0)
    {
      for (WebXml fragment : fragments)
      {
        EnumSet<SessionTrackingMode> value = fragment.getSessionConfig().getSessionTrackingModes();
        if (value.size() > 0) {
          if (temp.getSessionConfig().getSessionTrackingModes().size() == 0)
          {
            temp.getSessionConfig().getSessionTrackingModes().addAll(value);
          }
          else if (!value.equals(temp.getSessionConfig().getSessionTrackingModes()))
          {
            log.error(sm.getString("webXml.mergeConflictSessionTrackingMode", new Object[] { fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
      }
      this.sessionConfig.getSessionTrackingModes().addAll(temp.getSessionConfig().getSessionTrackingModes());
    }
    for (WebXml fragment : fragments) {
      if (!mergeMap(fragment.getTaglibs(), this.taglibs, temp.getTaglibs(), fragment, "Taglibs")) {
        return false;
      }
    }
    this.taglibs.putAll(temp.getTaglibs());
    for (WebXml fragment : fragments) {
      if ((fragment.alwaysAddWelcomeFiles) || (this.welcomeFiles.size() == 0)) {
        for (String welcomeFile : fragment.getWelcomeFiles()) {
          addWelcomeFile(welcomeFile);
        }
      }
    }
    if (this.postConstructMethods.isEmpty())
    {
      for (WebXml fragment : fragments) {
        if (!mergeLifecycleCallback(fragment.getPostConstructMethods(), temp.getPostConstructMethods(), fragment, "Post Construct Methods")) {
          return false;
        }
      }
      this.postConstructMethods.putAll(temp.getPostConstructMethods());
    }
    if (this.preDestroyMethods.isEmpty())
    {
      for (WebXml fragment : fragments) {
        if (!mergeLifecycleCallback(fragment.getPreDestroyMethods(), temp.getPreDestroyMethods(), fragment, "Pre Destroy Methods")) {
          return false;
        }
      }
      this.preDestroyMethods.putAll(temp.getPreDestroyMethods());
    }
    return true;
  }
  
  private static <T extends ResourceBase> boolean mergeResourceMap(Map<String, T> fragmentResources, Map<String, T> mainResources, Map<String, T> tempResources, WebXml fragment)
  {
    for (T resource : fragmentResources.values())
    {
      String resourceName = resource.getName();
      if (mainResources.containsKey(resourceName))
      {
        ((ResourceBase)mainResources.get(resourceName)).getInjectionTargets().addAll(resource.getInjectionTargets());
      }
      else
      {
        T existingResource = (ResourceBase)tempResources.get(resourceName);
        if (existingResource != null)
        {
          if (!existingResource.equals(resource))
          {
            log.error(sm.getString("webXml.mergeConflictResource", new Object[] { resourceName, fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
        else {
          tempResources.put(resourceName, resource);
        }
      }
    }
    return true;
  }
  
  private static <T> boolean mergeMap(Map<String, T> fragmentMap, Map<String, T> mainMap, Map<String, T> tempMap, WebXml fragment, String mapName)
  {
    for (Map.Entry<String, T> entry : fragmentMap.entrySet())
    {
      String key = (String)entry.getKey();
      if (!mainMap.containsKey(key))
      {
        T value = entry.getValue();
        if (tempMap.containsKey(key))
        {
          if ((value != null) && (!value.equals(tempMap.get(key))))
          {
            log.error(sm.getString("webXml.mergeConflictString", new Object[] { mapName, key, fragment.getName(), fragment.getURL() }));
            
            return false;
          }
        }
        else {
          tempMap.put(key, value);
        }
      }
    }
    return true;
  }
  
  private static boolean mergeFilter(FilterDef src, FilterDef dest, boolean failOnConflict)
  {
    if (dest.getAsyncSupported() == null) {
      dest.setAsyncSupported(src.getAsyncSupported());
    } else if ((src.getAsyncSupported() != null) && 
      (failOnConflict) && (!src.getAsyncSupported().equals(dest.getAsyncSupported()))) {
      return false;
    }
    if (dest.getFilterClass() == null) {
      dest.setFilterClass(src.getFilterClass());
    } else if ((src.getFilterClass() != null) && 
      (failOnConflict) && (!src.getFilterClass().equals(dest.getFilterClass()))) {
      return false;
    }
    for (Map.Entry<String, String> srcEntry : src.getParameterMap().entrySet()) {
      if (dest.getParameterMap().containsKey(srcEntry.getKey()))
      {
        if ((failOnConflict) && (!((String)dest.getParameterMap().get(srcEntry.getKey())).equals(srcEntry.getValue()))) {
          return false;
        }
      }
      else {
        dest.addInitParameter((String)srcEntry.getKey(), (String)srcEntry.getValue());
      }
    }
    return true;
  }
  
  private static boolean mergeServlet(ServletDef src, ServletDef dest, boolean failOnConflict)
  {
    if ((dest.getServletClass() != null) && (dest.getJspFile() != null)) {
      return false;
    }
    if ((src.getServletClass() != null) && (src.getJspFile() != null)) {
      return false;
    }
    if ((dest.getServletClass() == null) && (dest.getJspFile() == null))
    {
      dest.setServletClass(src.getServletClass());
      dest.setJspFile(src.getJspFile());
    }
    else if (failOnConflict)
    {
      if ((src.getServletClass() != null) && ((dest.getJspFile() != null) || (!src.getServletClass().equals(dest.getServletClass())))) {
        return false;
      }
      if ((src.getJspFile() != null) && ((dest.getServletClass() != null) || (!src.getJspFile().equals(dest.getJspFile())))) {
        return false;
      }
    }
    for (SecurityRoleRef securityRoleRef : src.getSecurityRoleRefs()) {
      dest.addSecurityRoleRef(securityRoleRef);
    }
    if (dest.getLoadOnStartup() == null)
    {
      if (src.getLoadOnStartup() != null) {
        dest.setLoadOnStartup(src.getLoadOnStartup().toString());
      }
    }
    else if ((src.getLoadOnStartup() != null) && 
      (failOnConflict) && (!src.getLoadOnStartup().equals(dest.getLoadOnStartup()))) {
      return false;
    }
    if (dest.getEnabled() == null)
    {
      if (src.getEnabled() != null) {
        dest.setEnabled(src.getEnabled().toString());
      }
    }
    else if ((src.getEnabled() != null) && 
      (failOnConflict) && (!src.getEnabled().equals(dest.getEnabled()))) {
      return false;
    }
    for (Map.Entry<String, String> srcEntry : src.getParameterMap().entrySet()) {
      if (dest.getParameterMap().containsKey(srcEntry.getKey()))
      {
        if ((failOnConflict) && (!((String)dest.getParameterMap().get(srcEntry.getKey())).equals(srcEntry.getValue()))) {
          return false;
        }
      }
      else {
        dest.addInitParameter((String)srcEntry.getKey(), (String)srcEntry.getValue());
      }
    }
    if (dest.getMultipartDef() == null) {
      dest.setMultipartDef(src.getMultipartDef());
    } else if (src.getMultipartDef() != null) {
      return mergeMultipartDef(src.getMultipartDef(), dest.getMultipartDef(), failOnConflict);
    }
    if (dest.getAsyncSupported() == null)
    {
      if (src.getAsyncSupported() != null) {
        dest.setAsyncSupported(src.getAsyncSupported().toString());
      }
    }
    else if ((src.getAsyncSupported() != null) && 
      (failOnConflict) && (!src.getAsyncSupported().equals(dest.getAsyncSupported()))) {
      return false;
    }
    return true;
  }
  
  private static boolean mergeMultipartDef(MultipartDef src, MultipartDef dest, boolean failOnConflict)
  {
    if (dest.getLocation() == null) {
      dest.setLocation(src.getLocation());
    } else if ((src.getLocation() != null) && 
      (failOnConflict) && (!src.getLocation().equals(dest.getLocation()))) {
      return false;
    }
    if (dest.getFileSizeThreshold() == null) {
      dest.setFileSizeThreshold(src.getFileSizeThreshold());
    } else if ((src.getFileSizeThreshold() != null) && 
      (failOnConflict) && (!src.getFileSizeThreshold().equals(dest.getFileSizeThreshold()))) {
      return false;
    }
    if (dest.getMaxFileSize() == null) {
      dest.setMaxFileSize(src.getMaxFileSize());
    } else if ((src.getMaxFileSize() != null) && 
      (failOnConflict) && (!src.getMaxFileSize().equals(dest.getMaxFileSize()))) {
      return false;
    }
    if (dest.getMaxRequestSize() == null) {
      dest.setMaxRequestSize(src.getMaxRequestSize());
    } else if ((src.getMaxRequestSize() != null) && 
      (failOnConflict) && (!src.getMaxRequestSize().equals(dest.getMaxRequestSize()))) {
      return false;
    }
    return true;
  }
  
  private static <T> boolean mergeLifecycleCallback(Map<String, String> fragmentMap, Map<String, String> tempMap, WebXml fragment, String mapName)
  {
    for (Map.Entry<String, String> entry : fragmentMap.entrySet())
    {
      String key = (String)entry.getKey();
      String value = (String)entry.getValue();
      if (tempMap.containsKey(key))
      {
        if ((value != null) && (!value.equals(tempMap.get(key))))
        {
          log.error(sm.getString("webXml.mergeConflictString", new Object[] { mapName, key, fragment.getName(), fragment.getURL() }));
          
          return false;
        }
      }
      else {
        tempMap.put(key, value);
      }
    }
    return true;
  }
  
  public static Set<WebXml> orderWebFragments(WebXml application, Map<String, WebXml> fragments, ServletContext servletContext)
  {
    Set<WebXml> orderedFragments = new LinkedHashSet();
    
    boolean absoluteOrdering = application.getAbsoluteOrdering() != null;
    
    boolean orderingPresent = false;
    Set<String> requestedOrder;
    if (absoluteOrdering)
    {
      orderingPresent = true;
      
      requestedOrder = application.getAbsoluteOrdering();
      for (String requestedName : requestedOrder) {
        if ("org.apache.catalina.order.others".equals(requestedName))
        {
          for (Map.Entry<String, WebXml> entry : fragments.entrySet()) {
            if (!requestedOrder.contains(entry.getKey()))
            {
              WebXml fragment = (WebXml)entry.getValue();
              if (fragment != null) {
                orderedFragments.add(fragment);
              }
            }
          }
        }
        else
        {
          WebXml fragment = (WebXml)fragments.get(requestedName);
          if (fragment != null) {
            orderedFragments.add(fragment);
          } else {
            log.warn(sm.getString("webXml.wrongFragmentName", new Object[] { requestedName }));
          }
        }
      }
    }
    else
    {
      for (WebXml fragment : fragments.values())
      {
        Iterator<String> before = fragment.getBeforeOrdering().iterator();
        while (before.hasNext())
        {
          orderingPresent = true;
          String beforeEntry = (String)before.next();
          if (!beforeEntry.equals("org.apache.catalina.order.others"))
          {
            WebXml beforeFragment = (WebXml)fragments.get(beforeEntry);
            if (beforeFragment == null) {
              before.remove();
            } else {
              beforeFragment.addAfterOrdering(fragment.getName());
            }
          }
        }
        Iterator<String> after = fragment.getAfterOrdering().iterator();
        while (after.hasNext())
        {
          orderingPresent = true;
          String afterEntry = (String)after.next();
          if (!afterEntry.equals("org.apache.catalina.order.others"))
          {
            WebXml afterFragment = (WebXml)fragments.get(afterEntry);
            if (afterFragment == null) {
              after.remove();
            } else {
              afterFragment.addBeforeOrdering(fragment.getName());
            }
          }
        }
      }
      for (WebXml fragment : fragments.values())
      {
        if (fragment.getBeforeOrdering().contains("org.apache.catalina.order.others")) {
          makeBeforeOthersExplicit(fragment.getAfterOrdering(), fragments);
        }
        if (fragment.getAfterOrdering().contains("org.apache.catalina.order.others")) {
          makeAfterOthersExplicit(fragment.getBeforeOrdering(), fragments);
        }
      }
      Set<WebXml> beforeSet = new HashSet();
      Set<WebXml> othersSet = new HashSet();
      Set<WebXml> afterSet = new HashSet();
      for (WebXml fragment : fragments.values()) {
        if (fragment.getBeforeOrdering().contains("org.apache.catalina.order.others"))
        {
          beforeSet.add(fragment);
          fragment.getBeforeOrdering().remove("org.apache.catalina.order.others");
        }
        else if (fragment.getAfterOrdering().contains("org.apache.catalina.order.others"))
        {
          afterSet.add(fragment);
          fragment.getAfterOrdering().remove("org.apache.catalina.order.others");
        }
        else
        {
          othersSet.add(fragment);
        }
      }
      decoupleOtherGroups(beforeSet);
      decoupleOtherGroups(othersSet);
      decoupleOtherGroups(afterSet);
      
      orderFragments(orderedFragments, beforeSet);
      orderFragments(orderedFragments, othersSet);
      orderFragments(orderedFragments, afterSet);
    }
    if (servletContext != null)
    {
      List<String> orderedJarFileNames = null;
      if (orderingPresent)
      {
        orderedJarFileNames = new ArrayList();
        for (WebXml fragment : orderedFragments) {
          orderedJarFileNames.add(fragment.getJarName());
        }
      }
      servletContext.setAttribute("javax.servlet.context.orderedLibs", orderedJarFileNames);
    }
    return orderedFragments;
  }
  
  private static void decoupleOtherGroups(Set<WebXml> group)
  {
    Set<String> names = new HashSet();
    for (WebXml fragment : group) {
      names.add(fragment.getName());
    }
    for (WebXml fragment : group)
    {
      Iterator<String> after = fragment.getAfterOrdering().iterator();
      while (after.hasNext())
      {
        String entry = (String)after.next();
        if (!names.contains(entry)) {
          after.remove();
        }
      }
    }
  }
  
  private static void orderFragments(Set<WebXml> orderedFragments, Set<WebXml> unordered)
  {
    Set<WebXml> addedThisRound = new HashSet();
    Set<WebXml> addedLastRound = new HashSet();
    while (unordered.size() > 0)
    {
      Iterator<WebXml> source = unordered.iterator();
      while (source.hasNext())
      {
        WebXml fragment = (WebXml)source.next();
        for (WebXml toRemove : addedLastRound) {
          fragment.getAfterOrdering().remove(toRemove.getName());
        }
        if (fragment.getAfterOrdering().isEmpty())
        {
          addedThisRound.add(fragment);
          orderedFragments.add(fragment);
          source.remove();
        }
      }
      if (addedThisRound.size() == 0) {
        throw new IllegalArgumentException(sm.getString("webXml.mergeConflictOrder"));
      }
      addedLastRound.clear();
      addedLastRound.addAll(addedThisRound);
      addedThisRound.clear();
    }
  }
  
  private static void makeBeforeOthersExplicit(Set<String> beforeOrdering, Map<String, WebXml> fragments)
  {
    for (String before : beforeOrdering) {
      if (!before.equals("org.apache.catalina.order.others"))
      {
        WebXml webXml = (WebXml)fragments.get(before);
        if (!webXml.getBeforeOrdering().contains("org.apache.catalina.order.others"))
        {
          webXml.addBeforeOrderingOthers();
          makeBeforeOthersExplicit(webXml.getAfterOrdering(), fragments);
        }
      }
    }
  }
  
  private static void makeAfterOthersExplicit(Set<String> afterOrdering, Map<String, WebXml> fragments)
  {
    for (String after : afterOrdering) {
      if (!after.equals("org.apache.catalina.order.others"))
      {
        WebXml webXml = (WebXml)fragments.get(after);
        if (!webXml.getAfterOrdering().contains("org.apache.catalina.order.others"))
        {
          webXml.addAfterOrderingOthers();
          makeAfterOthersExplicit(webXml.getBeforeOrdering(), fragments);
        }
      }
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\deploy\WebXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */