package org.apache.catalina.startup;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.apache.catalina.loader.StandardClassLoader;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public final class ClassLoaderFactory
{
  private static final Log log = LogFactory.getLog(ClassLoaderFactory.class);
  
  public ClassLoaderFactory() {}
  
  public static ClassLoader createClassLoader(File[] unpacked, File[] packed, ClassLoader parent)
    throws Exception
  {
    if (log.isDebugEnabled()) {
      log.debug("Creating new class loader");
    }
    Set<URL> set = new LinkedHashSet();
    if (unpacked != null) {
      for (int i = 0; i < unpacked.length; i++)
      {
        File file = unpacked[i];
        if ((file.exists()) && (file.canRead()))
        {
          file = new File(file.getCanonicalPath() + File.separator);
          URL url = file.toURI().toURL();
          if (log.isDebugEnabled()) {
            log.debug("  Including directory " + url);
          }
          set.add(url);
        }
      }
    }
    if (packed != null) {
      for (int i = 0; i < packed.length; i++)
      {
        File directory = packed[i];
        if ((directory.isDirectory()) && (directory.exists()) && (directory.canRead()))
        {
          String[] filenames = directory.list();
          for (int j = 0; j < filenames.length; j++)
          {
            String filename = filenames[j].toLowerCase(Locale.ENGLISH);
            if (filename.endsWith(".jar"))
            {
              File file = new File(directory, filenames[j]);
              if (log.isDebugEnabled()) {
                log.debug("  Including jar file " + file.getAbsolutePath());
              }
              URL url = file.toURI().toURL();
              set.add(url);
            }
          }
        }
      }
    }
    final URL[] array = (URL[])set.toArray(new URL[set.size()]);
    (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
    {
      public StandardClassLoader run()
      {
        if (this.val$parent == null) {
          return new StandardClassLoader(array);
        }
        return new StandardClassLoader(array, this.val$parent);
      }
    });
  }
  
  public static ClassLoader createClassLoader(List<Repository> repositories, ClassLoader parent)
    throws Exception
  {
    if (log.isDebugEnabled()) {
      log.debug("Creating new class loader");
    }
    Set<URL> set = new LinkedHashSet();
    if (repositories != null) {
      for (Repository repository : repositories) {
        if (repository.getType() == RepositoryType.URL)
        {
          URL url = new URL(repository.getLocation());
          if (log.isDebugEnabled()) {
            log.debug("  Including URL " + url);
          }
          set.add(url);
        }
        else if (repository.getType() == RepositoryType.DIR)
        {
          File directory = new File(repository.getLocation());
          directory = directory.getCanonicalFile();
          if (validateFile(directory, RepositoryType.DIR))
          {
            URL url = directory.toURI().toURL();
            if (log.isDebugEnabled()) {
              log.debug("  Including directory " + url);
            }
            set.add(url);
          }
        }
        else if (repository.getType() == RepositoryType.JAR)
        {
          File file = new File(repository.getLocation());
          file = file.getCanonicalFile();
          if (validateFile(file, RepositoryType.JAR))
          {
            URL url = file.toURI().toURL();
            if (log.isDebugEnabled()) {
              log.debug("  Including jar file " + url);
            }
            set.add(url);
          }
        }
        else if (repository.getType() == RepositoryType.GLOB)
        {
          File directory = new File(repository.getLocation());
          directory = directory.getCanonicalFile();
          if (validateFile(directory, RepositoryType.GLOB))
          {
            if (log.isDebugEnabled()) {
              log.debug("  Including directory glob " + directory.getAbsolutePath());
            }
            String[] filenames = directory.list();
            for (int j = 0; j < filenames.length; j++)
            {
              String filename = filenames[j].toLowerCase(Locale.ENGLISH);
              if (filename.endsWith(".jar"))
              {
                File file = new File(directory, filenames[j]);
                file = file.getCanonicalFile();
                if (validateFile(file, RepositoryType.JAR))
                {
                  if (log.isDebugEnabled()) {
                    log.debug("    Including glob jar file " + file.getAbsolutePath());
                  }
                  URL url = file.toURI().toURL();
                  set.add(url);
                }
              }
            }
          }
        }
      }
    }
    final URL[] array = (URL[])set.toArray(new URL[set.size()]);
    if (log.isDebugEnabled()) {
      for (int i = 0; i < array.length; i++) {
        log.debug("  location " + i + " is " + array[i]);
      }
    }
    (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
    {
      public StandardClassLoader run()
      {
        if (this.val$parent == null) {
          return new StandardClassLoader(array);
        }
        return new StandardClassLoader(array, this.val$parent);
      }
    });
  }
  
  private static boolean validateFile(File file, RepositoryType type)
    throws IOException
  {
    if ((RepositoryType.DIR == type) || (RepositoryType.GLOB == type))
    {
      if ((!file.exists()) || (!file.isDirectory()) || (!file.canRead()))
      {
        String msg = "Problem with directory [" + file + "], exists: [" + file.exists() + "], isDirectory: [" + file.isDirectory() + "], canRead: [" + file.canRead() + "]";
        
        File home = new File(Bootstrap.getCatalinaHome());
        home = home.getCanonicalFile();
        File base = new File(Bootstrap.getCatalinaBase());
        base = base.getCanonicalFile();
        File defaultValue = new File(base, "lib");
        if ((!home.getPath().equals(base.getPath())) && (file.getPath().equals(defaultValue.getPath())) && (!file.exists())) {
          log.debug(msg);
        } else {
          log.warn(msg);
        }
        return false;
      }
    }
    else if ((RepositoryType.JAR == type) && (
      (!file.exists()) || (!file.canRead())))
    {
      log.warn("Problem with JAR file [" + file + "], exists: [" + file.exists() + "], canRead: [" + file.canRead() + "]");
      
      return false;
    }
    return true;
  }
  
  public static enum RepositoryType
  {
    DIR,  GLOB,  JAR,  URL;
    
    private RepositoryType() {}
  }
  
  public static class Repository
  {
    private String location;
    private ClassLoaderFactory.RepositoryType type;
    
    public Repository(String location, ClassLoaderFactory.RepositoryType type)
    {
      this.location = location;
      this.type = type;
    }
    
    public String getLocation()
    {
      return this.location;
    }
    
    public ClassLoaderFactory.RepositoryType getType()
    {
      return this.type;
    }
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\startup\ClassLoaderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */