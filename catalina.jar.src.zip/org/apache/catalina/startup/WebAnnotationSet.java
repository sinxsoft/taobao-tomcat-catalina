package org.apache.catalina.startup;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.annotation.Resource;
import javax.annotation.Resource.AuthenticationType;
import javax.annotation.Resources;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RunAs;
import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.Wrapper;
import org.apache.catalina.deploy.ContextEnvironment;
import org.apache.catalina.deploy.ContextResource;
import org.apache.catalina.deploy.ContextResourceEnvRef;
import org.apache.catalina.deploy.ContextService;
import org.apache.catalina.deploy.FilterDef;
import org.apache.catalina.deploy.MessageDestinationRef;
import org.apache.catalina.deploy.NamingResources;
import org.apache.catalina.util.Introspection;
import org.apache.tomcat.util.res.StringManager;

public class WebAnnotationSet
{
  private static final String SEPARATOR = "/";
  protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
  
  public WebAnnotationSet() {}
  
  public static void loadApplicationAnnotations(Context context)
  {
    loadApplicationListenerAnnotations(context);
    loadApplicationFilterAnnotations(context);
    loadApplicationServletAnnotations(context);
  }
  
  protected static void loadApplicationListenerAnnotations(Context context)
  {
    Class<?> classClass = null;
    String[] applicationListeners = context.findApplicationListeners();
    for (int i = 0; i < applicationListeners.length; i++)
    {
      classClass = Introspection.loadClass(context, applicationListeners[i]);
      if (classClass != null)
      {
        loadClassAnnotation(context, classClass);
        loadFieldsAnnotation(context, classClass);
        loadMethodsAnnotation(context, classClass);
      }
    }
  }
  
  protected static void loadApplicationFilterAnnotations(Context context)
  {
    Class<?> classClass = null;
    FilterDef[] filterDefs = context.findFilterDefs();
    for (int i = 0; i < filterDefs.length; i++)
    {
      classClass = Introspection.loadClass(context, filterDefs[i].getFilterClass());
      if (classClass != null)
      {
        loadClassAnnotation(context, classClass);
        loadFieldsAnnotation(context, classClass);
        loadMethodsAnnotation(context, classClass);
      }
    }
  }
  
  protected static void loadApplicationServletAnnotations(Context context)
  {
    Wrapper wrapper = null;
    Class<?> classClass = null;
    
    Container[] children = context.findChildren();
    for (int i = 0; i < children.length; i++) {
      if ((children[i] instanceof Wrapper))
      {
        wrapper = (Wrapper)children[i];
        if (wrapper.getServletClass() != null)
        {
          classClass = Introspection.loadClass(context, wrapper.getServletClass());
          if (classClass != null)
          {
            loadClassAnnotation(context, classClass);
            loadFieldsAnnotation(context, classClass);
            loadMethodsAnnotation(context, classClass);
            
            RunAs annotation = (RunAs)classClass.getAnnotation(RunAs.class);
            if (annotation != null) {
              wrapper.setRunAs(annotation.value());
            }
          }
        }
      }
    }
  }
  
  protected static void loadClassAnnotation(Context context, Class<?> classClass)
  {
    Resource annotation = (Resource)classClass.getAnnotation(Resource.class);
    if (annotation != null) {
      addResource(context, annotation);
    }
    Resources annotation = (Resources)classClass.getAnnotation(Resources.class);
    if ((annotation != null) && (annotation.value() != null)) {
      for (Resource resource : annotation.value()) {
        addResource(context, resource);
      }
    }
    DeclareRoles annotation = (DeclareRoles)classClass.getAnnotation(DeclareRoles.class);
    if ((annotation != null) && (annotation.value() != null)) {
      for (String role : annotation.value()) {
        context.addSecurityRole(role);
      }
    }
  }
  
  protected static void loadFieldsAnnotation(Context context, Class<?> classClass)
  {
    Field[] fields = Introspection.getDeclaredFields(classClass);
    if ((fields != null) && (fields.length > 0)) {
      for (Field field : fields)
      {
        Resource annotation = (Resource)field.getAnnotation(Resource.class);
        if (annotation != null)
        {
          String defaultName = classClass.getName() + "/" + field.getName();
          Class<?> defaultType = field.getType();
          addResource(context, annotation, defaultName, defaultType);
        }
      }
    }
  }
  
  protected static void loadMethodsAnnotation(Context context, Class<?> classClass)
  {
    Method[] methods = Introspection.getDeclaredMethods(classClass);
    if ((methods != null) && (methods.length > 0)) {
      for (Method method : methods)
      {
        Resource annotation = (Resource)method.getAnnotation(Resource.class);
        if (annotation != null)
        {
          if (!Introspection.isValidSetter(method)) {
            throw new IllegalArgumentException(sm.getString("webAnnotationSet.invalidInjection"));
          }
          String defaultName = classClass.getName() + "/" + Introspection.getPropertyName(method);
          
          Class<?> defaultType = method.getParameterTypes()[0];
          
          addResource(context, annotation, defaultName, defaultType);
        }
      }
    }
  }
  
  protected static void addResource(Context context, Resource annotation)
  {
    addResource(context, annotation, null, null);
  }
  
  protected static void addResource(Context context, Resource annotation, String defaultName, Class<?> defaultType)
  {
    String name = getName(annotation, defaultName);
    String type = getType(annotation, defaultType);
    if ((type.equals("java.lang.String")) || (type.equals("java.lang.Character")) || (type.equals("java.lang.Integer")) || (type.equals("java.lang.Boolean")) || (type.equals("java.lang.Double")) || (type.equals("java.lang.Byte")) || (type.equals("java.lang.Short")) || (type.equals("java.lang.Long")) || (type.equals("java.lang.Float")))
    {
      ContextEnvironment resource = new ContextEnvironment();
      
      resource.setName(name);
      resource.setType(type);
      
      resource.setDescription(annotation.description());
      
      resource.setValue(annotation.mappedName());
      
      context.getNamingResources().addEnvironment(resource);
    }
    else if (type.equals("javax.xml.rpc.Service"))
    {
      ContextService service = new ContextService();
      
      service.setName(name);
      service.setWsdlfile(annotation.mappedName());
      
      service.setType(type);
      service.setDescription(annotation.description());
      
      context.getNamingResources().addService(service);
    }
    else if ((type.equals("javax.sql.DataSource")) || (type.equals("javax.jms.ConnectionFactory")) || (type.equals("javax.jms.QueueConnectionFactory")) || (type.equals("javax.jms.TopicConnectionFactory")) || (type.equals("javax.mail.Session")) || (type.equals("java.net.URL")) || (type.equals("javax.resource.cci.ConnectionFactory")) || (type.equals("org.omg.CORBA_2_3.ORB")) || (type.endsWith("ConnectionFactory")))
    {
      ContextResource resource = new ContextResource();
      
      resource.setName(name);
      resource.setType(type);
      if (annotation.authenticationType() == Resource.AuthenticationType.CONTAINER) {
        resource.setAuth("Container");
      } else if (annotation.authenticationType() == Resource.AuthenticationType.APPLICATION) {
        resource.setAuth("Application");
      }
      resource.setScope(annotation.shareable() ? "Shareable" : "Unshareable");
      resource.setProperty("mappedName", annotation.mappedName());
      resource.setDescription(annotation.description());
      
      context.getNamingResources().addResource(resource);
    }
    else if ((type.equals("javax.jms.Queue")) || (type.equals("javax.jms.Topic")))
    {
      MessageDestinationRef resource = new MessageDestinationRef();
      
      resource.setName(name);
      resource.setType(type);
      
      resource.setUsage(annotation.mappedName());
      resource.setDescription(annotation.description());
      
      context.getNamingResources().addMessageDestinationRef(resource);
    }
    else
    {
      if ((!type.equals("javax.resource.cci.InteractionSpec")) && (!type.equals("javax.transaction.UserTransaction"))) {}
      ContextResourceEnvRef resource = new ContextResourceEnvRef();
      
      resource.setName(name);
      resource.setType(type);
      
      resource.setProperty("mappedName", annotation.mappedName());
      resource.setDescription(annotation.description());
      
      context.getNamingResources().addResourceEnvRef(resource);
    }
  }
  
  private static String getType(Resource annotation, Class<?> defaultType)
  {
    Class<?> type = annotation.type();
    if (((type == null) || (type.equals(Object.class))) && 
      (defaultType != null)) {
      type = defaultType;
    }
    return Introspection.convertPrimitiveType(type).getCanonicalName();
  }
  
  private static String getName(Resource annotation, String defaultName)
  {
    String name = annotation.name();
    if (((name == null) || (name.equals(""))) && 
      (defaultName != null)) {
      name = defaultName;
    }
    return name;
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\startup\WebAnnotationSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */