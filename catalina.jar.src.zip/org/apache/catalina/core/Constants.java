package org.apache.catalina.core;

public class Constants
{
  public static final String Package = "org.apache.catalina.core";
  public static final int MAJOR_VERSION = 3;
  public static final int MINOR_VERSION = 0;
  public static final String JSP_SERVLET_CLASS = "org.apache.jasper.servlet.JspServlet";
  
  public Constants() {}
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\core\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */