package org.apache.catalina.core;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessControlException;
import java.util.Random;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Server;
import org.apache.catalina.Service;
import org.apache.catalina.deploy.NamingResources;
import org.apache.catalina.mbeans.MBeanFactory;
import org.apache.catalina.mbeans.MBeanUtils;
import org.apache.catalina.startup.Catalina;
import org.apache.catalina.util.ExtensionValidator;
import org.apache.catalina.util.LifecycleMBeanBase;
import org.apache.catalina.util.ServerInfo;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.buf.StringCache;
import org.apache.tomcat.util.res.StringManager;

public final class StandardServer
  extends LifecycleMBeanBase
  implements Server
{
  private static final Log log = LogFactory.getLog(StandardServer.class);
  
  static
  {
    System.setProperty("com.taobao.tomcat.version", ServerInfo.getServerNumber());
    System.setProperty("com.taobao.tomcat.info", ServerInfo.getServerInfo());
  }
  
  public StandardServer()
  {
    this.globalNamingResources = new NamingResources();
    this.globalNamingResources.setContainer(this);
    if ((isUseNaming()) && 
      (this.namingContextListener == null))
    {
      this.namingContextListener = new NamingContextListener();
      addLifecycleListener(this.namingContextListener);
    }
  }
  
  private javax.naming.Context globalNamingContext = null;
  private NamingResources globalNamingResources = null;
  private static final String info = "org.apache.catalina.core.StandardServer/1.0";
  private NamingContextListener namingContextListener = null;
  private int port = 8005;
  private String address = "localhost";
  private Random random = null;
  private Service[] services = new Service[0];
  private String shutdown = "SHUTDOWN";
  private static final StringManager sm = StringManager.getManager("org.apache.catalina.core");
  protected PropertyChangeSupport support = new PropertyChangeSupport(this);
  private volatile boolean stopAwait = false;
  private Catalina catalina = null;
  private ClassLoader parentClassLoader = null;
  private volatile Thread awaitThread = null;
  private volatile ServerSocket awaitSocket = null;
  private ObjectName onameStringCache;
  private ObjectName onameMBeanFactory;
  
  public javax.naming.Context getGlobalNamingContext()
  {
    return this.globalNamingContext;
  }
  
  public void setGlobalNamingContext(javax.naming.Context globalNamingContext)
  {
    this.globalNamingContext = globalNamingContext;
  }
  
  public NamingResources getGlobalNamingResources()
  {
    return this.globalNamingResources;
  }
  
  public void setGlobalNamingResources(NamingResources globalNamingResources)
  {
    NamingResources oldGlobalNamingResources = this.globalNamingResources;
    
    this.globalNamingResources = globalNamingResources;
    this.globalNamingResources.setContainer(this);
    this.support.firePropertyChange("globalNamingResources", oldGlobalNamingResources, this.globalNamingResources);
  }
  
  public String getInfo()
  {
    return "org.apache.catalina.core.StandardServer/1.0";
  }
  
  public String getServerInfo()
  {
    return ServerInfo.getServerInfo();
  }
  
  public int getPort()
  {
    return this.port;
  }
  
  public void setPort(int port)
  {
    this.port = port;
  }
  
  public String getAddress()
  {
    return this.address;
  }
  
  public void setAddress(String address)
  {
    this.address = address;
  }
  
  public String getShutdown()
  {
    return this.shutdown;
  }
  
  public void setShutdown(String shutdown)
  {
    this.shutdown = shutdown;
  }
  
  public Catalina getCatalina()
  {
    return this.catalina;
  }
  
  public void setCatalina(Catalina catalina)
  {
    this.catalina = catalina;
  }
  
  public void addService(Service service)
  {
    service.setServer(this);
    synchronized (this.services)
    {
      Service[] results = new Service[this.services.length + 1];
      System.arraycopy(this.services, 0, results, 0, this.services.length);
      results[this.services.length] = service;
      this.services = results;
      if (getState().isAvailable()) {
        try
        {
          service.start();
        }
        catch (LifecycleException e) {}
      }
      this.support.firePropertyChange("service", null, service);
    }
  }
  
  public void stopAwait()
  {
    this.stopAwait = true;
    Thread t = this.awaitThread;
    if (t != null)
    {
      ServerSocket s = this.awaitSocket;
      if (s != null)
      {
        this.awaitSocket = null;
        try
        {
          s.close();
        }
        catch (IOException e) {}
      }
      t.interrupt();
      try
      {
        t.join(1000L);
      }
      catch (InterruptedException e) {}
    }
  }
  
  public void await()
  {
    if (this.port == -2) {
      return;
    }
    if (this.port == -1)
    {
      try
      {
        this.awaitThread = Thread.currentThread();
        while (!this.stopAwait) {
          try
          {
            Thread.sleep(10000L);
          }
          catch (InterruptedException ex) {}
        }
      }
      finally
      {
        this.awaitThread = null;
      }
      return;
    }
    try
    {
      this.awaitSocket = new ServerSocket(this.port, 1, InetAddress.getByName(this.address));
    }
    catch (IOException e)
    {
      log.error("StandardServer.await: create[" + this.address + ":" + this.port + "]: ", e);
      
      return;
    }
    try
    {
      this.awaitThread = Thread.currentThread();
      while (!this.stopAwait)
      {
        ServerSocket serverSocket = this.awaitSocket;
        if (serverSocket == null) {
          break;
        }
        Socket socket = null;
        StringBuilder command = new StringBuilder();
        try
        {
          long acceptStartTime = System.currentTimeMillis();
          InputStream stream;
          try
          {
            socket = serverSocket.accept();
            socket.setSoTimeout(10000);
            stream = socket.getInputStream();
          }
          catch (SocketTimeoutException ste)
          {
            log.warn(sm.getString("standardServer.accept.timeout", new Object[] { Long.valueOf(System.currentTimeMillis() - acceptStartTime) }), ste);
            try
            {
              if (socket != null) {
                socket.close();
              }
            }
            catch (IOException e) {}
            continue;
          }
          catch (AccessControlException ace)
          {
            log.warn("StandardServer.accept security exception: " + ace.getMessage(), ace);
            try
            {
              if (socket != null) {
                socket.close();
              }
            }
            catch (IOException e) {}
            continue;
          }
          catch (IOException e)
          {
            if (this.stopAwait) {
              try
              {
                if (socket != null) {
                  socket.close();
                }
              }
              catch (IOException e) {}
            }
            log.error("StandardServer.await: accept: ", e);
          }
          int expected = 1024;
          while (expected < this.shutdown.length())
          {
            if (this.random == null) {
              this.random = new Random();
            }
            expected += this.random.nextInt() % 1024;
          }
          while (expected > 0)
          {
            int ch = -1;
            try
            {
              ch = stream.read();
            }
            catch (IOException e)
            {
              log.warn("StandardServer.await: read: ", e);
              ch = -1;
            }
            if (ch < 32) {
              break;
            }
            command.append((char)ch);
            expected--;
          }
          try
          {
            if (socket != null) {
              socket.close();
            }
          }
          catch (IOException e) {}
          match = command.toString().equals(this.shutdown);
        }
        finally
        {
          try
          {
            if (socket != null) {
              socket.close();
            }
          }
          catch (IOException e) {}
        }
        boolean match;
        if (match)
        {
          log.info(sm.getString("standardServer.shutdownViaPort"));
          break;
        }
        log.warn("StandardServer.await: Invalid command '" + command.toString() + "' received");
      }
    }
    finally
    {
      ServerSocket serverSocket;
      ServerSocket serverSocket = this.awaitSocket;
      this.awaitThread = null;
      this.awaitSocket = null;
      if (serverSocket != null) {
        try
        {
          serverSocket.close();
        }
        catch (IOException e) {}
      }
    }
  }
  
  public Service findService(String name)
  {
    if (name == null) {
      return null;
    }
    synchronized (this.services)
    {
      for (int i = 0; i < this.services.length; i++) {
        if (name.equals(this.services[i].getName())) {
          return this.services[i];
        }
      }
    }
    return null;
  }
  
  public Service[] findServices()
  {
    return this.services;
  }
  
  public ObjectName[] getServiceNames()
  {
    ObjectName[] onames = new ObjectName[this.services.length];
    for (int i = 0; i < this.services.length; i++) {
      onames[i] = ((StandardService)this.services[i]).getObjectName();
    }
    return onames;
  }
  
  public void removeService(Service service)
  {
    synchronized (this.services)
    {
      int j = -1;
      for (int i = 0; i < this.services.length; i++) {
        if (service == this.services[i])
        {
          j = i;
          break;
        }
      }
      if (j < 0) {
        return;
      }
      try
      {
        this.services[j].stop();
      }
      catch (LifecycleException e) {}
      int k = 0;
      Service[] results = new Service[this.services.length - 1];
      for (int i = 0; i < this.services.length; i++) {
        if (i != j) {
          results[(k++)] = this.services[i];
        }
      }
      this.services = results;
      
      this.support.firePropertyChange("service", service, null);
    }
  }
  
  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    this.support.addPropertyChangeListener(listener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    this.support.removePropertyChangeListener(listener);
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder("StandardServer[");
    sb.append(getPort());
    sb.append("]");
    return sb.toString();
  }
  
  public synchronized void storeConfig()
    throws Exception
  {
    ObjectName sname = new ObjectName("Catalina:type=StoreConfig");
    this.mserver.invoke(sname, "storeConfig", null, null);
  }
  
  public synchronized void storeContext(org.apache.catalina.Context context)
    throws Exception
  {
    ObjectName sname = null;
    try
    {
      sname = new ObjectName("Catalina:type=StoreConfig");
      if (this.mserver.isRegistered(sname)) {
        this.mserver.invoke(sname, "store", new Object[] { context }, new String[] { "java.lang.String" });
      } else {
        log.error("StoreConfig mbean not registered" + sname);
      }
    }
    catch (Throwable t)
    {
      ExceptionUtils.handleThrowable(t);
      log.error(t);
    }
  }
  
  private boolean isUseNaming()
  {
    boolean useNaming = true;
    
    String useNamingProperty = System.getProperty("catalina.useNaming");
    if ((useNamingProperty != null) && (useNamingProperty.equals("false"))) {
      useNaming = false;
    }
    return useNaming;
  }
  
  protected void startInternal()
    throws LifecycleException
  {
    fireLifecycleEvent("configure_start", null);
    setState(LifecycleState.STARTING);
    
    this.globalNamingResources.start();
    synchronized (this.services)
    {
      for (int i = 0; i < this.services.length; i++) {
        this.services[i].start();
      }
    }
  }
  
  protected void stopInternal()
    throws LifecycleException
  {
    setState(LifecycleState.STOPPING);
    fireLifecycleEvent("configure_stop", null);
    for (int i = 0; i < this.services.length; i++) {
      this.services[i].stop();
    }
    this.globalNamingResources.stop();
    
    stopAwait();
  }
  
  protected void initInternal()
    throws LifecycleException
  {
    super.initInternal();
    
    this.onameStringCache = register(new StringCache(), "type=StringCache");
    
    MBeanFactory factory = new MBeanFactory();
    factory.setContainer(this);
    this.onameMBeanFactory = register(factory, "type=MBeanFactory");
    
    this.globalNamingResources.init();
    if (getCatalina() != null)
    {
      ClassLoader cl = getCatalina().getParentClassLoader();
      while ((cl != null) && (cl != ClassLoader.getSystemClassLoader()))
      {
        if ((cl instanceof URLClassLoader))
        {
          URL[] urls = ((URLClassLoader)cl).getURLs();
          for (URL url : urls) {
            if (url.getProtocol().equals("file")) {
              try
              {
                File f = new File(url.toURI());
                if ((f.isFile()) && (f.getName().endsWith(".jar"))) {
                  ExtensionValidator.addSystemResource(f);
                }
              }
              catch (URISyntaxException e) {}catch (IOException e) {}
            }
          }
        }
        cl = cl.getParent();
      }
    }
    for (int i = 0; i < this.services.length; i++) {
      this.services[i].init();
    }
  }
  
  protected void destroyInternal()
    throws LifecycleException
  {
    for (int i = 0; i < this.services.length; i++) {
      this.services[i].destroy();
    }
    this.globalNamingResources.destroy();
    
    unregister(this.onameMBeanFactory);
    
    unregister(this.onameStringCache);
    
    super.destroyInternal();
  }
  
  public ClassLoader getParentClassLoader()
  {
    if (this.parentClassLoader != null) {
      return this.parentClassLoader;
    }
    if (this.catalina != null) {
      return this.catalina.getParentClassLoader();
    }
    return ClassLoader.getSystemClassLoader();
  }
  
  public void setParentClassLoader(ClassLoader parent)
  {
    ClassLoader oldParentClassLoader = this.parentClassLoader;
    this.parentClassLoader = parent;
    this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
  }
  
  protected String getDomainInternal()
  {
    String domain = null;
    
    Service[] services = findServices();
    if (services.length > 0)
    {
      Service service = services[0];
      if (service != null) {
        domain = MBeanUtils.getDomain(service);
      }
    }
    return domain;
  }
  
  protected final String getObjectNameKeyProperties()
  {
    return "type=Server";
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\org\apache\catalina\core\StandardServer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */