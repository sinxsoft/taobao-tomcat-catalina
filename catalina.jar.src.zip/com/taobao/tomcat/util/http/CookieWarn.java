package com.taobao.tomcat.util.http;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import org.apache.tomcat.util.buf.ByteChunk;

public class CookieWarn
{
  private Exception exception;
  private String message;
  private ByteChunk cookie;
  
  public CookieWarn() {}
  
  public Exception getException()
  {
    return this.exception;
  }
  
  public void setException(Exception exception)
  {
    this.exception = exception;
  }
  
  public String getMessage()
  {
    return this.message;
  }
  
  public void setMessage(String message)
  {
    this.message = message;
  }
  
  public ByteChunk getCookie()
  {
    return this.cookie;
  }
  
  public void setCookie(ByteChunk cookie)
  {
    this.cookie = cookie;
  }
  
  public String getCookieString()
  {
    ByteBuffer bb = ByteBuffer.wrap(this.cookie.getBytes(), this.cookie.getOffset(), this.cookie.getLength());
    CharBuffer cb = Charset.defaultCharset().decode(bb);
    return new String(cb.array(), cb.arrayOffset(), cb.length());
  }
}


/* Location:              D:\F\阿里云架构开发\taobao-tomcat-7.0.59\taobao-tomcat-7.0.59\lib\catalina.jar!\com\taobao\tomcat\util\http\CookieWarn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */